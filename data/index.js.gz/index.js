var hst = '192.168.1.13';
var _rooms = [];
let LANG = {};
let LANG_FALLBACK = {};
const isDevHost = window.location.protocol === 'file:' || ['localhost', '127.0.0.1'].includes(window.location.hostname);
var baseUrl = isDevHost ? `http://${hst}` : '';
const GIT_SYNC_PORT = 8082;
const GITHUB_RAW_ROOT = 'https://raw.githubusercontent.com/xkain/TESTRTS/';
const GEO_HELPER_URL = 'https://xkain.github.io/TESTRTS/geolocalisation.html';
const GEO_HELPER_ORIGIN = new URL(GEO_HELPER_URL).origin;
let _pendingGeoFromUrl = null;
(function() {
const params = new URLSearchParams(window.location.search);
if (!params.has('lat') || !params.has('lon')) return;
const lat = parseFloat(params.get('lat'));
const lon = parseFloat(params.get('lon'));
if (!isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
_pendingGeoFromUrl = { lat, lon };
}
params.delete('lat');
params.delete('lon');
const qs = params.toString();
history.replaceState(null, '', window.location.pathname + (qs ? '?' + qs : '') + window.location.hash);
})();
window.addEventListener('message', (event) => {
if (event.origin !== GEO_HELPER_ORIGIN) return;
const d = event.data;
if (!d || d.source !== 'espsomfy-geo') return;
const lat = Number(d.lat), lon = Number(d.lon);
if (!Number.isFinite(lat) || lat < -90 || lat > 90) return;
if (!Number.isFinite(lon) || lon < -180 || lon > 180) return;
if (get('inputGeoLat') && get('inputGeoLon')) {
get('inputGeoLat').value = lat.toFixed(2);
get('inputGeoLon').value = lon.toFixed(2);
} else {
general.GeoOverlay({ lat, lon });
}
event.source?.postMessage({ source: 'espsomfy-geo-ack' }, event.origin);
});
const LANG_MANIFEST_URL = GITHUB_RAW_ROOT + 'main/locales/manifest.json';
const isApMode = window.location.hostname === '192.168.4.1';
var waitLoad;
var waitLoadTimer;
const LANG_WAIT_OVERLAY_DELAY = 1200;
const get = id => document.getElementById(id);
const isPrimaryPress = (evt) => !evt || typeof evt.button !== 'number' || evt.button === 0;
var mouseDown = false;
const POINTER_HOLD_MAX_MS = 15000;
let pointerHoldTimer = null;
const setPointerDown = (down) => () => {
mouseDown = down;
if (pointerHoldTimer) { clearTimeout(pointerHoldTimer); pointerHoldTimer = null; }
if (down) pointerHoldTimer = setTimeout(() => { pointerHoldTimer = null; mouseDown = false; }, POINTER_HOLD_MAX_MS);
};
const releasePointer = setPointerDown(false);
const pressPointer = setPointerDown(true);
document.addEventListener('mousedown', (evt) => { if (isPrimaryPress(evt)) pressPointer(); }, true);
document.addEventListener('mouseup', releasePointer, true);
document.addEventListener('touchstart', pressPointer, { capture: true, passive: true });
document.addEventListener('touchend', releasePointer, true);
document.addEventListener('touchcancel', releasePointer, true);
document.addEventListener('pointerup', releasePointer, true);
document.addEventListener('pointercancel', releasePointer, true);
document.addEventListener('mouseleave', releasePointer, true);
document.addEventListener('mousemove', (evt) => { if (mouseDown && evt.buttons === 0) releasePointer(); }, true);
document.addEventListener('visibilitychange', () => { if (document.hidden) releasePointer(); }, true);
window.addEventListener('blur', releasePointer);
let deviceUptimeSeconds = 0;
let netUptimeSeconds = 0;
let uptimeInterval = null;
const logger = {
_debugEnabled: false,
setDebugEnabled(enabled) { this._debugEnabled = !!enabled; },
debug(...args) { if (this._debugEnabled) console.log(...args); },
info(...args) { if (this._debugEnabled) console.info(...args); },
warn(...args) { console.warn(...args); },
error(...args) { console.error(...args); }
};
function initMultiClickToggle(triggerSelector, action, requiredClicks = 3) {
const triggers = document.querySelectorAll(triggerSelector);
if (!triggers.length) return;
let clickCount = 0;
let clickTimeout;
const fire = typeof action === 'function' ? action : () => {
document.body.classList.add(action);
if (typeof ui?.successMessage === 'function') {
ui.successMessage("Mode avancé débloqué.");
}
};
triggers.forEach((trigger) => trigger.addEventListener('pointerdown', (e) => {
if (e.button !== 0) return;
clickCount++;
clearTimeout(clickTimeout);
clickTimeout = setTimeout(() => { clickCount = 0; }, 2000);
if (clickCount >= requiredClicks) {
clickCount = 0;
fire();
}
}));
}
window.tr = function(id) {
if (LANG && LANG[id]) return LANG[id];
if (LANG_FALLBACK && LANG_FALLBACK[id]) return LANG_FALLBACK[id];
return id;
};
window.trOr = function(id, fallback) {
const v = tr(id);
return v === id ? fallback : v;
};
window.escAttr = function(str) {
return String(str).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
};
window.escHtml = function(str) {
return String(str ?? '').replace(/[&<>"']/g, c =>
({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
};
const translator = {
isInitialized: false,
observer: null,
translate(el) {
const key = el.getAttribute('tr');
if (!key) return;
const text = tr(key);
if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
el.placeholder = text;
} else if (el.hasAttribute('title')) {
el.title = text;
} else {
el.textContent = text;
}
},
init() {
document.querySelectorAll('[tr]').forEach(el => this.translate(el));
if (this.isInitialized) return;
this.observer = new MutationObserver((mutations) => {
mutations.forEach(m => m.addedNodes.forEach(node => {
if (node.nodeType === 1) {
if (node.hasAttribute('tr')) this.translate(node);
node.querySelectorAll('[tr]').forEach(el => this.translate(el));
}
}));
});
this.observer.observe(document.body, { childList: true, subtree: true });
this.isInitialized = true;
}
};
function loadLang(callback) {
if (Object.keys(LANG).length > 0) {
logger.debug("Language already cached, skipping reload");
if (callback) callback();
return;
}
if (!waitLoad && !waitLoadTimer) {
waitLoadTimer = setTimeout(() => {
waitLoadTimer = null;
if (document.body && typeof ui !== 'undefined' && ui.waitMessage) {
waitLoad = ui.waitMessage(document.body);
}
}, LANG_WAIT_OVERLAY_DELAY);
}
fetch(baseUrl + '/lang')
.then(r => r.json())
.then(dict => {
LANG = dict;
return fetch(baseUrl + '/langDefault')
.then(r => (r.ok && r.status !== 204) ? r.json() : null)
.then(d => { if (d) LANG_FALLBACK = d; })
.catch(err => logger.warn('Fallback language unavailable:', err));
})
.then(() => {
translator.init();
finishLoad(callback);
})
.catch(err => {
logger.error("Failed to load language file, falling back to defaults", err);
LANG = { "BT_LOGIN": "Login", "HOME": "Maison" };
translator.init();
finishLoad(callback);
});
}
function finishLoad(callback) {
document.body.classList.add('lang-loaded');
if (waitLoadTimer) {
clearTimeout(waitLoadTimer);
waitLoadTimer = null;
}
if (waitLoad && typeof waitLoad.remove === 'function') {
waitLoad.remove();
}
waitLoad = null;
if (callback) callback();
}
let _langManifestCache = null;
function loadLangManifest() {
if (_langManifestCache) return Promise.resolve(_langManifestCache);
return fetch(baseUrl + '/manifest.json')
.then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
.then(manifest => { _langManifestCache = manifest; return manifest; })
.catch(() => fetch(LANG_MANIFEST_URL)
.then(r => r.json())
.then(manifest => { _langManifestCache = manifest; return manifest; })
.catch(err => { logger.error('Failed to load language manifest:', err); return null; })
);
}
window.langLabel = function(code) {
if (!code) return '';
const native = _langManifestCache && _langManifestCache.langs
&& _langManifestCache.langs[code] && _langManifestCache.langs[code].native;
return native || String(code).toUpperCase();
};
let pendingLangAppliedChecked = false;
function checkPendingLangApplied(activeLang, pendingLang) {
if (pendingLangAppliedChecked) return;
pendingLangAppliedChecked = true;
const watched = localStorage.getItem('pendingLangWatch');
if (!watched) return;
if (pendingLang) return;
localStorage.removeItem('pendingLangWatch');
if (activeLang === watched && typeof general !== 'undefined') general.showLangAppliedToast(watched);
}
let activeLangAvailabilityChecked = false;
function checkActiveLangAvailability(activeLang) {
if (activeLangAvailabilityChecked) return;
if (!activeLang) return;
if (typeof security !== 'undefined' && security.type !== 0 && !security.authenticated) return;
activeLangAvailabilityChecked = true;
deviceFetch('/getInstalledLangs')
.then(installed => {
if (installed.includes(activeLang)) {
checkBrowserLangSuggestion(activeLang);
return;
}
if (typeof general !== 'undefined') general.showLangMissingPrompt(activeLang);
})
.catch(err => logger.error('Failed to check active language availability:', err));
}
let langSuggestionChecked = false;
function checkBrowserLangSuggestion(activeLang) {
if (langSuggestionChecked) return;
if (typeof security !== 'undefined' && security.type !== 0 && !security.authenticated) return;
if (isApMode) return;
langSuggestionChecked = true;
const browserLang = ((navigator.language || navigator.userLanguage || 'en').split('-')[0] || '').toLowerCase();
if (!browserLang || browserLang === activeLang) return;
if (localStorage.getItem('langPromptDismissed_' + browserLang) === '1') return;
Promise.all([
loadLangManifest(),
deviceFetch('/getInstalledLangs').catch(() => [])
])
.then(([manifest, installed]) => {
if (!manifest || !manifest.langs || !manifest.langs[browserLang]) return;
if (installed.includes(browserLang)) return;
if (typeof general !== 'undefined') general.showBrowserLangPrompt(browserLang, manifest.langs[browserLang]);
})
.catch(err => logger.error('Failed to check browser language suggestion:', err));
}
async function gzipCompress(text) {
const stream = new Blob([text]).stream().pipeThrough(new CompressionStream('gzip'));
return await new Response(stream).blob();
}
async function fetchGithubRawContent(path) {
const tag = window.__fwVersionTag;
if (tag) {
const pinnedUrl = `${GITHUB_RAW_ROOT}${tag}/${path}`;
const r = await fetch(pinnedUrl);
if (r.ok) return r.text();
logger.debug(`Language source absent at tag ${tag}, falling back to main:`, pinnedUrl);
}
const fallbackUrl = `${GITHUB_RAW_ROOT}main/${path}`;
const r2 = await fetch(fallbackUrl);
if (!r2.ok) throw new Error('HTTP ' + r2.status);
return r2.text();
}
async function relayLangViaBrowser(code) {
if (typeof CompressionStream === 'undefined') {
throw new Error('unsupported: CompressionStream API absente de ce navigateur');
}
const manifest = await loadLangManifest();
if (!manifest) {
throw new Error('manifest-fetch-failed: pas de route Internet vers raw.githubusercontent.com depuis cet appareil');
}
const info = manifest.langs && manifest.langs[code];
if (!info || !info.path) {
throw new Error('unknown-language: ' + code + ' absent du manifeste');
}
let text;
try {
text = await fetchGithubRawContent(info.path);
} catch (err) {
throw new Error('github-fetch-failed: pas de route Internet vers raw.githubusercontent.com depuis cet appareil (' + err.message + ')');
}
const gzBlob = await gzipCompress(text);
await uploadLangGzBlob(code, gzBlob);
}
async function uploadLangGzBlob(code, gzBlob) {
const fd = new FormData();
fd.append('file', gzBlob, code + '.json.gz');
let upResp;
try {
upResp = await fetch(baseUrl + '/uploadLang?code=' + code, { method: 'POST', body: fd, headers: { apikey: security.apiKey || '' } });
} catch (err) {
throw new Error('upload-failed: ESP32 injoignable depuis ce navigateur (' + err.message + ')');
}
let json;
try {
json = await upResp.json();
} catch (err) {
throw new Error('upload-bad-response: HTTP ' + upResp.status);
}
if (json.status !== 'ok') {
throw new Error('upload-rejected: ' + (json.error || json.desc || ('HTTP ' + upResp.status)));
}
}
async function importLangFileManually(code, file) {
let buf;
try {
buf = await file.arrayBuffer();
} catch (err) {
throw new Error('read-failed: impossible de lire le fichier sélectionné (' + err.message + ')');
}
const bytes = new Uint8Array(buf);
const isGzip = bytes.length >= 2 && bytes[0] === 0x1F && bytes[1] === 0x8B;
if (isGzip) {
if (typeof DecompressionStream === 'undefined') {
throw new Error('unsupported: DecompressionStream API absente de ce navigateur, impossible de valider ce fichier .gz');
}
let text;
try {
const ds = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
text = await new Response(ds).text();
} catch (err) {
throw new Error('invalid-gzip: le fichier .gz sélectionné est corrompu ou illisible (' + err.message + ')');
}
try {
JSON.parse(text);
} catch (err) {
throw new Error('invalid-json: le fichier .gz sélectionné ne contient pas un JSON valide');
}
await uploadLangGzBlob(code, new Blob([bytes]));
return;
}
let text;
try {
text = new TextDecoder('utf-8').decode(bytes);
} catch (err) {
throw new Error('read-failed: impossible de lire le fichier sélectionné (' + err.message + ')');
}
try {
JSON.parse(text);
} catch (err) {
throw new Error('invalid-json: le fichier sélectionné n\'est pas un JSON valide');
}
const gzBlob = await gzipCompress(text);
await uploadLangGzBlob(code, gzBlob);
}
function updateNetUptimeLabel(mode) {
const key = mode === 'ap' ? 'TOPBAR_NET_AP' : mode === 'eth' ? 'TOPBAR_NET_ETH' : 'TOPBAR_NET_WIFI';
const text = tr(key);
document.querySelectorAll('.net-uptime-label').forEach(el => {
if (el.hasAttribute('title')) el.title = text;
else el.textContent = text;
});
}
function displayUptime(totalSeconds, className) {
const elements = document.querySelectorAll('.' + className);
if (elements.length === 0 || isNaN(totalSeconds)) return;
let seconds = parseInt(totalSeconds, 10);
let days = Math.floor(seconds / (24 * 3600));
seconds %= (24 * 3600);
let hours = Math.floor(seconds / 3600);
seconds %= 3600;
let minutes = Math.floor(seconds / 60);
const fH = hours.toString().padStart(2, '0');
const fM = minutes.toString().padStart(2, '0');
const fS = (seconds % 60).toString().padStart(2, '0');
const timeString = `${days}${tr('UNIT_DAY')} ${fH}${tr('UNIT_HOUR')} ${fM}${tr('UNIT_MIN')} ${fS}${tr('UNIT_SEC')}`;
elements.forEach(el => {
el.textContent = timeString;
});
}
var errors = [
{ code: -10, key: 'ERR_PIN_TRANSCEIVER' },
{ code: -11, key: 'ERR_PIN_ETHERNET' },
{ code: -12, key: 'ERR_PIN_MOTOR' },
{ code: -21, key: 'ERR_GIT_FLASH_WRITE' },
{ code: -22, key: 'ERR_GIT_FLASH_ERASE' },
{ code: -23, key: 'ERR_GIT_FLASH_READ' },
{ code: -24, key: 'ERR_GIT_SPACE' },
{ code: -25, key: 'ERR_GIT_FILE_SIZE' },
{ code: -26, key: 'ERR_GIT_TIMEOUT' },
{ code: -27, key: 'ERR_GIT_MD5' },
{ code: -28, key: 'ERR_GIT_MAGIC_BYTE' },
{ code: -29, key: 'ERR_GIT_ACTIVATE' },
{ code: -30, key: 'ERR_GIT_PARTITION' },
{ code: -31, key: 'ERR_GIT_ARGUMENT' },
{ code: -32, key: 'ERR_GIT_ABORTED' },
{ code: -40, key: 'ERR_GIT_HTTP' },
{ code: -41, key: 'ERR_GIT_BUFFER' },
{ code: -42, key: 'ERR_GIT_CONNECT' },
{ code: -43, key: 'ERR_GIT_DL_TIMEOUT' },
{ code: -46, key: 'ERR_GIT_LOW_HEAP' }
].map(err => {
return {
code: err.code,
key: err.key,
get desc() { return tr(this.key); }
};
});
document.oncontextmenu = (event) => {
if (event.target && event.target.tagName.toLowerCase() === 'input' && (event.target.type.toLowerCase() === 'text' || event.target.type.toLowerCase() === 'password'))
return;
else {
event.preventDefault(); event.stopPropagation(); return false;
}
};
Date.prototype.addMinutes = function (minutes) {
this.setMinutes(this.getMinutes() + minutes);
return this;
};
Date.prototype.toJSON = function () {
const tz = this.getTimezoneOffset();
const sign = tz > 0 ? '-' : '+';
const absTz = Math.abs(tz);
const f = (n, c) => n.toString().padStart(c, '0');
return `${this.getFullYear()}-${f(this.getMonth() + 1, 2)}-${f(this.getDate(), 2)}T${f(this.getHours(), 2)}:${f(this.getMinutes(), 2)}:${f(this.getSeconds(), 2)}.${f(this.getMilliseconds(), 3)}${sign}${f(Math.floor(absTz / 60), 2)}${f(absTz % 60, 2)}`;
};
Date.prototype.fmt = function (fmtMask, emptyMask) {
const mask = fmtMask || 'MM-dd-yyyy HH:mm:ss';
const d = this;
const y = d.getFullYear();
const H = d.getHours();
const m = d.getMonth();
const map = {
yyyy: y,
yy: String(y).slice(-2),
MMMM: formatType.MONTHS[m],
MMM: formatType.MONTHS[m]?.substring(0, 3),
MM: String(m + 1).padStart(2, '0'),
M: m + 1,
dddd: formatType.DAYS[d.getDay()],
ddd: formatType.DAYS[d.getDay()]?.substring(0, 3),
dd: String(d.getDate()).padStart(2, '0'),
d: d.getDate(),
HH: String(H).padStart(2, '0'),
H: H,
hh: String(H % 12 || 12).padStart(2, '0'),
h: (H % 12 || 12),
mm: String(d.getMinutes()).padStart(2, '0'),
m: d.getMinutes(),
ss: String(d.getSeconds()).padStart(2, '0'),
s: d.getSeconds(),
tt: H < 12 ? 'am' : 'pm',
t: H < 12 ? 'a' : 'p'
};
return mask.replace(/yyyy|yy|MMMM|MMM|MM|M|dddd|ddd|dd|d|HH|H|hh|h|mm|m|ss|s|tt|t/g, t => map[t]);
};
Number.prototype.round = function (dec) { return Number(Math.round(this + 'e' + dec) + 'e-' + dec); };
Number.prototype.fmt = function (format, empty) {
if (isNaN(this)) return empty || '';
if (typeof format === 'undefined') return this.toString();
let isNegative = this < 0;
let tok = ['#', '0'];
let pfx = '', sfx = '', fmt = format.replace(/[^#\.0\,]/g, '');
let dec = fmt.lastIndexOf('.') > 0 ? fmt.length - (fmt.lastIndexOf('.') + 1) : 0,
fw = '', fd = '', vw = '', vd = '', rw = '', rd = '';
let val = String(Math.abs(this).round(dec));
let ret = '', commaChar = ',', decChar = '.';
for (var i = 0; i < format.length; i++) {
let c = format.charAt(i);
if (c === '#' || c === '0' || c === '.' || c === ',')
break;
pfx += c;
}
for (let i = format.length - 1; i >= 0; i--) {
let c = format.charAt(i);
if (c === '#' || c === '0' || c === '.' || c === ',')
break;
sfx = c + sfx;
}
if (dec > 0) {
let dp = val.lastIndexOf('.');
if (dp === -1) {
val += '.'; dp = 0;
}
else
dp = val.length - (dp + 1);
while (dp < dec) {
val += '0';
dp++;
}
fw = fmt.substring(0, fmt.lastIndexOf('.'));
fd = fmt.substring(fmt.lastIndexOf('.') + 1);
vw = val.substring(0, val.lastIndexOf('.'));
vd = val.substring(val.lastIndexOf('.') + 1);
let ds = val.substring(val.lastIndexOf('.'), val.length);
for (let i = 0; i < fd.length; i++) {
if (fd.charAt(i) === '#' && vd.charAt(i) !== '0') {
rd += vd.charAt(i);
continue;
} else if (fd.charAt(i) === '#' && vd.charAt(i) === '0') {
var np = vd.substring(i);
if (np.match('[1-9]')) {
rd += vd.charAt(i);
continue;
}
else
break;
}
else if (fd.charAt(i) === '0' || fd.charAt(i) === '#')
rd += vd.charAt(i);
}
if (rd.length > 0) rd = decChar + rd;
}
else {
fw = fmt;
vw = val;
}
var cg = fw.lastIndexOf(',') >= 0 ? fw.length - fw.lastIndexOf(',') - 1 : 0;
var nw = Math.abs(Math.floor(this.round(dec)));
if (!(nw === 0 && fw.substr(fw.length - 1) === '#') || fw.substr(fw.length - 1) === '0') {
var gc = 0;
for (let i = vw.length - 1; i >= 0; i--) {
rw = vw.charAt(i) + rw;
gc++;
if (gc === cg && i !== 0) {
rw = commaChar + rw;
gc = 0;
}
}
if (fw.length > rw.length) {
var pstart = fw.indexOf('0');
if (pstart >= 0) {
var plen = fw.length - pstart;
var pos = fw.length - rw.length - 1;
while (rw.length < plen) {
let pc = fw.charAt(pos);
if (pc === ',') pc = commaChar;
rw = pc + rw;
pos--;
}
}
}
}
if (isNegative) rw = '-' + rw;
if (rd.length === 0 && rw.length === 0) return '';
return pfx + rw + rd + sfx;
};
function computeSunUtcMinutes(lat, lon, date) {
const rad = d => d * Math.PI / 180;
const deg = r => r * 180 / Math.PI;
let y = date.getFullYear(), m = date.getMonth() + 1;
const d = date.getDate();
if (m <= 2) { y -= 1; m += 12; }
const a = Math.floor(y / 100);
const b = 2 - a + Math.floor(a / 4);
const jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
const jc = (jd - 2451545.0) / 36525.0;
let gml = (280.46646 + jc * (36000.76983 + jc * 0.0003032)) % 360.0;
if (gml < 0) gml += 360.0;
const gma = 357.52911 + jc * (35999.05029 - 0.0001537 * jc);
const ecc = 0.016708634 - jc * (0.000042037 + 0.0000001267 * jc);
const gmaRad = rad(gma);
const ctr = Math.sin(gmaRad) * (1.914602 - jc * (0.004817 + 0.000014 * jc))
+ Math.sin(2 * gmaRad) * (0.019993 - 0.000101 * jc)
+ Math.sin(3 * gmaRad) * 0.000289;
const al = gml + ctr - 0.00569 - 0.00478 * Math.sin(rad(125.04 - 1934.136 * jc));
const oe = 23.0 + (26.0 + (21.448 - jc * (46.815 + jc * (0.00059 - jc * 0.001813))) / 60.0) / 60.0;
const oc = oe + 0.00256 * Math.cos(rad(125.04 - 1934.136 * jc));
const decl = deg(Math.asin(Math.sin(rad(oc)) * Math.sin(rad(al))));
const vy = Math.pow(Math.tan(rad(oc / 2.0)), 2);
const eot = 4.0 * deg(
vy * Math.sin(2 * rad(gml))
- 2 * ecc * Math.sin(gmaRad)
+ 4 * ecc * vy * Math.sin(gmaRad) * Math.cos(2 * rad(gml))
- 0.5 * vy * vy * Math.sin(4 * rad(gml))
- 1.25 * ecc * ecc * Math.sin(2 * gmaRad));
const cosH = Math.cos(rad(90.833)) / (Math.cos(rad(lat)) * Math.cos(rad(decl)))
- Math.tan(rad(lat)) * Math.tan(rad(decl));
if (cosH > 1.0 || cosH < -1.0) return null;
const ha = deg(Math.acos(cosH));
const solarNoon = 720.0 - 4.0 * lon - eot;
return { sunriseUtcMinutes: solarNoon - 4.0 * ha, sunsetUtcMinutes: solarNoon + 4.0 * ha };
}
function formatSunTime(utcMinutes) {
if (utcMinutes === undefined || utcMinutes === null || isNaN(utcMinutes)) return '--:--';
const now = new Date();
const totalSeconds = Math.round(utcMinutes * 60);
const flooredMinutes = Math.floor(totalSeconds / 60);
const utcDate = new Date(Date.UTC(
now.getFullYear(),
now.getMonth(),
now.getDate(),
0,
flooredMinutes
));
return utcDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function sunUtcMinutesToLocal(utcMinutes) {
if (utcMinutes === undefined || utcMinutes === null || isNaN(utcMinutes)) return null;
const now = new Date();
const totalSeconds = Math.round(utcMinutes * 60);
const flooredMinutes = Math.floor(totalSeconds / 60);
const utcDate = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate(), 0, flooredMinutes));
return utcDate.getHours() * 60 + utcDate.getMinutes();
}
function formatMinutesOfDay(totalMinutes) {
if (totalMinutes === null || totalMinutes === undefined || isNaN(totalMinutes)) return { main: '--:--', ampm: '' };
totalMinutes = ((totalMinutes % 1440) + 1440) % 1440;
const d = new Date();
d.setHours(Math.floor(totalMinutes / 60), totalMinutes % 60, 0, 0);
const parts = new Intl.DateTimeFormat([], { hour: '2-digit', minute: '2-digit' }).formatToParts(d);
let hour = '', minute = '', ampm = '';
parts.forEach(p => {
if (p.type === 'hour') hour = p.value;
else if (p.type === 'minute') minute = p.value;
else if (p.type === 'dayPeriod') ampm = p.value;
});
return { main: `${hour}:${minute}`, ampm };
}
const SCHEDULE_DAY_DEFS = [
{ bit: 2, key: 'SCHEDULE_MON' }, { bit: 4, key: 'SCHEDULE_TUE' }, { bit: 8, key: 'SCHEDULE_WED' },
{ bit: 16, key: 'SCHEDULE_THU' }, { bit: 32, key: 'SCHEDULE_FRI' }, { bit: 64, key: 'SCHEDULE_SAT' }, { bit: 1, key: 'SCHEDULE_SUN' }
];
function makeBool(val) {
if (typeof val === 'boolean') return val;
if (typeof val === 'undefined') return false;
if (typeof val === 'number') return val >= 1;
if (typeof val === 'string') {
if (val === '') return false;
switch (val.toLowerCase().trim()) {
case 'on':
case 'true':
case 'yes':
case 'y':
return true;
case 'off':
case 'false':
case 'no':
case 'n':
return false;
}
if (!isNaN(parseInt(val, 10))) return parseInt(val, 10) >= 1;
}
return false;
}
var httpStatusText = {
'200': 'OK',
'201': 'Created',
'202': 'Accepted',
'203': 'Non-Authoritative Information',
'204': 'No Content',
'205': 'Reset Content',
'206': 'Partial Content',
'300': 'Multiple Choices',
'301': 'Moved Permanently',
'302': 'Found',
'303': 'See Other',
'304': 'Not Modified',
'305': 'Use Proxy',
'306': 'Unused',
'307': 'Temporary Redirect',
'400': 'Bad Request',
'401': 'Unauthorized',
'402': 'Payment Required',
'403': 'Forbidden',
'404': 'Not Found',
'405': 'Method Not Allowed',
'406': 'Not Acceptable',
'407': 'Proxy Authentication Required',
'408': 'Request Timeout',
'409': 'Conflict',
'410': 'Gone',
'411': 'Length Required',
'412': 'Precondition Required',
'413': 'Request Entry Too Large',
'414': 'Request-URI Too Long',
'415': 'Unsupported Media Type',
'416': 'Requested Range Not Satisfiable',
'417': 'Expectation Failed',
'418': 'I\'m a teapot',
'429': 'Too Many Requests',
'500': 'Internal Server Error',
'501': 'Not Implemented',
'502': 'Bad Gateway',
'503': 'Service Unavailable',
'504': 'Gateway Timeout',
'505': 'HTTP Version Not Supported'
};
function noteAuthFailure(err) {
if (!err || err.htmlError !== 401) return;
if (typeof security !== 'undefined' && security.handleUnauthorized) security.handleUnauthorized();
}
function _xhrError(xhr, method, url, data) {
let err = xhr.response || {};
if (typeof err !== 'object' || err === null) err = {};
err.htmlError = xhr.status || 500;
err.service = `${method} ${url}`;
if (typeof data !== 'undefined') err.data = data;
if (typeof err.desc === 'undefined') err.desc = xhr.statusText || httpStatusText[xhr.status || 500];
noteAuthFailure(err);
return err;
}
function deviceFetch(url, opts) {
const options = Object.assign({}, opts);
options.headers = Object.assign({}, options.headers, { apikey: (typeof security !== 'undefined' ? security.apiKey : '') || '' });
const service = `${(options.method || 'GET').toUpperCase()} ${url}`;
return fetch(baseUrl + url, options).then(resp => {
return resp.text().then(txt => {
if (!resp.ok) {
let err = {};
try { err = txt ? JSON.parse(txt) : {}; } catch (e) { }
err.htmlError = resp.status;
err.service = service;
if (typeof err.desc === 'undefined') err.desc = resp.statusText || httpStatusText[resp.status] || httpStatusText['500'];
noteAuthFailure(err);
throw err;
}
if (!txt) return {};
try { return JSON.parse(txt); }
catch (e) { throw { htmlError: resp.status, service: service, desc: httpStatusText['500'] }; }
});
});
}
function getJSON(url, cb) {
let xhr = new XMLHttpRequest();
logger.debug('GET', url);
xhr.open('GET', baseUrl.length > 0 ? `${baseUrl}${url}` : url, true);
xhr.setRequestHeader('apikey', security.apiKey);
xhr.responseType = 'json';
xhr.onload = () => {
if (xhr.status !== 200) cb(_xhrError(xhr, 'GET', url), null);
else cb(null, xhr.response);
};
xhr.onerror = () => cb(_xhrError(xhr, 'GET', url), null);
xhr.send();
}
function getJSONSync(url, cb) {
let overlay = ui.waitMessage(get('divContainer'), 'WAIT_MSG_LOADING');
try {
let xhr = new XMLHttpRequest();
logger.debug('GET', url);
xhr.responseType = 'json';
xhr.onload = () => {
if (xhr.status !== 200) cb(_xhrError(xhr, 'GET', url), null);
else cb(null, xhr.response);
overlay.remove();
};
xhr.onerror = () => {
cb(_xhrError(xhr, 'GET', url), null);
overlay.remove();
};
xhr.onabort = () => overlay.remove();
xhr.open('GET', baseUrl.length > 0 ? `${baseUrl}${url}` : url, true);
xhr.setRequestHeader('apikey', security.apiKey);
xhr.send();
} catch (err) { ui.serviceError(get('divContainer'), err); }
}
function postJSONSync(url, data, cb) {
let overlay = ui.waitMessage(get('divContainer'), 'WAIT_MSG_SAVING');
try {
let xhr = new XMLHttpRequest();
logger.debug('POST', url, data);
let fd = new FormData();
for (let name in data) {
fd.append(name, data[name]);
}
xhr.open('POST', baseUrl.length > 0 ? `${baseUrl}${url}` : url, true);
xhr.responseType = 'json';
xhr.setRequestHeader('Accept', 'application/json');
xhr.setRequestHeader('apikey', security.apiKey);
xhr.onload = () => {
if (xhr.status !== 200) cb(_xhrError(xhr, 'POST', url, data), null);
else cb(null, xhr.response);
overlay.remove();
};
xhr.onerror = () => {
logger.error('POST failed:', url, xhr.status, xhr.statusText);
cb(_xhrError(xhr, 'POST', url, data), null);
overlay.remove();
};
xhr.send(fd);
} catch (err) { ui.serviceError(get('divContainer'), err); }
}
function putJSON(url, data, cb) {
let xhr = new XMLHttpRequest();
logger.debug('PUT', url, data);
xhr.open('PUT', baseUrl.length > 0 ? `${baseUrl}${url}` : url, true);
xhr.responseType = 'json';
xhr.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
xhr.setRequestHeader('Accept', 'application/json');
xhr.setRequestHeader('apikey', security.apiKey);
xhr.onload = () => {
if (xhr.status !== 200) cb(_xhrError(xhr, 'PUT', url, data), null);
else cb(null, xhr.response);
};
xhr.onerror = () => {
logger.error('PUT failed:', url, xhr.status, xhr.statusText);
cb(_xhrError(xhr, 'PUT', url, data), null);
};
xhr.send(JSON.stringify(data));
}
function putJSONSync(url, data, cb) {
let overlay = ui.waitMessage(get('divContainer'), 'WAIT_MSG_SAVING');
try {
let xhr = new XMLHttpRequest();
logger.debug('PUT', url, data);
xhr.open('PUT', baseUrl.length > 0 ? `${baseUrl}${url}` : url, true);
xhr.responseType = 'json';
xhr.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
xhr.setRequestHeader('Accept', 'application/json');
xhr.setRequestHeader('apikey', security.apiKey);
xhr.onload = () => {
if (xhr.status !== 200) cb(_xhrError(xhr, 'PUT', url, data), null);
else cb(null, xhr.response);
overlay.remove();
};
xhr.onerror = () => {
logger.error('PUT failed:', url, xhr.status, xhr.statusText);
cb(_xhrError(xhr, 'PUT', url, data), null);
overlay.remove();
};
xhr.send(JSON.stringify(data));
} catch (err) { ui.serviceError(get('divContainer'), err); }
}
var socket;
var tConnect = null;
var sockIsOpen = false;
var connecting = false;
var connects = 0;
var connectFailed = 0;
const RE_ISO_DATE = /^(\d{4}|\+010000)-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*))(?:Z|(\+|-)([\d|:]*))?$/;
const RE_MSAJAX_DATE = /^\/Date\((d|-|.*)\)[\/|\\]$/;
async function initSockets() {
if (connecting) return;
logger.debug('Connecting to socket...');
connecting = true;
if (tConnect) clearTimeout(tConnect);
tConnect = null;
let wms = document.getElementsByClassName('socket-wait');
for (let i = 0; i < wms.length; i++) {
wms[i].remove();
}
ui.waitMessage(get('divContainer'), 'WAIT_MSG_CONNECTING').classList.add('socket-wait');
let host = isDevHost ? hst : window.location.hostname;
try {
const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
const port = window.location.protocol === 'https:' ? '' : ':8080';
const key = (typeof security !== 'undefined' && security.apiKey) ? security.apiKey : '';
const query = key ? `?apikey=${encodeURIComponent(key)}` : '';
socket = new WebSocket(`${protocol}//${host}${port}/${query}`);
socket.onmessage = (evt) => {
if (evt.data.startsWith('42')) {
let ndx = evt.data.indexOf(',');
let eventName = evt.data.substring(3, ndx);
let data = evt.data.substring(ndx + 1, evt.data.length - 1);
try {
var msg = JSON.parse(data, (key, value) => {
if (typeof value === 'string') {
var a = RE_ISO_DATE.exec(value);
if (a) return new Date(value);
a = RE_MSAJAX_DATE.exec(value);
if (a) {
var b = a[1].split(/[-+,.]/);
return new Date(b[0] ? +b[0] : 0 - +b[1]);
}
}
return value;
});
switch (eventName) {
case 'memStatus':
firmware.procMemoryStatus(msg);
break;
case 'updateProgress':
firmware.procUpdateProgress(msg);
break;
case 'fwStatus':
firmware.procFwStatus(msg);
break;
case 'gitLangRestore':
firmware.procLangRestore(msg);
break;
case 'langDownloadProgress':
general.procLangDownloadProgress(msg);
break;
case 'langDownloadComplete':
general.procLangDownloadComplete(msg);
break;
case 'remoteFrame':
somfy.procRemoteFrame(msg);
break;
case 'rfNoise':
somfy.procRfNoise(msg);
break;
case 'groupState':
somfy.procGroupState(msg);
break;
case 'shadeState':
somfy.procShadeState(msg);
break;
case 'shadeCommand':
logger.debug('Shade command received:', msg);
break;
case 'roomRemoved':
somfy.procRoomRemoved(msg);
break;
case 'roomAdded':
somfy.procRoomAdded(msg);
break;
case 'shadeRemoved':
break;
case 'shadeAdded':
break;
case 'ethernet':
wifi.procEthernet(msg);
break;
case 'wifiStrength':
wifi.procWifiStrength(msg);
break;
case 'packetPulses':
logger.debug('RF packet pulses:', msg);
break;
case 'frequencyScan':
somfy.procFrequencyScan(msg);
break;
case 'radioActivity':
somfy.pulseRadioActivity();
break;
}
} catch (err) {
logger.error('Error processing socket event', eventName, err);
}
}
};
socket.onopen = (evt) => {
if (tConnect) clearTimeout(tConnect);
tConnect = null;
logger.debug('Socket connected');
if (evt.target && evt.target.url && evt.target.url.includes('192.168.4.1')) {
logger.debug("Hotspot mode detected (192.168.4.1)");
wifi.isHotspot = true;
document.body.classList.add('mode-hotspot');
} else {
wifi.isHotspot = false;
document.body.classList.remove('mode-hotspot');
}
sockIsOpen = true;
connecting = false;
connects++;
connectFailed = 0;
let wms = document.getElementsByClassName('socket-wait');
for (let i = 0; i < wms.length; i++) {
wms[i].remove();
}
let errs = document.getElementsByClassName('socket-error');
for (let i = 0; i < errs.length; i++)
errs[i].remove();
if (general.reloadApp) {
general.reload();
}
else {
(async () => {
ui.clearErrors();
const configOnly = (security.permissions & 0x01) === 0x01;
const dashboardAccessible = security.type === 0 || security.authenticated || configOnly;
const configAccessible = security.type === 0 || security.authenticated;
if (dashboardAccessible) {
await general.loadGeneral();
await somfy.loadSomfy();
}
if (configAccessible) {
await wifi.loadNetwork();
await mqtt.loadMQTT();
}
if (ui.isConfigOpen()) socket.send('join:0');
})();
}
};
socket.onclose = (evt) => {
wifi.procWifiStrength({ ssid: '', channel: -1, strength: -100 });
wifi.procEthernet({ connected: false, speed: 0, fullduplex: false });
if (document.getElementsByClassName('socket-wait').length === 0)
ui.waitMessage(get('divContainer'), 'WAIT_MSG_CONNECTING').classList.add('socket-wait');
if (evt.wasClean) {
logger.debug('Socket closed cleanly');
connectFailed = 0;
tConnect = setTimeout(async () => { await reopenSocket(); }, 7000);
logger.debug('Reconnecting socket in 7 seconds');
}
else {
logger.warn('Socket closed unexpectedly, reconnecting...', evt.reason);
if (connects > 0) {
logger.debug('Reconnecting socket in 3 seconds');
tConnect = setTimeout(async () => { await reopenSocket(); }, 3000);
}
else {
if (connecting) {
connectFailed++;
let timeout = Math.min(connectFailed * 500, 10000);
logger.debug(`Initial socket did not connect try again (server was busy and timed out ${connectFailed} times)`);
tConnect = setTimeout(async () => { await reopenSocket(); }, timeout);
if (connectFailed === 5) {
ui.socketError(trOr('ERR_SOCKET_TOO_MANY',
'Too many clients connected. A maximum of {MAX} clients may be connected at any one time. Close some connections to the ESP Somfy RTS device to proceed.')
.replace('{MAX}', window.__maxClients || '?'));
}
let spanAttempts = get('spanSocketAttempts');
if (spanAttempts) spanAttempts.innerHTML = connectFailed.fmt("#,##0");
}
else {
logger.debug('Connecting socket in .5 seconds');
tConnect = setTimeout(async () => { await reopenSocket(); }, 500);
}
}
}
connecting = false;
};
socket.onerror = (evt) => {
logger.warn('Socket error', evt);
};
} catch (err) {
logger.error('Failed to open WebSocket connection', err);
tConnect = setTimeout(async () => { await reopenSocket(); }, 5000);
}
}
function shOverlay(div, onClose) {
if (!div) return;
const btn = div.querySelector('[close]');
if (btn) btn.onclick = () => requestCloseOverlay(div, onClose);
if (div.classList.contains('modal-overlay')) {
document.body.classList.add('modal-open');
} else {
window.scrollTo(0, 0);
}
get('divContainer').appendChild(div);
void div.offsetWidth;
div.classList.add('overlay-entered');
}
const closeOverlay = (div, callback) => {
if (!div) return;
div.classList.add('overlay-exit');
setTimeout(() => {
div.remove();
const remainingModal = document.querySelector('.modal-overlay:not(.overlay-exit)');
if (!remainingModal) {
document.body.classList.remove('modal-open');
}
if (typeof div._onClosed === 'function') div._onClosed();
if (typeof callback === 'function') callback();
}, 300);
};
function handleMobileDismiss(handleElement) {
const topOverlay = handleElement.closest('.modal-overlay, .inst-overlay');
if (topOverlay) {
requestCloseOverlay(topOverlay);
}
}
document.addEventListener('click', (e) => {
const overlay = e.target.closest('.modal-overlay, .inst-overlay');
if (!overlay) return;
if (e.target.closest('.message-content, .instructions-content')) return;
if (overlay.querySelector('.prompt-content, .error-content, .info-content')) return;
requestCloseOverlay(overlay);
});
function clearOverlays() {
const selectors = ['.inst-overlay', '.modal-overlay', '.instructions', '#divGitInstall'];
selectors.forEach(s => document.querySelectorAll(s).forEach(el => {
if (el.dataset.lockMode === 'hard') return;
el.remove();
}));
document.body.classList.remove('modal-open');
}
function syncSliderProgress(el) {
const progress = el.previousElementSibling;
if (!progress || !progress.classList.contains('slider-progress')) return;
const min = parseFloat(el.min) || 0;
const max = parseFloat(el.max) || 100;
const pct = max > min ? ((parseFloat(el.value) - min) / (max - min)) * 100 : 0;
const clampedPct = Math.min(100, Math.max(0, pct));
progress.style.width = `${clampedPct}%`;
progress.style.setProperty('--pct', clampedPct);
}
function sliderDragStart(el) {
el.dataset.dragging = 'true';
}
function sliderDragEnd(el) {
el.dataset.dragging = 'false';
}
['pointerup', 'pointercancel'].forEach(evt => {
window.addEventListener(evt, () => {
document.querySelectorAll('[data-dragging="true"]').forEach(el => sliderDragEnd(el));
}, true);
});
let isDirty = false;
const _dirtyWatchContainers = new Set();
function _markDirty(evt) {
const el = evt.target;
if (!el || !el.classList) return;
el.classList.add('is-dirty');
isDirty = true;
}
function _recomputeIsDirty() {
isDirty = !!document.querySelector('.is-dirty');
}
function watchDirty(container) {
if (!container) return;
if (!_dirtyWatchContainers.has(container)) {
_dirtyWatchContainers.add(container);
container.addEventListener('input', _markDirty);
container.addEventListener('change', _markDirty);
}
container.querySelectorAll('.is-dirty').forEach(el => el.classList.remove('is-dirty'));
_recomputeIsDirty();
}
function clearDirty(container) {
if (container) {
container.querySelectorAll('.is-dirty').forEach(el => el.classList.remove('is-dirty'));
_recomputeIsDirty();
if (!isDirty) document.body.classList.remove('dirty-alerted');
return;
}
_dirtyWatchContainers.forEach(c => c.querySelectorAll('.is-dirty').forEach(el => el.classList.remove('is-dirty')));
document.body.classList.remove('dirty-alerted');
isDirty = false;
}
function confirmDiscardChanges(onLeave, onStay, options) {
const opts = options || {};
const scope = opts.scope || null;
const scopeDirty = scope ? !!scope.querySelector('.is-dirty') : isDirty;
if (!scopeDirty && !opts.force) { onLeave(); return; }
if (scopeDirty) document.body.classList.add('dirty-alerted');
const titleKey = opts.titleKey || 'PROMPT_UNSAVED_TITLE';
const msgKey = opts.msgKey || 'PROMPT_UNSAVED_MSG';
const icon = opts.icon || (opts.force ? 'svg-warning' : 'svg-info');
const type = opts.type || (opts.force ? 'small danger' : 'small');
let div = document.createElement('div');
div.className = 'modal-overlay';
div.innerHTML = `
    <div class="message-content prompt-content">
    ${modalHeader(titleKey, icon, { type: type })}
    <div class="sub-message"><p>${tr(msgKey)}</p></div>
    <div class="button-container-row">
    <button id="btnUnsavedStay" line type="button">${tr('BT_STAY_PAGE')}</button>
    <button id="btnUnsavedLeave" red type="button"><span>${tr('BT_LEAVE_WITHOUT_SAVING')}</span></button>
    </div>
    </div>`;
shOverlay(div);
div.querySelector('#btnUnsavedStay').onclick = () => {
closeOverlay(div);
if (typeof onStay === 'function') onStay();
};
div.querySelector('#btnUnsavedLeave').onclick = () => {
if (typeof general !== 'undefined' && typeof general.revertClientPreviews === 'function') general.revertClientPreviews(scope);
clearDirty(scope || undefined);
closeOverlay(div);
onLeave();
};
}
function markCriticalStepReached(div, criticalStep) {
div.addEventListener('stepchanged', (e) => {
if (e.detail.newStep >= criticalStep) div.setAttribute('data-radio-committed', 'true');
});
}
const CRITICAL_STEP_OVERLAY_IDS = ['divPairing', 'divLinkGroup', 'divUnlinkGroup', 'divCalibration'];
function criticalStepGuard(overlay) {
if (!overlay) return null;
if (CRITICAL_STEP_OVERLAY_IDS.includes(overlay.id) && overlay.getAttribute('data-radio-committed') === 'true') {
return { force: true, titleKey: 'PROMPT_RADIO_PROCEDURE_TITLE', msgKey: 'PROMPT_RADIO_PROCEDURE_MSG' };
}
return null;
}
function anyCriticalStepPending() {
return CRITICAL_STEP_OVERLAY_IDS.some(id => {
const el = document.getElementById(id);
return el && el.getAttribute('data-radio-committed') === 'true';
});
}
function setOverlayLock(div, mode, opts = {}) {
if (!div) return;
div.dataset.lockMode = mode;
div.dataset.lockTitleKey = opts.titleKey || 'PROMPT_ACTION_IN_PROGRESS_TITLE';
div.dataset.lockMsgKey = opts.msgKey || 'PROMPT_ACTION_IN_PROGRESS_MSG';
div._onLockedLeave = typeof opts.onConfirm === 'function' ? opts.onConfirm : null;
}
function clearOverlayLock(div) {
if (!div) return;
delete div.dataset.lockMode;
delete div.dataset.lockTitleKey;
delete div.dataset.lockMsgKey;
div._onLockedLeave = null;
}
function overlayLockGuard(overlay) {
if (!overlay || !overlay.dataset.lockMode) return null;
return {
hard: overlay.dataset.lockMode === 'hard',
force: true,
titleKey: overlay.dataset.lockTitleKey,
msgKey: overlay.dataset.lockMsgKey,
};
}
function flashOverlayLocked(overlay) {
const target = overlay.querySelector('.message-content, .instructions-content') || overlay;
target.classList.remove('overlay-locked-shake');
void target.offsetWidth;
target.classList.add('overlay-locked-shake');
showLockedInfo(overlay);
}
function showLockedInfo(overlay) {
if (typeof ui === 'undefined' || typeof ui.infoMessage !== 'function') return;
const titleKey = overlay.dataset.lockTitleKey || 'PROMPT_ACTION_IN_PROGRESS_TITLE';
const msgKey = overlay.dataset.lockMsgKey || 'PROMPT_ACTION_IN_PROGRESS_MSG';
ui.infoMessage(titleKey, msgKey);
}
function anyHardLockPending() {
return !!document.querySelector('[data-lock-mode="hard"]');
}
function requestCloseOverlay(overlay, onClose) {
if (!overlay) return;
const lock = overlayLockGuard(overlay);
if (lock && lock.hard) { flashOverlayLocked(overlay); return; }
confirmDiscardChanges(() => {
if (typeof overlay._onLockedLeave === 'function') overlay._onLockedLeave();
closeOverlay(overlay, onClose);
}, null, Object.assign({}, criticalStepGuard(overlay) || lock || {}, { scope: overlay }));
}
window.appInitiatedReload = function() {
window.__appReloading = true;
window.location.reload(true);
};
window.addEventListener('beforeunload', (e) => {
if (window.__appReloading) return;
if (!isDirty && !anyCriticalStepPending() && !anyHardLockPending()) return;
e.preventDefault();
e.returnValue = '';
});
const ROUTE_TOP_LEVEL_IDS = new Set(['divSystemSettings', 'divNetworkSettings', 'divSomfySettings', 'divRadioSettings']);
function _resolveDefaultChild(grpid) {
if (!ROUTE_TOP_LEVEL_IDS.has(grpid)) return grpid;
const subtabContainer = get('subtabContainer-' + grpid);
const firstSpan = subtabContainer ? subtabContainer.querySelector('span[data-grpid]') : null;
return firstSpan ? firstSpan.getAttribute('data-grpid') : grpid;
}
const ROUTE_LEAF_PARENT = {
divSystemOptions: 'divSystemSettings',
divFirmware: 'divSystemSettings',
divNetAdapter: 'divNetworkSettings',
divMQTT: 'divNetworkSettings',
divSomfyRooms: 'divSomfySettings',
divSomfyMotors: 'divSomfySettings',
divSomfyGroups: 'divSomfySettings',
divRepeater: 'divSomfySettings',
divSomfySchedules: 'divSomfySettings',
divTransceiverSettings: 'divRadioSettings',
divFrameLog: 'divRadioSettings',
};
const ROUTE_SLUGS = {
divHomePnl: 'dashboard',
divSystemOptions: 'general',
divFirmware: 'firmware',
divNetAdapter: 'connection',
divMQTT: 'mqtt',
divSomfyRooms: 'rooms',
divSomfyMotors: 'shades',
divSomfyGroups: 'groups',
divRepeater: 'repeaters',
divSomfySchedules: 'schedules',
divTransceiverSettings: 'radio',
divFrameLog: 'radio-logs',
};
const ROUTE_SLUG_TO_GRPID = Object.fromEntries(Object.entries(ROUTE_SLUGS).map(([id, slug]) => [slug, id]));
const ROUTE_EDITORS = {
divSomfyMotors: {
open: (editorId, opts) => somfy._openEditShade(editorId === 'new' ? undefined : editorId, opts),
label: (editorId) => {
if (editorId === 'new') return tr('SHADE_CREATE_TITLE');
const shade = (somfy.shades || []).find(x => x.shadeId === editorId);
return shade ? shade.name : '';
},
},
divSomfyGroups: {
open: (editorId, opts) => somfy._openEditGroup(editorId === 'new' ? undefined : editorId, opts),
label: (editorId) => {
if (editorId === 'new') return tr('GROUP_CREATE_TITLE');
const group = (somfy.groups || []).find(x => x.groupId === editorId);
return group ? group.name : '';
},
},
divSomfySchedules: {
open: (editorId, opts) => somfy._openEditSchedule(editorId === 'new' ? undefined : editorId, undefined, false, opts),
label: (editorId) => {
if (editorId === 'new') return tr('SCHEDULE_CREATE_TITLE');
const schedule = (somfy.schedules || []).find(x => x.id === editorId);
return schedule ? somfy.scheduleLabel(schedule) : '';
},
},
};
function _routeSlug(leafId, editorId) {
const base = ROUTE_SLUGS[leafId] || 'dashboard';
return (editorId == null || !ROUTE_EDITORS[leafId]) ? base : `${base}/${editorId}`;
}
function _parseRoute(hash) {
const raw = (hash || '').replace(/^#/, '');
const sep = raw.indexOf('/');
const slug = sep === -1 ? raw : raw.slice(0, sep);
const param = sep === -1 ? '' : raw.slice(sep + 1);
const grpid = ROUTE_SLUG_TO_GRPID[slug];
if (!grpid) return { grpid: 'divHomePnl', editor: null };
if (!param || !ROUTE_EDITORS[grpid]) return { grpid: grpid, editor: null };
if (param === 'new') return { grpid: grpid, editor: 'new' };
return { grpid: grpid, editor: /^\d+$/.test(param) ? parseInt(param, 10) : null };
}
let isApplyingHash = false;
let currentSlug = 'dashboard';
let currentLeafId = null;
let isRouting = false;
function _setBreadcrumbLink(el, targetGrpid) {
if (!el) return;
if (targetGrpid) {
el.classList.add('section-breadcrumb-link');
el.setAttribute('data-grpid', targetGrpid);
el.setAttribute('role', 'link');
el.setAttribute('tabindex', '0');
}
else {
el.classList.remove('section-breadcrumb-link');
el.removeAttribute('data-grpid');
el.removeAttribute('role');
el.removeAttribute('tabindex');
}
}
function _updateBreadcrumb(topId, leafId, detailLabel = null) {
const bc = get('divSectionBreadcrumb');
if (!bc) return;
const parentEl = bc.querySelector('.section-breadcrumb-parent');
const activeEl = bc.querySelector('.section-breadcrumb-active');
const detailEl = bc.querySelector('.section-breadcrumb-detail');
if (topId === 'divHomePnl') {
parentEl.textContent = '';
activeEl.textContent = '';
if (detailEl) detailEl.textContent = '';
bc.removeAttribute('data-depth');
_setBreadcrumbLink(parentEl, null);
_setBreadcrumbLink(activeEl, null);
return;
}
const topLabel = document.querySelector(`.nav-item[data-grpid="${topId}"] span`)?.textContent.trim() || '';
const leafLabel = document.querySelector(`.subtab-container > span[data-grpid="${leafId}"]`)?.textContent.trim() || '';
parentEl.textContent = topLabel;
activeEl.textContent = (leafLabel && leafLabel !== topLabel) ? leafLabel : '';
const inEditor = detailLabel !== null;
if (detailEl) detailEl.textContent = inEditor ? (detailLabel || '') : '';
bc.setAttribute('data-depth', inEditor ? '3' : (activeEl.textContent ? '2' : '1'));
_setBreadcrumbLink(parentEl, (inEditor || leafId !== _resolveDefaultChild(topId)) ? topId : null);
_setBreadcrumbLink(activeEl, (inEditor && activeEl.textContent) ? leafId : null);
}
function whenSomfyDataReady(cb, onGiveUp) {
let waited = 0;
const tick = () => {
if (typeof somfy !== 'undefined' && somfy.dataLoaded) return cb();
waited += 100;
if (waited >= 10000) {
if (typeof onGiveUp === 'function') onGiveUp();
return;
}
setTimeout(tick, 100);
};
setTimeout(tick, 0);
}
function routeSetEditor(leafId, editorId, opts) {
const o = opts || {};
if (isRouting || leafId !== currentLeafId || !ROUTE_EDITORS[leafId]) return;
const slug = _routeSlug(leafId, editorId);
const wasNew = currentSlug === _routeSlug(leafId, 'new');
if (slug !== currentSlug) {
currentSlug = slug;
if (location.hash.slice(1) !== slug) {
if (o.replace || (wasNew && editorId != null)) history.replaceState(null, '', location.pathname + location.search + '#' + slug);
else {
isApplyingHash = true;
location.hash = slug;
}
}
}
const label = (editorId == null) ? null : (o.label || ROUTE_EDITORS[leafId].label(editorId));
_updateBreadcrumb(ROUTE_LEAF_PARENT[leafId] || leafId, leafId, label);
}
function activateGrpid(grpid, opts) {
isRouting = true;
try { return _activateGrpid(grpid, opts || {}); }
finally { isRouting = false; }
}
function _activateGrpid(grpid, { updateHash = true, editor = null } = {}) {
if (isApMode && !window.__onboardingDone) return 'dashboard';
if (!grpid || !get(grpid)) grpid = 'divHomePnl';
const leafId = _resolveDefaultChild(grpid);
const topId = (leafId === 'divHomePnl') ? 'divHomePnl' : (ROUTE_LEAF_PARENT[leafId] || leafId);
const isDashboard = (topId === 'divHomePnl');
let activeEditor = null;
if (!isDashboard && typeof security !== 'undefined' && !security.authenticated && security.type !== 0) {
get('divContainer').addEventListener('afterlogin', () => {
if (security.authenticated) activateGrpid(grpid, { updateHash, editor });
}, { once: true });
security.authUser();
return _routeSlug(leafId, editor);
}
clearOverlays();
if (isDashboard) {
if (typeof security !== 'undefined' && security.type !== 0 && !security.authenticated) {
const configOnly = (security.permissions & 0x01) === 0x01;
if (!configOnly) {
security.authUser();
return 'dashboard';
}
get('divUnauthenticated').style.display = 'none';
get('divAuthenticated').style.display = '';
}
const divCfg = get('divConfigPnl'), header = get('appHeader');
if (header) header.style.display = '';
if (divCfg) divCfg.style.display = 'none';
somfy.checkEmptyState();
if (sockIsOpen) socket.send('leave:0');
general.setSecurityConfig({ type: 0, username: '', password: '', pin: '', permissions: 0 });
somfy.showEditShade(false);
somfy.showEditGroup(false);
document.querySelectorAll('.nav-item[data-grpid]').forEach(i => i.classList.toggle('active', i.getAttribute('data-grpid') === 'divHomePnl'));
document.querySelectorAll('.nav-group .submenu').forEach(s => { s.style.display = 'none'; });
document.querySelectorAll('.sub-nav-item[data-grpid]').forEach(i => i.classList.remove('active'));
currentLeafId = 'divHomePnl';
_updateBreadcrumb('divHomePnl', null);
} else {
const wasClosed = window.getComputedStyle(get('divConfigPnl')).display === 'none';
const divCfg = get('divConfigPnl'), divHome = get('divHomePnl'), header = get('appHeader');
if (divHome) divHome.style.display = 'none';
if (header) header.style.display = 'none';
if (divCfg) divCfg.style.display = '';
somfy.checkEmptyState();
if (wasClosed) {
if (sockIsOpen) socket.send('join:0');
let overlay = ui.waitMessage(get('divSystemOptions'));
if (overlay) {
overlay.style.borderRadius = '5px';
getJSON('/getSecurity', (err, sec) => {
overlay.remove();
if (err) ui.serviceError(err);
else general.setSecurityConfig(sec);
});
}
}
if (typeof somfy !== 'undefined') {
somfy.showEditShade(false);
somfy.showEditGroup(false);
}
if (topId === 'divNetworkSettings' && typeof wifi !== 'undefined') wifi.loadNetwork();
document.querySelectorAll('.nav-item[data-grpid]').forEach(i => i.classList.toggle('active', i.getAttribute('data-grpid') === topId));
document.querySelectorAll('.nav-group .submenu').forEach(s => {
s.style.display = (s.previousElementSibling?.getAttribute('data-grpid') === topId) ? 'flex' : 'none';
});
document.querySelectorAll('.tab-container > span[data-grpid]').forEach(t => {
const id = t.getAttribute('data-grpid');
t.classList.toggle('selected', id === topId);
const panel = get(id);
if (panel) panel.style.display = (id === topId) ? '' : 'none';
});
document.querySelectorAll('.sub-nav-item[data-grpid]').forEach(i => i.classList.toggle('active', i.getAttribute('data-grpid') === leafId));
document.querySelectorAll('.subtab-container > span[data-grpid]').forEach(t => {
const id = t.getAttribute('data-grpid');
t.classList.toggle('selected', id === leafId);
const panel = get(id);
if (panel) panel.style.display = (id === leafId) ? '' : 'none';
});
currentLeafId = leafId;
if (ROUTE_EDITORS[leafId] && editor != null) activeEditor = editor;
_updateBreadcrumb(topId, leafId, activeEditor == null ? null : ROUTE_EDITORS[leafId].label(activeEditor));
_mountMobileSubtab(topId);
}
if (typeof somfy !== 'undefined') {
if (leafId === 'divTransceiverSettings') somfy.refreshRadio();
if (leafId === 'divFrameLog') somfy.showFrameLog();
else somfy.frameLogVisible = false;
}
const slug = _routeSlug(leafId, activeEditor);
currentSlug = slug;
if (updateHash && location.hash.slice(1) !== slug) {
isApplyingHash = true;
location.hash = slug;
}
if (activeEditor != null) {
const cfg = ROUTE_EDITORS[leafId];
whenSomfyDataReady(() => { if (currentLeafId === leafId) cfg.open(activeEditor, { silentError: true }); }, () => routeSetEditor(leafId, null, { replace: true }));
}
return slug;
}
function _mountMobileSubtab(topId) {
const slot = get('divMobileSubtabSlot');
if (!slot) return;
Array.from(slot.children).forEach(child => {
const ownerGrpid = child.id.replace('subtabContainer-', '');
const owner = get(ownerGrpid);
if (owner) owner.prepend(child);
});
const subtab = get('subtabContainer-' + topId);
if (subtab) slot.appendChild(subtab);
}
function bindMobileUptimeTooltip() {
const chip = get('mobileUptime');
if (!chip) return;
chip.addEventListener('click', (e) => {
if (e.target.closest('.uptime-tooltip')) return;
chip.classList.toggle('uptime-open');
});
document.addEventListener('click', (e) => {
if (!chip.contains(e.target)) chip.classList.remove('uptime-open');
});
}
let scheduleIndicatorHideTimer = null;
function getScheduleIndicatorPopover() {
let pop = get('scheduleIndicatorPopover');
if (!pop) {
pop = document.createElement('div');
pop.id = 'scheduleIndicatorPopover';
pop.className = 'schedule-popover';
pop.addEventListener('mouseenter', () => {
if (scheduleIndicatorHideTimer) { clearTimeout(scheduleIndicatorHideTimer); scheduleIndicatorHideTimer = null; }
});
pop.addEventListener('mouseleave', () => hideScheduleIndicatorPopover());
document.body.appendChild(pop);
}
return pop;
}
function hideScheduleIndicatorPopover() {
const pop = get('scheduleIndicatorPopover');
if (pop) { pop.classList.remove('open'); pop.removeAttribute('data-for'); }
}
function showScheduleIndicatorPopover(indicatorEl) {
const targetType = indicatorEl.getAttribute('data-schedule-target');
const targetId = parseInt(indicatorEl.getAttribute('data-schedule-id'), 10);
if (!targetType || isNaN(targetId)) return;
const pop = getScheduleIndicatorPopover();
pop.innerHTML = somfy._buildScheduleTooltipHtml(targetType, targetId);
pop.setAttribute('data-for', `${targetType}:${targetId}`);
pop.classList.add('open');
const rect = indicatorEl.getBoundingClientRect();
const popRect = pop.getBoundingClientRect();
const margin = 8;
let left = rect.left;
const maxLeft = window.innerWidth - popRect.width - margin;
if (left > maxLeft) left = Math.max(margin, maxLeft);
let top = rect.top - popRect.height - 10;
if (top < margin) top = rect.bottom + 10;
pop.style.left = `${left}px`;
pop.style.top = `${top}px`;
}
function bindScheduleIndicatorPopover() {
document.addEventListener('mouseover', (e) => {
const el = e.target.closest('.schedule-indicator');
if (!el || el.contains(e.relatedTarget)) return;
if (scheduleIndicatorHideTimer) { clearTimeout(scheduleIndicatorHideTimer); scheduleIndicatorHideTimer = null; }
showScheduleIndicatorPopover(el);
});
document.addEventListener('mouseout', (e) => {
const el = e.target.closest('.schedule-indicator');
if (!el || el.contains(e.relatedTarget)) return;
scheduleIndicatorHideTimer = setTimeout(hideScheduleIndicatorPopover, 150);
});
document.addEventListener('click', (e) => {
const el = e.target.closest('.schedule-indicator');
if (!el) {
if (!e.target.closest('#scheduleIndicatorPopover')) hideScheduleIndicatorPopover();
return;
}
e.stopPropagation();
const pop = get('scheduleIndicatorPopover');
const key = `${el.getAttribute('data-schedule-target')}:${el.getAttribute('data-schedule-id')}`;
if (pop && pop.classList.contains('open') && pop.getAttribute('data-for') === key) hideScheduleIndicatorPopover();
else showScheduleIndicatorPopover(el);
});
}
function bindNavigation() {
document.querySelectorAll('.nav-item, .sub-nav-item, .tab-container > span, .subtab-container > span').forEach(item => {
item.addEventListener('click', (e) => {
e.preventDefault();
const grpid = item.getAttribute('data-grpid');
if (grpid) confirmDiscardChanges(() => activateGrpid(grpid));
});
});
const breadcrumb = get('divSectionBreadcrumb');
if (breadcrumb) {
const followBreadcrumb = (target) => {
const el = target && target.closest ? target.closest('.section-breadcrumb-link') : null;
const grpid = el ? el.getAttribute('data-grpid') : null;
if (!grpid) return false;
confirmDiscardChanges(() => activateGrpid(grpid));
return true;
};
breadcrumb.addEventListener('click', (e) => { followBreadcrumb(e.target); });
breadcrumb.addEventListener('keydown', (e) => {
if (e.key !== 'Enter' && e.key !== ' ') return;
if (followBreadcrumb(e.target)) e.preventDefault();
});
}
window.addEventListener('hashchange', () => {
if (isApplyingHash) { isApplyingHash = false; return; }
const target = _parseRoute(location.hash);
if (isDirty) {
isApplyingHash = true;
location.hash = currentSlug;
confirmDiscardChanges(() => activateGrpid(target.grpid, { editor: target.editor }));
return;
}
activateGrpid(target.grpid, { updateHash: false, editor: target.editor });
});
}
function stepDeviceGpio(pinKey, direction, prefix, boardSelectId, isManualCallback, pinMaps) {
const selBoard = get(boardSelectId);
if (!selBoard) return;
const isM = isManualCallback(parseInt(selBoard.value, 10));
const el = get((isM ? 'input' : 'sel') + prefix + pinKey);
if (!el) return;
let newValue;
if (isM) {
let current = parseInt(el.value, 10);
if (isNaN(current)) current = 0;
let next = current + direction;
const cm = (get('divContainer').getAttribute('data-chipmodel') || "").toLowerCase();
const pm = pinMaps.find(x => x.name === cm) || { maxPins: 39 };
if (next < 0 || next > pm.maxPins) return;
el.value = next;
newValue = next;
const selPin = get(`sel${prefix}${pinKey}`);
if (selPin) selPin.value = next;
} else {
const nextIndex = el.selectedIndex + direction;
if (nextIndex < 0 || nextIndex >= el.options.length) return;
el.selectedIndex = nextIndex;
newValue = el.value;
const inpP = get(`input${prefix}${pinKey}`);
if (inpP) inpP.value = newValue;
}
el.dispatchEvent(new Event('change', { bubbles: true }));
return newValue;
}
const SECRET_DUMMY_CHAR = '•';
const SECRET_DUMMY_TEXT = SECRET_DUMMY_CHAR.repeat(10);
function initSecretField(input, hasValue) {
if (!input) return;
const eye = input.parentElement ? input.parentElement.querySelector('.password-eye') : null;
const showDummy = () => {
input.value = SECRET_DUMMY_TEXT;
input.dataset.secretDummy = 'true';
if (eye) eye.style.display = 'none';
};
const reveal = () => {
if (input.dataset.secretDummy === 'true') {
input.value = '';
input.dataset.secretDummy = 'false';
if (eye) eye.style.display = '';
}
};
input.dataset.hadValue = hasValue ? 'true' : 'false';
if (hasValue) showDummy();
else clearSecretField(input);
input.addEventListener('focus', reveal);
input.addEventListener('input', reveal);
input.addEventListener('blur', () => {
if (input.dataset.hadValue === 'true' && input.dataset.secretDummy === 'false' && input.value === '') {
showDummy();
}
});
}
function clearSecretField(input) {
if (!input) return;
const eye = input.parentElement ? input.parentElement.querySelector('.password-eye') : null;
input.value = '';
input.dataset.secretDummy = 'false';
input.dataset.hadValue = 'false';
if (eye) eye.style.display = '';
}
function secretValue(input) {
if (!input) return '';
return input.dataset.secretDummy === 'true' ? '' : input.value;
}
function initSecretPinGroup(inputs, hasValue) {
const list = Array.from(inputs || []);
if (list.length === 0) return;
const showDummy = () => {
list.forEach(inp => { inp.value = SECRET_DUMMY_CHAR; inp.dataset.secretDummy = 'true'; });
};
const reveal = () => {
if (list[0].dataset.secretDummy === 'true') {
list.forEach(inp => { inp.value = ''; inp.dataset.secretDummy = 'false'; });
}
};
list.forEach(inp => {
inp.value = hasValue ? SECRET_DUMMY_CHAR : '';
inp.dataset.secretDummy = hasValue ? 'true' : 'false';
inp.dataset.hadValue = hasValue ? 'true' : 'false';
inp.addEventListener('focus', reveal);
inp.addEventListener('blur', () => {
setTimeout(() => {
const stillInGroup = list.includes(document.activeElement);
const allEmpty = list.every(i => i.value === '');
if (!stillInGroup && list[0].dataset.hadValue === 'true' && list[0].dataset.secretDummy === 'false' && allEmpty) {
showDummy();
}
}, 0);
});
});
}
function secretPinValue(inputs) {
const list = Array.from(inputs || []);
if (list.length === 0 || list[0].dataset.secretDummy === 'true') return '';
return list.map(inp => inp.value || '').join('');
}
function modalHeader(title, icon = 'svg-simpleShutter', options = {}) {
const subtitle = options.subtitle ? `<span class="modalHeader-subtitle">${tr(options.subtitle)}</span>` : '';
const rightContent = options.rightContent || '';
const headerTypeClass = options.type ? options.type.split(' ').map(t => `header-${t}`).join(' ') : '';
return `
    <!-- Poignée visible uniquement sur Mobile -->
    <div class="modalHeader-handle" onclick="handleMobileDismiss(this)"></div>

    <div class="modalHeader ${headerTypeClass}">
    <div class="modalHeader-block">
    <!-- Badge Icône Premium -->
    <div class="modalHeader-badge">
    <svg><use href="#${icon}"></use></svg>
    </div>

    <!-- Bloc Textes (Titre + Sous-titre facultatif) -->
    <div class="modalHeader-texts">
    <span class="modalHeader-title">${tr(title)}</span>
    ${subtitle}
    </div>
    </div>

    <!-- Contenu additionnel à droite -->
    <div class="modalHeader-right">${rightContent}</div>
    </div>`;
}
function overlayHeader(title, desc, icon = 'svg-simpleShutter', options = {}) {
if (typeof options === 'boolean') {
options = { showExpert: options };
}
const subtitle = options.subtitle ? `<span class="overlayHeader-subtitle">${tr(options.subtitle)}</span>` : '';
const stateBadge = options.stateBadge ? `<span class="overlayHeader-state" style="display:none;">${tr(options.stateBadge)}</span>` : '';
const titleLine = stateBadge
? `<div class="overlayHeader-titleRow"><span class="overlayHeader-title">${tr(title)}</span>${stateBadge}</div>`
: `<span class="overlayHeader-title">${tr(title)}</span>`;
const showInfo = options.showInfo !== undefined ? options.showInfo : true;
const showExpert = options.showExpert || false;
const escJsString = s => (s || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
const escHtmlAttr = s => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
const safeTitle = escHtmlAttr(escJsString(title));
const safeDesc = escHtmlAttr(escJsString(desc));
const infoAction = `(typeof ui !== 'undefined' && ui.infoMessage) ? ui.infoMessage('${safeTitle}', '${safeDesc}') : infoMessage('${safeTitle}', '${safeDesc}');`;
let actionHTML = '';
if (showExpert) {
actionHTML = `
        <div class="overlayHeader-dropdown-container">
        <button type="button" class="overlayHeader-btn-action" title="${tr("OPTION")}" onclick="
        event.stopPropagation();
        const menu = this.nextElementSibling;
        const isExp = (typeof ui !== 'undefined' && ui) ? ui.isExpertMode : false;

        const optExp = menu.querySelector('.opt-expert');
        const optNorm = menu.querySelector('.opt-normal');

        // On réinitialise et on applique .active sur le BON bouton uniquement
        if (optExp && optNorm) {
            optExp.classList.remove('active');
            optNorm.classList.remove('active');
            if (isExp) {
                optExp.classList.add('active');
            } else {
                optNorm.classList.add('active');
            }
        }

        menu.classList.toggle('show');
        ">
        <svg><use href="#svg-menuVertical"></use></svg>
        </button>
        <div class="overlayHeader-dropdown-menu">
        ${showInfo ? `<div class="dropdown-item" onclick="this.parentElement.classList.remove('show'); ${infoAction}"><svg><use href="#svg-info"></use></svg> ${tr('MSG_INFO')}</div>` : ''}

        <div class="dropdown-item opt-expert" onclick="
        this.parentElement.classList.remove('show');
        if(typeof ui !== 'undefined' && ui && !ui.isExpertMode) {
            ui.toggleExpertMode(this.closest('.inst-overlay, .modal-overlay'));
        }
        ">
        ${tr('BT_EXPERT_MODE')}
        </div>

        <div class="dropdown-item opt-normal" onclick="
        this.parentElement.classList.remove('show');
        if(typeof ui !== 'undefined' && ui && ui.isExpertMode) {
            ui.toggleExpertMode(this.closest('.inst-overlay, .modal-overlay'));
        }
        ">
        ${tr('BT_GUIDED_MODE')}
        </div>
        </div>
        </div>`;
} else if (showInfo) {
actionHTML = `
        <button type="button" class="overlayHeader-btn-action" title="${tr('BT_HELP')}" onclick="${infoAction}">
        <svg><use href="#svg-info"></use></svg>
        </button>`;
}
return `
    <div class="overlayHeader">
    <div class="overlayHeader-block">
    <div class="overlayHeader-badge">
    <svg><use href="#${icon}"></use></svg>
    </div>
    <div class="overlayHeader-texts">
    ${titleLine}
    ${subtitle}
    </div>
    </div>
    <div class="overlayHeader-right">
    ${actionHTML}
    <div close onclick="closeOverlay(this.closest('.inst-overlay, .modal-overlay'))">
    <svg><use href="#svg-closeOverlay"></use></svg>
    </div>
    </div>
    </div>`;
}
document.addEventListener('click', () => {
document.querySelectorAll('.overlayHeader-dropdown-menu.show').forEach(menu => menu.classList.remove('show'));
});
function wizardStepper(stepsData, translationPrefix) {
let stepsHtml = '';
let titlesHtml = '';
const isArray = Array.isArray(stepsData);
const totalSteps = isArray ? stepsData.length : stepsData;
for (let i = 1; i <= totalSteps; i++) {
stepsHtml += `<div class="stepper-item" data-stepid="${i}"><div class="step-counter">${i}</div></div>`;
let titleKey;
if (isArray) {
titleKey = stepsData[i - 1];
} else {
titleKey = `${translationPrefix}_STEP${i}`;
}
titlesHtml += `<h3 class="step-title wizard-step" data-stepid="${i}">${tr(titleKey)}</h3>`;
}
return `
    <div class="stepper-wrapper" style="--steps: ${totalSteps};">
    ${stepsHtml}
    </div>
    <div class="step-title-container">
    ${titlesHtml}
    </div>`;
}
let appTooltipHideTimer = null;
let appTooltipTrigger = null;
function getAppTooltipEl() {
let pop = get('appTooltipPortal');
if (!pop) {
pop = document.createElement('div');
pop.id = 'appTooltipPortal';
pop.className = 'app-tooltip app-tooltip-portal';
pop.innerHTML = '<div class="app-tooltip-title"></div><div class="app-tooltip-body"></div>';
pop.addEventListener('mouseenter', () => {
if (appTooltipHideTimer) { clearTimeout(appTooltipHideTimer); appTooltipHideTimer = null; }
});
pop.addEventListener('mouseleave', () => hideAppTooltip());
document.body.appendChild(pop);
}
return pop;
}
function hideAppTooltip() {
const pop = get('appTooltipPortal');
if (pop) pop.classList.remove('open');
appTooltipTrigger = null;
}
function showAppTooltip(triggerEl) {
const titleTr = triggerEl.getAttribute('data-tooltip-title-tr');
const title = titleTr ? tr(titleTr) : (triggerEl.getAttribute('data-tooltip-title') || '');
const textTr = triggerEl.getAttribute('data-tooltip-tr');
const text = textTr
? textTr.split(',').map(k => tr(k.trim())).join('<br><br>')
: (triggerEl.getAttribute('data-tooltip-text') || '');
if (!text) return;
const href = triggerEl.getAttribute('data-tooltip-href');
const hrefTr = triggerEl.getAttribute('data-tooltip-href-tr');
const hrefLabel = hrefTr ? tr(hrefTr) : (triggerEl.getAttribute('data-tooltip-href-label') || href);
const link = href
? `<a class="app-tooltip-link" href="${href}" target="_blank" rel="noopener noreferrer">${hrefLabel}<svg class="app-tooltip-link-icon"><use href="#svg-linkOut"></use></svg></a>`
: '';
const pop = getAppTooltipEl();
pop.querySelector('.app-tooltip-title').innerHTML = title;
pop.querySelector('.app-tooltip-body').innerHTML = text + link;
pop.classList.remove('open');
pop.style.left = '-9999px';
pop.style.top = '-9999px';
pop.classList.add('open');
appTooltipTrigger = triggerEl;
const rect = triggerEl.getBoundingClientRect();
const popRect = pop.getBoundingClientRect();
const margin = 8;
let left = rect.left;
const maxLeft = window.innerWidth - popRect.width - margin;
if (left > maxLeft) left = Math.max(margin, maxLeft);
let top = rect.bottom + 10, arrow = 'up';
if (top + popRect.height > window.innerHeight - margin) {
top = rect.top - popRect.height - 10;
arrow = 'down';
}
pop.style.setProperty('--arrow-x', `${Math.max(8, rect.left - left + rect.width / 2 - 6)}px`);
pop.setAttribute('data-arrow', arrow);
pop.style.left = `${left}px`;
pop.style.top = `${top}px`;
}
function bindAppTooltips() {
document.addEventListener('mouseover', (e) => {
const el = e.target.closest('[data-tooltip-text], [data-tooltip-tr]');
if (!el || el.contains(e.relatedTarget)) return;
if (appTooltipHideTimer) { clearTimeout(appTooltipHideTimer); appTooltipHideTimer = null; }
showAppTooltip(el);
});
document.addEventListener('mouseout', (e) => {
const el = e.target.closest('[data-tooltip-text], [data-tooltip-tr]');
if (!el || el.contains(e.relatedTarget)) return;
appTooltipHideTimer = setTimeout(hideAppTooltip, 150);
});
document.addEventListener('click', (e) => {
const el = e.target.closest('[data-tooltip-text], [data-tooltip-tr]');
if (!el) {
if (!e.target.closest('#appTooltipPortal')) hideAppTooltip();
return;
}
if (appTooltipTrigger === el) hideAppTooltip();
else showAppTooltip(el);
});
}
async function reopenSocket() {
if (tConnect) clearTimeout(tConnect);
tConnect = null;
await initSockets();
}
async function init() {
await security.init();
general.init();
wifi.init();
somfy.init();
mqtt.init();
firmware.init();
bindNavigation();
bindMobileUptimeTooltip();
bindScheduleIndicatorPopover();
bindAppTooltips();
const initialRoute = _parseRoute(location.hash);
const resolvedSlug = activateGrpid(initialRoute.grpid, { updateHash: false, editor: initialRoute.editor });
if (location.hash.slice(1) !== resolvedSlug) {
history.replaceState(null, '', location.pathname + location.search + '#' + resolvedSlug);
}
get('divContainer').addEventListener('afterlogin', (evt) => {
if (!evt.detail || !evt.detail.authenticated || !sockIsOpen) return;
(async () => {
await general.loadGeneral();
await wifi.loadNetwork();
await somfy.loadSomfy();
await mqtt.loadMQTT();
})();
});
}
class UIBinder {
isExpertMode = localStorage.getItem('expertMode') === 'true';
setValue(el, val) {
if (el instanceof HTMLInputElement) {
switch (el.type.toLowerCase()) {
case 'checkbox':
el.checked = makeBool(val);
break;
case 'range':
let dt = el.getAttribute('data-datatype');
let mult = parseInt(el.getAttribute('data-mult') || 1, 10);
switch (dt) {
case 'float':
el.value = Math.round(parseInt(val * mult, 10));
break;
case 'index':
let ivals = JSON.parse(el.getAttribute('data-values'));
for (let i = 0; i < ivals.length; i++) {
if (ivals[i].toString() === val.toString()) {
el.value = i;
break;
}
}
break;
default:
el.value = parseInt(val, 10) * mult;
break;
}
syncSliderProgress(el);
break;
default:
el.value = val;
break;
}
}
else if (el instanceof HTMLSelectElement) {
let ndx = 0;
for (let i = 0; i < el.options.length; i++) {
let opt = el.options[i];
if (opt.value === val.toString()) {
ndx = i;
break;
}
}
el.selectedIndex = ndx;
}
else if (el instanceof HTMLElement) el.innerHTML = val;
}
getValue(el, defVal) {
let val = defVal;
if (el instanceof HTMLInputElement) {
switch (el.type.toLowerCase()) {
case 'checkbox':
val = el.checked;
break;
case 'range':
let dt = el.getAttribute('data-datatype');
let mult = parseInt(el.getAttribute('data-mult') || 1, 10);
switch (dt) {
case 'float':
val = parseInt(el.value, 10) / mult;
break;
case 'index':
let ivals = JSON.parse(el.getAttribute('data-values'));
val = ivals[parseInt(el.value, 10)];
break;
default:
val = parseInt(el.value / mult, 10);
break;
}
break;
default:
val = el.value;
break;
}
}
else if (el instanceof HTMLSelectElement) val = el.value;
else if (el instanceof HTMLElement) val = el.innerHTML;
return val;
}
toElement(el, val) {
let flds = el.querySelectorAll('*[data-bind]');
flds.forEach((fld) => {
let prop = fld.getAttribute('data-bind');
let arr = prop.split('.');
let tval = val;
for (let i = 0; i < arr.length; i++) {
var s = arr[i];
if (typeof s === 'undefined' || !s) continue;
let ndx = s.indexOf('[');
if (ndx !== -1) {
ndx = parseInt(s.substring(ndx + 1, s.indexOf(']') - 1), 10);
s = s.substring(0, ndx - 1);
}
tval = tval[s];
if (typeof tval === 'undefined') break;
if (ndx >= 0) tval = tval[ndx];
}
if (typeof tval !== 'undefined') {
if (typeof fld.val === 'function') this.val(tval);
else {
switch (fld.getAttribute('data-fmttype')) {
case 'time':
{
var dt = new Date();
dt.setHours(0, 0, 0);
dt.addMinutes(tval);
tval = dt.fmt(fld.getAttribute('data-fmtmask'), fld.getAttribute('data-fmtempty') || '');
}
break;
case 'date':
case 'datetime':
{
let dt = new Date(tval);
tval = dt.fmt(fld.getAttribute('data-fmtmask'), fld.getAttribute('data-fmtempty') || '');
}
break;
case 'number':
if (typeof tval !== 'number') tval = parseFloat(tval);
tval = tval.fmt(fld.getAttribute('data-fmtmask'), fld.getAttribute('data-fmtempty') || '');
break;
case 'duration':
tval = ui.formatDuration(tval, fld.getAttribute('data-fmtmask'));
break;
}
this.setValue(fld, tval);
}
}
});
}
fromElement(el, obj, arrayRef) {
if (typeof arrayRef === 'undefined' || arrayRef === null) arrayRef = [];
if (typeof obj === 'undefined' || obj === null) obj = {};
if (typeof el.getAttribute('data-bind') !== 'undefined') this._bindValue(obj, el, this.getValue(el), arrayRef);
let flds = el.querySelectorAll('*[data-bind]');
flds.forEach((fld) => {
if (!makeBool(fld.getAttribute('data-setonly')))
this._bindValue(obj, fld, this.getValue(fld), arrayRef);
});
return obj;
}
parseNumber(val) {
if (val === null) return;
if (typeof val === 'undefined') return val;
if (typeof val === 'number') return val;
if (typeof val.getMonth === 'function') return val.getTime();
var tval = val.replace(/[^0-9\.\-]+/g, '');
return tval.indexOf('.') !== -1 ? parseFloat(tval) : parseInt(tval, 10);
}
_bindValue(obj, el, val, arrayRef) {
var binding = el.getAttribute('data-bind');
var dataType = el.getAttribute('data-datatype');
if (binding && binding.length > 0) {
var sRef = '';
var arr = binding.split('.');
var t = obj;
for (var i = 0; i < arr.length - 1; i++) {
let s = arr[i];
if (typeof s === 'undefined' || s.length === 0) continue;
sRef += '.' + s;
var ndx = s.lastIndexOf('[');
if (ndx !== -1) {
var v = s.substring(0, ndx);
var ndxEnd = s.lastIndexOf(']');
var ord = parseInt(s.substring(ndx + 1, ndxEnd), 10);
if (isNaN(ord)) ord = 0;
if (typeof arrayRef[sRef] === 'undefined') {
if (typeof t[v] === 'undefined') {
t[v] = new Array();
t[v].push(new Object());
t = t[v][0];
arrayRef[sRef] = ord;
}
else {
let k = arrayRef[sRef];
if (typeof k === 'undefined') {
let a = t[v];
k = a.length;
arrayRef[sRef] = k;
a.push(new Object());
t = a[k];
}
else
t = t[v][k];
}
}
else {
let k = arrayRef[sRef];
if (typeof k === 'undefined') {
let a = t[v];
k = a.length;
arrayRef[sRef] = k;
a.push(new Object());
t = a[k];
}
else
t = t[v][k];
}
}
else if (typeof t[s] === 'undefined') {
t[s] = new Object();
t = t[s];
}
else
t = t[s];
}
if (typeof dataType === 'undefined') dataType = 'string';
t[arr[arr.length - 1]] = this.parseValue(val, dataType);
}
}
parseValue(val, dataType) {
switch (dataType) {
case 'int':
return Math.floor(this.parseNumber(val));
case 'uint':
return Math.abs(this.parseNumber(val));
case 'float':
case 'real':
case 'double':
case 'decimal':
case 'number':
return this.parseNumber(val);
case 'date':
if (typeof val === 'string') return new Date(val);
else if (typeof val === 'number') return new Date(val);
else if (typeof val.getMonth === 'function') return val;
return undefined;
case 'time':
var dt = new Date();
if (typeof val === 'number') {
dt.setHours(0, 0, 0);
dt.addMinutes(val);
return dt;
}
else if (typeof val === 'string' && val.indexOf(':') !== -1) {
var n = val.lastIndexOf(':');
var min = this.parseNumber(val.substring(n));
var nsp = val.substring(0, n).lastIndexOf(' ') + 1;
var hrs = this.parseNumber(val.substring(nsp, n));
dt.setHours(0, 0, 0);
if (hrs <= 12 && val.substring(n).indexOf('p')) hrs += 12;
dt.addMinutes(hrs * 60 + min);
return dt;
}
break;
case 'duration':
if (typeof val === 'number') return val;
return Math.floor(this.parseNumber(val));
default:
return val;
}
}
formatValue(val, dataType, fmtMask, emptyMask) {
var v = this.parseValue(val, dataType);
if (typeof v === 'undefined') return emptyMask || '';
switch (dataType) {
case 'int':
case 'uint':
case 'float':
case 'real':
case 'double':
case 'decimal':
case 'number':
return v.fmt(fmtMask, emptyMask || '');
case 'time':
case 'date':
case 'dateTime':
return v.fmt(fmtMask, emptyMask || '');
}
return v;
}
waitMessage(el, msgKey) {
let div = document.createElement('div');
div.innerHTML = `
        <div class="wait-overlay-inner">
        <svg class="wait-spinner" viewBox="25 25 50 50"><circle class="wait-spinner-track" cx="50" cy="50" r="20" fill="none" stroke-width="3"/><circle class="wait-spinner-arc" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10"/></svg>
        <div class="wait-overlay-text"></div>
        </div>`;
div.classList.add('wait-overlay');
if (typeof el === 'undefined') el = get('divContainer');
el.appendChild(div);
void div.offsetWidth;
div.classList.add('overlay-entered');
this.setWaitMessage(div, msgKey);
return div;
}
setWaitMessage(overlay, msgKey) {
if (!overlay) return;
const txt = overlay.querySelector('.wait-overlay-text');
if (!txt) return;
txt.textContent = msgKey ? tr(msgKey) : '';
txt.style.display = msgKey ? '' : 'none';
}
serviceError(el, err) {
let title = tr('ERR_SERVICE_TITLE');
if (arguments.length === 1) {
err = el;
el = get('divContainer');
}
let msg = '';
if (typeof err === 'string' && err.startsWith('{')) {
let e = JSON.parse(err);
if (typeof e !== 'undefined' && typeof e.desc === 'string') msg = e.desc;
else msg = err;
}
else if (typeof err === 'string') msg = err;
else if (typeof err === 'number') {
switch (err) {
case 404:
msg = `404: Service not found`;
break;
default:
msg = `${err}: Service Error`;
break;
}
}
else if (typeof err !== 'undefined') {
if (typeof err.desc === 'string') {
msg = typeof err.desc !== 'undefined' ? err.desc : err.message;
if (typeof err.code === 'number') {
let e = errors.find(x => x.code === err.code) || { code: err.code, desc: 'Unspecified error' };
msg = e.desc;
title = err.desc;
}
}
}
if (err && typeof err === 'object' && typeof err.code === 'string') {
const proprio = typeof err.owner === 'string' ? err.owner
: (err.ownerKey ? tr(err.ownerKey) : '');
const modele = trOr('ERR_' + err.code, null);
const champs = {
pin: escHtml(String(err.pin ?? '')),
line: escHtml(String(err.line ?? '')),
line2: escHtml(String(err.line2 ?? '')),
owner: escHtml(proprio)
};
msg = modele
? modele.replace(/\{(pin|line2|line|owner)\}/g, (m, k) => champs[k])
: escHtml(msg);
}
logger.error('Service error:', err);
let div = this.errorMessage(el, `${err.htmlError || 500}: ${title}`);
let sub = div.querySelector('.sub-message');
sub.innerHTML = `
        <div style="margin-bottom: 10px;">
        <strong style="opacity: 0.7;">${tr('ERR_SERVICE_LABEL')}</strong> ${err.service || 'Unknown'}
        </div>
        <div style="font-weight: 600; opacity: 0.9;">
        ${msg}
        </div>
        `;
return div;
}
socketError(el, msg) {
if (arguments.length === 1) {
msg = el;
el = get('divContainer');
}
let existing = document.querySelector('.socket-error');
if (existing) {
let subMsg = existing.querySelector('.sub-message-text');
if (subMsg) subMsg.innerHTML = msg;
return existing;
}
let div = document.createElement('div');
div.className = 'error-message socket-error modal-overlay';
div.innerHTML = `
        <div class="message-content error-content">
        ${modalHeader(trOr('ERR_SOCKET_TITLE', 'Connection Error'), 'svg-error', { type: 'small danger' })}
        <div class="sub-message">
        <p style="font-weight: 600; margin-bottom: 8px;">${trOr('ERR_SOCKET_CONNECT', 'Unable to connect to the server')}</p>
        <p class="sub-message-text" style="font-size: 0.85em; opacity: 0.8;">${msg}</p>

        <!-- Compteur de tentatives stylisé en bas du message -->
        <div id="divSocketAttempts" class="socketAttempts" style="margin-top: 20px; font-size: 0.85em; opacity: 0.6;">
        <span>${trOr('ERR_SOCKET_ATTEMPTS', 'Connection attempts:')} </span><span id="spanSocketAttempts" style="font-weight: 600;">1</span>
        </div>
        </div>
        </div>`;
el.appendChild(div);
shOverlay(div);
return div;
}
errorMessage(el, title, subMsg, extraMsg) {
this.clearErrors();
let container = el;
let args = [title, subMsg, extraMsg];
if (!(el instanceof HTMLElement)) {
container = get('divContainer');
args = [el, title, subMsg, extraMsg].filter(a => a !== undefined && a !== null && a !== '');
} else {
args = args.filter(a => a !== undefined && a !== null && a !== '');
}
let headerTitle = tr('ERROR');
let bodyMessages = [];
if (args.length === 1) {
bodyMessages.push(args[0]);
} else if (args.length === 2) {
headerTitle = args[0];
bodyMessages.push(args[1]);
} else if (args.length >= 3) {
headerTitle = args[0];
bodyMessages = args.slice(1);
}
const bodyContent = bodyMessages.map(msg => `<p>${msg}</p>`).join('');
let div = document.createElement('div');
div.className = 'error-message modal-overlay';
div.innerHTML = `
        <div class="message-content error-content">
        ${modalHeader(headerTitle, 'svg-error', { type: 'small danger' })}
        <div class="sub-message">
        ${bodyContent}
        </div>
        <div class="button-container-row">
        <button type="button" onclick="ui.clearErrors();">${tr('BT_CLOSE')}</button>
        </div>
        </div>`;
container.appendChild(div);
shOverlay(div);
return div;
}
promptMessage(el, msg, onYes, isDanger = false, iconId = null) {
if (arguments.length === 2 || (arguments.length === 3 && typeof msg === 'function')) {
if (typeof msg === 'function') {
isDanger = onYes;
onYes = msg;
msg = el;
el = get('divContainer');
}
}
if (!iconId) {
iconId = isDanger ? 'svg-reboot' : 'svg-info';
}
let div = document.createElement('div');
div.className = 'modal-overlay';
const redAttr = isDanger ? 'red' : '';
const modalType = isDanger ? 'small danger' : 'small';
div.innerHTML = `
        <div class="message-content prompt-content">
        ${modalHeader(msg, iconId, { type: modalType })}

        <div class="sub-message"></div>
        <div class="button-container-row">
        <button line type="button" onclick="ui.clearErrors();">${tr('BT_NO')}</button>
        <button id="btnYes" ${redAttr} type="button">
        ${isDanger ? `<svg><use href="#svg-retry"></use></svg>` : ''} <span>${tr('BT_YES')}</span>
        </button>
        </div>
        </div>`;
el.appendChild(div);
shOverlay(div);
div.querySelector('#btnYes').onclick = () => {
if (typeof onYes === 'function') onYes();
ui.clearErrors();
};
return div;
}
infoMessage(el, title, msg, onOk) {
this.clearErrors();
if (typeof el === 'string') {
onOk = msg;
msg = title;
title = el;
el = get('divContainer');
}
let div = document.createElement('div');
div.className = 'info-message modal-overlay';
const contentMsg = (msg !== undefined && msg !== null) ? tr(msg) : '';
div.innerHTML = `
        <div class="message-content info-content">
        ${modalHeader(title, 'svg-info', { type: 'small' })}

        <div class="sub-message">
        ${contentMsg ? `<p>${contentMsg}</p>` : ''}
        </div>

        <div class="button-container-row">
        <button id="btnOk" type="button">${tr('BT_OK')}</button>
        </div>
        </div>`;
el.appendChild(div);
shOverlay(div);
const btnOk = div.querySelector('#btnOk');
btnOk.onclick = () => {
if (typeof onOk === 'function') onOk();
ui.clearErrors();
};
return div;
}
clearErrors() {
document.querySelectorAll('div.modal-overlay').forEach((el) => {
if (!el.querySelector('.prompt-content, .error-content, .info-content')) return;
closeOverlay(el);
});
}
successMessage(msg) {
this.clearErrors();
let el = get('divContainer');
let div = document.createElement('div');
div.innerHTML = `<div class="success-content"><svg class="icon-svg"><use href="#svg-succes"></use></svg><span>${msg}</span></div>`;
div.classList.add('success-toast');
el.appendChild(div);
setTimeout(() => {
div.classList.add('hide');
setTimeout(() => {
if (div.parentNode) div.remove();
}, 400);
}, 3500);
return div;
}
toggleExpertMode(el) {
this.isExpertMode = !this.isExpertMode;
localStorage.setItem('expertMode', this.isExpertMode);
if (el) {
el.classList.toggle('is-expert', this.isExpertMode);
if (!this.isExpertMode) {
this.wizSetStep(el, this.wizCurrentStep(el));
}
}
}
setFocus(target, activate = true, color = null) {
let el = (typeof target === 'string') ? document.getElementById(target) : target;
if (!el) return;
if (el.id === 'btnPairShade' || el.id === 'btnUnpairShade') {
el = el.closest('.uniblocCol.divButton') || el;
}
else if (el.tagName === 'BUTTON' && el.classList.contains('unibutton')) {
el = el.closest('.uniblocCol') || el;
}
if (activate) {
if (color) el.style.setProperty('--pulse-color', color);
el.classList.add('ui-pulse');
} else {
el.classList.remove('ui-pulse');
el.style.removeProperty('--pulse-color');
}
}
wizSetPrevStep(el) { this.wizSetStep(el, Math.max(this.wizCurrentStep(el) - 1, 1)); }
wizSetNextStep(el) { this.wizSetStep(el, this.wizCurrentStep(el) + 1); }
wizSetStep(el, step) {
let curr = this.wizCurrentStep(el);
let sStep = step.toString();
const isExpert = el.classList.contains('is-expert');
el.setAttribute('data-stepid', step);
el.style.setProperty('--current-step', step);
el.querySelectorAll('.stepper-item[data-stepid]').forEach(item => {
const n = parseInt(item.getAttribute('data-stepid'), 10);
const isCompleted = n < step;
item.classList.toggle('completed', isCompleted);
item.classList.toggle('active', n === step);
const counter = item.querySelector('.step-counter');
if (counter) counter.innerHTML = isCompleted ? '<svg><use href="#svg-check"></use></svg>' : n;
});
el.querySelectorAll('[data-stepid], [data-ustepid], [data-mstepid]').forEach(item => {
if (item.classList.contains('stepper-item')) return;
if (item === el) return;
let show = true;
if (isExpert) {
show = item.hasAttribute('data-expert');
}
else {
if (item.hasAttribute('data-stepid')) {
show = item.getAttribute('data-stepid') === sStep;
}
else if (item.hasAttribute('data-ustepid')) {
show = item.getAttribute('data-ustepid') !== sStep;
}
else if (item.hasAttribute('data-mstepid')) {
let steps = item.getAttribute('data-mstepid').split(',');
show = steps.includes(sStep);
}
}
item.style.display = show ? '' : 'none';
});
if (curr !== step) {
let evt = new CustomEvent('stepchanged', { detail: { oldStep: curr, newStep: step }, bubbles: true });
el.dispatchEvent(evt);
}
}
wizCurrentStep(el) { return parseInt(el.getAttribute('data-stepid') || 1, 10); }
pinKeyPressed(evt) {
let el = evt.target || evt.srcElement;
let parent = el.parentElement;
let digits = Array.from(parent.querySelectorAll('.pin-digit'));
let index = digits.indexOf(el);
switch (evt.key) {
case 'Backspace':
if (el.value === '' && index > 0) digits[index - 1].focus();
return;
case 'ArrowLeft':
if (index > 0) digits[index - 1].focus();
return;
case 'ArrowRight':
if (index < digits.length - 1) digits[index + 1].focus();
return;
case 'Enter':
if (typeof security !== 'undefined') security.login();
return;
}
setTimeout(() => {
if (el.value.length > 1) el.value = el.value.slice(-1);
if (!/^[0-9]$/.test(el.value)) el.value = "";
if (el.value !== "" && index < digits.length - 1) {
digits[index + 1].focus();
}
const pin = digits.map(d => d.value).join('');
if (pin.length === 4) {
if (typeof security !== 'undefined') {
security.login();
} else if (typeof general !== 'undefined' && typeof general.login === 'function') {
general.login();
}
}
}, 20);
}
pinDigitFocus(evt) {
evt.srcElement.select();
}
isConfigOpen() { return window.getComputedStyle(get('divConfigPnl')).display !== 'none'; }
setConfigPanel() { activateGrpid('divSystemSettings'); }
setHomePanel() { activateGrpid('divHomePnl'); }
showRadioConfig() { activateGrpid('divTransceiverSettings'); }
showSystemConfig() { this.setConfigPanel(); }
showShadeConfig() {
activateGrpid('divSomfyMotors');
if (typeof somfy !== 'undefined') {
somfy.showEditShade(true);
somfy.openEditShade();
}
}
}
var ui = new UIBinder();
function showAuthenticatedShellOrWizard() {
if (isApMode && !window.__onboardingDone) {
get('divAuthenticated').style.display = 'none';
setOnboardingLock(true);
onboarding.open();
} else {
const wiz = get('divOnboardingWizard');
if (wiz) wiz.style.display = 'none';
setOnboardingLock(false);
get('divAuthenticated').style.display = '';
}
}
function setOnboardingLock(active) {
document.body.classList.toggle('onboarding-active', active);
const sidebar = document.querySelector('.sidebar');
if (sidebar) sidebar.inert = active;
}
const SECURITY_SESSION_KEY = 'espsomfy.apiKey';
class Security {
type = 0;
authenticated = false;
apiKey = '';
permissions = 0;
_restoreSessionKey() {
try {
const k = window.sessionStorage.getItem(SECURITY_SESSION_KEY);
if (k) this.apiKey = k;
} catch (err) { logger.debug('sessionStorage unavailable, session will not survive reloads'); }
}
_persistSessionKey() {
try {
if (this.apiKey) window.sessionStorage.setItem(SECURITY_SESSION_KEY, this.apiKey);
else window.sessionStorage.removeItem(SECURITY_SESSION_KEY);
} catch (err) { }
}
_clearSessionKey() {
try { window.sessionStorage.removeItem(SECURITY_SESSION_KEY); } catch (err) { }
}
async init() {
get('divContainer').addEventListener('afterlogin', () => {
checkActiveLangAvailability(window.__activeLangCode);
});
const userFld = get('divUnauthenticated').querySelector('#fldLoginUsername');
const pwdFld = get('divUnauthenticated').querySelector('#fldLoginPassword');
if (userFld) {
userFld.addEventListener('keydown', (evt) => {
if (evt.key !== 'Enter') return;
evt.preventDefault();
if (pwdFld && pwdFld.value.length === 0) pwdFld.focus();
else security.login();
});
}
if (pwdFld) {
pwdFld.addEventListener('keydown', (evt) => {
if (evt.key !== 'Enter') return;
evt.preventDefault();
security.login();
});
}
this._restoreSessionKey();
await this.loadContext();
if (this.type === 0 || (this.permissions & 0x01) === 0x01 || this.authenticated) {
this._ensureSockets();
get('divUnauthenticated').style.display = 'none';
showAuthenticatedShellOrWizard();
get('divContainer').setAttribute('data-auth', true);
}
}
_ensureSockets() {
if (typeof socket === 'undefined' || !socket) (async () => { await initSockets(); })();
}
async loadContext() {
const pnl = get('divUnauthenticated');
if (!pnl) return;
const qs = (s) => pnl.querySelector(s);
const btn = qs('#loginButtons'), pwd = qs('#divLoginPassword'), pin = qs('#divLoginPin');
pnl.style.display = btn.style.display = pwd.style.display = pin.style.display = 'none';
return new Promise(res => {
loadLang(() => {
getJSONSync('/loginContext', (err, ctx) => {
if (err) return ui.serviceError(err), res();
if (ctx.uptime !== undefined) {
deviceUptimeSeconds = ctx.uptime;
displayUptime(deviceUptimeSeconds, 'uptime-display');
}
if (ctx.netUptime !== undefined) {
netUptimeSeconds = ctx.netUptime;
displayUptime(netUptimeSeconds, 'net-display');
}
updateNetUptimeLabel(ctx.netMode);
if (ctx.netType && typeof wifi !== 'undefined') wifi.applyNetType(ctx.netType);
if (uptimeInterval) { clearInterval(uptimeInterval); uptimeInterval = null; }
if (ctx.uptime !== undefined) uptimeInterval = setInterval(() => {
deviceUptimeSeconds++;
displayUptime(deviceUptimeSeconds, 'uptime-display');
if (netUptimeSeconds > 0) {
netUptimeSeconds++;
displayUptime(netUptimeSeconds, 'net-display');
}
}, 1000);
if (ctx.cpuFreq) get('info-cpu').textContent = `${ctx.cores > 1 ? 'Dual' : 'Single'}-Core @ ${ctx.cpuFreq} ${tr('UNIT_MHZ')}`;
if (ctx.flashSize) {
get('info-flash').innerHTML = `<span>${tr('FW_TOTAL')}: </span><span class="status-detail">${ctx.flashSize}</span> ${tr('UNIT_MO')} (<span class="hide550">${tr('FW_SPEED')}: </span><span class="status-detail">${ctx.flashSpeed}</span> ${tr('UNIT_MHZ')})`;
}
if (ctx.fsTotal) {
const free = ctx.fsTotal - ctx.fsUsed, pct = Math.round((ctx.fsUsed / ctx.fsTotal) * 100);
const el = get('info-fs-status');
if (el) el.innerHTML = `<span class="status-detail">${free}</span> ${tr('UNIT_KO')} ${tr('FW_FREE_SUFFIX')}<span class="hide550"> ${tr('FW_ON')} <span class="status-detail">${ctx.fsTotal}</span></span>`;
const cFlash = get('circle-flash');
if (cFlash) {
cFlash.style.background = `conic-gradient(#12b17c ${pct}%, var(--color-circle-indicator) 0%)`;
cFlash.innerHTML = `<span>${pct}%</span>`;
}
}
if (ctx.mac) document.querySelectorAll('.spanMacAddress').forEach(el => el.textContent = ctx.mac);
this.type = ctx.type;
this.permissions = ctx.permissions;
this.authenticated = (ctx.type !== 0) && !!ctx.authenticated;
if (ctx.type !== 0 && !this.authenticated) {
this.apiKey = '';
this._clearSessionKey();
}
const cont = get('divContainer');
if (cont) cont.setAttribute('data-securitytype', ctx.type);
if (ctx.type !== 0 && !this.authenticated) {
btn.style.display = '';
const targetDiv = ctx.type === 1 ? pin : pwd;
targetDiv.style.display = '';
this.focusLoginField();
const typeFld = qs('#fldLoginType');
if (typeFld) typeFld.value = ctx.type;
pnl.style.display = 'flex';
const cancelBtn = qs('#btnCancelLogin');
if (cancelBtn) {
const configOnly = (ctx.permissions & 0x01) === 0x01;
cancelBtn.setAttribute('tr', configOnly ? 'BT_CANCEL_1' : 'BT_CLEAR');
if (typeof translator !== 'undefined') translator.translate(cancelBtn);
}
}
window.__activeLangCode = ctx.language;
window.__fwVersionTag = ctx.version;
window.__defaultLangCode = ctx.defaultLang;
window.__pendingLangCode = ctx.pendingLang || '';
checkPendingLangApplied(ctx.language, window.__pendingLangCode);
checkActiveLangAvailability(ctx.language);
window.__onboardingDone = !!ctx.onboardingDone;
window.__currentHostname = ctx.hostname || '';
window.__hardwareProfile = ctx.hardwareProfile || '';
window.__maxClients = ctx.maxClients || 0;
window.__fwImageMarker = ctx.fwImageMarker || '';
window.__fsPartitionSize = ctx.fsPartitionSize || 0;
window.__ledPin = typeof ctx.ledPin === 'number' ? ctx.ledPin : -1;
res();
});
});
});
}
authUser() {
get('divAuthenticated').style.display = 'none';
return this.loadContext().then(() => {
if (this.type !== 0 && this.authenticated) {
get('divUnauthenticated').style.display = 'none';
showAuthenticatedShellOrWizard();
get('divContainer').setAttribute('data-auth', true);
}
});
}
focusLoginField() {
const pnl = get('divUnauthenticated');
if (!pnl) return;
const fld = this.type === 1
? pnl.querySelector('.pin-digit[data-bind="login.pin.d0"]')
: pnl.querySelector('#fldLoginUsername');
if (fld) setTimeout(() => fld.focus(), 100);
}
cancelLogin() {
const configOnly = (this.permissions & 0x01) === 0x01;
if (this.type === 0 || configOnly) {
let evt = new CustomEvent('afterlogin', { detail: { authenticated: this.authenticated } });
showAuthenticatedShellOrWizard();
get('divUnauthenticated').style.display = 'none';
get('divContainer').dispatchEvent(evt);
} else {
this.resetLoginForm();
}
}
handleUnauthorized() {
if (this._reauthPending) return;
this._reauthPending = true;
this.authenticated = false;
this.apiKey = '';
this._clearSessionKey();
setTimeout(() => { this._reauthPending = false; }, 2000);
logger.warn('Session no longer authorized, prompting for login again');
this.authUser();
}
resetLoginForm() {
const pnl = get('divUnauthenticated');
if (!pnl) return;
const msg = pnl.querySelector('#spanLoginMessage');
if (msg) msg.innerHTML = '';
pnl.querySelectorAll('.pin-digit').forEach(inp => inp.value = '');
const userFld = pnl.querySelector('#fldLoginUsername');
if (userFld) userFld.value = '';
const pwdFld = pnl.querySelector('#fldLoginPassword');
if (pwdFld) pwdFld.value = '';
this.focusLoginField();
}
login(event) {
if (event && typeof event.preventDefault === 'function') {
event.preventDefault();
}
let pnl = get('divUnauthenticated');
let btn = pnl.querySelector('#btnLogin');
if (btn && btn.disabled) return;
let msg = pnl.querySelector('#spanLoginMessage');
msg.innerHTML = '';
let sec = ui.fromElement(pnl).login;
let pin = '';
switch (sec.type) {
case 1:
for (let i = 0; i < 4; i++) {
pin += sec.pin[`d${i}`];
}
if (pin.length !== 4) return;
break;
case 2:
break;
}
sec.pin = pin;
putJSONSync('/login', sec, (err, log) => {
if (err) {
if (err.htmlError === 429 && err.retryAfter) this.startLoginLockout(err.retryAfter);
else ui.serviceError(err);
}
else {
if (log.success) {
this.apiKey = log.apiKey;
this.authenticated = true;
this._persistSessionKey();
this._ensureSockets();
get('divUnauthenticated').style.display = 'none';
showAuthenticatedShellOrWizard();
get('divContainer').setAttribute('data-auth', true);
this.loadContext().then(() => {
let evt = new CustomEvent('afterlogin', { detail: { authenticated: true } });
get('divContainer').dispatchEvent(evt);
});
}
else {
let text = tr(log.msg);
if (log.maxAttempts) text += ` (${tr('LOGIN_ATTEMPT_LABEL')} ${log.attempt}/${log.maxAttempts})`;
msg.innerHTML = text;
}
}
});
}
startLoginLockout(seconds) {
const pnl = get('divUnauthenticated');
const msg = pnl.querySelector('#spanLoginMessage');
const btn = pnl.querySelector('#btnLogin');
if (this._lockoutInterval) clearInterval(this._lockoutInterval);
let remaining = Math.max(1, parseInt(seconds, 10) || 0);
if (btn) { btn.disabled = true; btn.classList.add('disabled'); }
const render = () => {
const m = Math.floor(remaining / 60);
const s = remaining % 60;
const time = m > 0 ? `${m}:${String(s).padStart(2, '0')}` : `${s}s`;
msg.innerHTML = `${tr('ERR_LOGIN_LOCKED')} ${time}`;
};
render();
this._lockoutInterval = setInterval(() => {
remaining--;
if (remaining <= 0) {
clearInterval(this._lockoutInterval);
this._lockoutInterval = null;
if (btn) { btn.disabled = false; btn.classList.remove('disabled'); }
msg.innerHTML = '';
} else {
render();
}
}, 1000);
}
toggleFieldPassword(fieldId, el) {
const fld = get(fieldId);
const ico = el.querySelector('use');
if (fld.type === 'password') {
fld.type = 'text';
if(ico) ico.setAttribute('href', '#svg-eyeOn');
} else {
fld.type = 'password';
if(ico) ico.setAttribute('href', '#svg-eyeOff');
}
}
}
var security = new Security();
class General {
initialized = false;
appVersion = 'v3.0.0';
reloadApp = false;
_currentSecurityType = 0;
_manualImportPending = new Set();
_feedbackListenersBound = false;
init() {
if (this.initialized) return;
const savedTheme = localStorage.getItem('themeMode') || '0';
this._savedTheme = savedTheme;
this.applyTheme(savedTheme);
this._defaultAccent = this.readAccent();
const savedColor = localStorage.getItem('accentColor');
if (savedColor) {
document.documentElement.style.setProperty('--color-accent', savedColor);
}
this.bindAccentColor(savedColor || this._defaultAccent);
this.applyFeedbackPrefs();
this.setAppVersion();
this.setTimeZones();
if (sockIsOpen && ui.isConfigOpen()) socket.send('join:0');
ui.toElement(get('divSystemSettings'), {
general: { hostname: 'ESPSomfyRTS', username: '', password: '', posixZone: 'UTC0', ntpServer: 'pool.ntp.org' }
});
this.initialized = true;
}
readAccent() {
const v = getComputedStyle(document.documentElement).getPropertyValue('--color-accent').trim();
return /^#[0-9a-f]{6}$/i.test(v) ? v : '#1a5fb4';
}
bindAccentColor(saved) {
const input = get('fldAccentColor');
if (!input) return;
this._savedAccent = saved;
input.value = saved;
input.addEventListener('input', (e) => {
document.documentElement.style.setProperty('--color-accent', e.target.value);
});
}
revertAccentPreview(scope) {
if (!this._savedAccent) return;
const input = get('fldAccentColor');
if (scope && !(input && scope.contains(input))) return;
document.documentElement.style.setProperty('--color-accent', this._savedAccent);
if (input) input.value = this._savedAccent;
}
revertThemePreview(scope) {
if (!this._savedTheme) return;
const sel = get('selThemeMode');
if (scope && !(sel && scope.contains(sel))) return;
this.applyTheme(this._savedTheme);
}
revertClientPreviews(scope) {
this.revertAccentPreview(scope);
this.revertThemePreview(scope);
}
applyTheme(val) {
if (val === '1') {
document.documentElement.setAttribute('data-theme', 'dark');
} else if (val === '2') {
document.documentElement.setAttribute('data-theme', 'light');
} else {
const dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
}
const sel = get('selThemeMode');
if (sel) sel.value = val;
}
static FEEDBACK_PREFS_DEFAULT = { haptic: true, visualCommands: true, visualUI: true, visualForms: true, style: 'scale', styleCommands: 'scale' };
getFeedbackPrefs() {
let saved = {};
try { saved = JSON.parse(localStorage.getItem('feedbackPrefs') || '{}'); } catch (e) { saved = {}; }
return Object.assign({}, General.FEEDBACK_PREFS_DEFAULT, saved);
}
setFeedbackPrefs(patch) {
const merged = Object.assign(this.getFeedbackPrefs(), patch);
localStorage.setItem('feedbackPrefs', JSON.stringify(merged));
this.applyFeedbackPrefs();
}
applyFeedbackPrefs() {
const p = this.getFeedbackPrefs();
const root = document.documentElement;
root.setAttribute('data-feedback-commands', p.visualCommands ? 'on' : 'off');
root.setAttribute('data-feedback-ui', p.visualUI ? 'on' : 'off');
root.setAttribute('data-feedback-forms', p.visualForms ? 'on' : 'off');
root.setAttribute('data-feedback-style', p.style === 'flash' ? 'flash' : 'scale');
root.setAttribute('data-feedback-style-commands', p.styleCommands === 'flash' ? 'flash' : 'scale');
this._bindFeedbackListeners();
}
_bindFeedbackListeners() {
if (this._feedbackListenersBound) return;
this._feedbackListenersBound = true;
const HAPTIC_PRESS_SELECTOR = '.btn-somfy-svg, .animScale, .welcomeCard, .preset-badge, .radioBtnPrec, [close], button';
const vibrate = () => {
if (this.getFeedbackPrefs().haptic && navigator.vibrate) navigator.vibrate(15);
};
document.addEventListener('pointerdown', (e) => {
if (e.target.closest(HAPTIC_PRESS_SELECTOR)) vibrate();
}, { passive: true });
document.addEventListener('focusin', (e) => {
const el = e.target;
if (/^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName) && el.closest('.dirty-target')) vibrate();
});
}
FeedbackOverlay() {
if (get('divFeedbackOverlay')) return;
const p = this.getFeedbackPrefs();
const hasTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
const hapticSupported = !!navigator.vibrate && hasTouch;
const div = document.createElement('div');
div.id = 'divFeedbackOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content" id="divFeedbackPopupContent">
        ${modalHeader('GENERAL_FEEDBACK', 'svg-haptic', { subtitle: 'FEEDBACK_MODAL_DESC' })}

        <div class="overlay-scroll-content">

        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('FEEDBACK_SECTION_HAPTIC')}</h3>
        <label class="uniRow dirty-target" for="cbFeedbackHaptic">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-vibrate"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('FEEDBACK_HAPTIC_TOGGLE')}</div>
        <div class="uniStatus">${tr(hapticSupported ? 'FEEDBACK_HAPTIC_TOGGLE_DESC' : 'FEEDBACK_HAPTIC_UNSUPPORTED')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch">
        <input id="cbFeedbackHaptic" type="checkbox" ${p.haptic ? 'checked' : ''} ${hapticSupported ? '' : 'disabled'}>
        <div></div>
        </span>
        </div>
        </label>
        </div>

        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('FEEDBACK_VISUAL_COMMANDS')}</h3>
        <label class="uniRow dirty-target" for="cbFeedbackCommands">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-simpleShutter"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('FEEDBACK_SECTION_VISUAL')}</div>
        <div class="uniStatus">${tr('FEEDBACK_VISUAL_COMMANDS_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch"><input id="cbFeedbackCommands" type="checkbox" ${p.visualCommands ? 'checked' : ''}><div></div></span>
        </div>
        </label>

        <div class="SwitchBig SwitchBig-2 dirty-target" id="feedbackStyleCommandsSwitch">
        <input type="radio" name="feedbackStyleCommands" id="feedbackStyleCommandsScale" value="scale" ${p.styleCommands !== 'flash' ? 'checked' : ''}>
        <label for="feedbackStyleCommandsScale">${tr('FEEDBACK_STYLE_SCALE')}</label>
        <input type="radio" name="feedbackStyleCommands" id="feedbackStyleCommandsFlash" value="flash" ${p.styleCommands === 'flash' ? 'checked' : ''}>
        <label for="feedbackStyleCommandsFlash">${tr('FEEDBACK_STYLE_FLASH')}</label>
        <div class="nav-pill"></div>
        </div>
        </div>

        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('FEEDBACK_SECTION_VISUAL_UI')}</h3>
        <label class="uniRow dirty-target" for="cbFeedbackUI">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-tabHome"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('FEEDBACK_VISUAL_UI')}</div>
        <div class="uniStatus">${tr('FEEDBACK_VISUAL_UI_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch"><input id="cbFeedbackUI" type="checkbox" ${p.visualUI ? 'checked' : ''}><div></div></span>
        </div>
        </label>
        <label class="uniRow dirty-target" for="cbFeedbackForms">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-edit"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('FEEDBACK_VISUAL_FORMS')}</div>
        <div class="uniStatus">${tr('FEEDBACK_VISUAL_FORMS_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch"><input id="cbFeedbackForms" type="checkbox" ${p.visualForms ? 'checked' : ''}><div></div></span>
        </div>
        </label>


        <div class="SwitchBig SwitchBig-2 dirty-target" id="feedbackStyleSwitch">
        <input type="radio" name="feedbackStyle" id="feedbackStyleScale" value="scale" ${p.style !== 'flash' ? 'checked' : ''}>
        <label for="feedbackStyleScale">${tr('FEEDBACK_STYLE_SCALE')}</label>
        <input type="radio" name="feedbackStyle" id="feedbackStyleFlash" value="flash" ${p.style === 'flash' ? 'checked' : ''}>
        <label for="feedbackStyleFlash">${tr('FEEDBACK_STYLE_FLASH')}</label>
        <div class="nav-pill"></div>
        </div>
        </div>

        </div>

        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnFeedbackCancel" line type="button">${tr('BT_CANCEL')}</button>
        <button id="btnFeedbackApply" type="button"><svg><use href="#svg-save"></use></svg><span>${tr('BT_SAVE')}</span></button>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
watchDirty(div);
const syncCommandsStyleState = () => {
const on = div.querySelector('#cbFeedbackCommands').checked;
div.querySelectorAll('input[name="feedbackStyleCommands"]').forEach(r => { r.disabled = !on; });
};
div.querySelector('#cbFeedbackCommands').addEventListener('change', syncCommandsStyleState);
syncCommandsStyleState();
get('btnFeedbackCancel').onclick = () => requestCloseOverlay(div);
get('btnFeedbackApply').onclick = () => {
const radioValue = (name, fallback) => div.querySelector(`input[name="${name}"]:checked`)?.value || fallback;
this.setFeedbackPrefs({
haptic: get('cbFeedbackHaptic').checked,
visualCommands: get('cbFeedbackCommands').checked,
visualUI: get('cbFeedbackUI').checked,
visualForms: get('cbFeedbackForms').checked,
style: radioValue('feedbackStyle', 'scale'),
styleCommands: radioValue('feedbackStyleCommands', 'scale')
});
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
clearDirty(div);
closeOverlay(div);
};
}
getCookie(cname) {
let n = cname + '=';
let cookies = document.cookie.split(';');
for (let i = 0; i < cookies.length; i++) {
let c = cookies[i];
while (c.charAt(0) === ' ') c = c.substring(1);
if (c.indexOf(n) === 0) return c.substring(n.length, c.length);
}
return '';
}
reload() {
let addMetaTag = (name, content) => {
let meta = document.createElement('meta');
meta.httpEquiv = name;
meta.content = content;
document.getElementsByTagName('head')[0].appendChild(meta);
};
addMetaTag('pragma', 'no-cache');
addMetaTag('expires', '0');
addMetaTag('cache-control', 'no-cache');
document.location.reload();
}
timeZones = [
"Africa/Cairo|EET-2",
"Africa/Johannesburg|SAST-2",
"Africa/Juba|CAT-2",
"Africa/Lagos|WAT-1",
"Africa/Mogadishu|EAT-3",
"Africa/Tunis|CET-1",
"America/Adak|HST10HDT,M3.2.0,M11.1.0",
"America/Anchorage|AKST9AKDT,M3.2.0,M11.1.0",
"America/Asuncion|<-04>4<-03>,M10.1.0/0,M3.4.0/0",
"America/Bahia_Banderas|CST6CDT,M4.1.0,M10.5.0",
"America/Barbados|AST4",
"America/Bermuda|AST4ADT,M3.2.0,M11.1.0",
"America/Cancun|EST5",
"America/Central_Time|CST6CDT,M3.2.0,M11.1.0",
"America/Chihuahua|MST7MDT,M4.1.0,M10.5.0",
"America/Eastern_Time|EST5EDT,M3.2.0,M11.1.0",
"America/Godthab|<-03>3<-02>,M3.5.0/-2,M10.5.0/-1",
"America/Havana|CST5CDT,M3.2.0/0,M11.1.0/1",
"America/Mexico_City|CST6",
"America/Miquelon|<-03>3<-02>,M3.2.0,M11.1.0",
"America/Mountain_Time|MST7MDT,M3.2.0,M11.1.0",
"America/Pacific_Time|PST8PDT,M3.2.0,M11.1.0",
"America/Phoenix|MST7",
"America/Santiago|<-04>4<-03>,M9.1.6/24,M4.1.6/24",
"America/St_Johns|NST3:30NDT,M3.2.0,M11.1.0",
"Antarctica/Troll|<+00>0<+02>-2,M3.5.0/1,M10.5.0/3",
"Asia/Amman|EET-2EEST,M2.5.4/24,M10.5.5/1",
"Asia/Beirut|EET-2EEST,M3.5.0/0,M10.5.0/0",
"Asia/Colombo|<+0530>-5:30",
"Asia/Damascus|EET-2EEST,M3.5.5/0,M10.5.5/0",
"Asia/Gaza|EET-2EEST,M3.4.4/50,M10.4.4/50",
"Asia/Hong_Kong|HKT-8",
"Asia/Jakarta|WIB-7",
"Asia/Jayapura|WIT-9",
"Asia/Jerusalem|IST-2IDT,M3.4.4/26,M10.5.0",
"Asia/Kabul|<+0430>-4:30",
"Asia/Karachi|PKT-5",
"Asia/Kathmandu|<+0545>-5:45",
"Asia/Kolkata|IST-5:30",
"Asia/Makassar|WITA-8",
"Asia/Manila|PST-8",
"Asia/Seoul|KST-9",
"Asia/Shanghai|CST-8",
"Asia/Tehran|<+0330>-3:30",
"Asia/Tokyo|JST-9",
"Atlantic/Azores|<-01>1<+00>,M3.5.0/0,M10.5.0/1",
"Australia/Adelaide|ACST-9:30ACDT,M10.1.0,M4.1.0/3",
"Australia/Brisbane|AEST-10",
"Australia/Darwin|ACST-9:30",
"Australia/Eucla|<+0845>-8:45",
"Australia/Lord_Howe|<+1030>-10:30<+11>-11,M10.1.0,M4.1.0",
"Australia/Melbourne|AEST-10AEDT,M10.1.0,M4.1.0/3",
"Australia/Perth|AWST-8",
"Etc/GMT-1|<+01>-1",
"Etc/GMT-2|<+02>-2",
"Etc/GMT-3|<+03>-3",
"Etc/GMT-4|<+04>-4",
"Etc/GMT-5|<+05>-5",
"Etc/GMT-6|<+06>-6",
"Etc/GMT-7|<+07>-7",
"Etc/GMT-8|<+08>-8",
"Etc/GMT-9|<+09>-9",
"Etc/GMT-10|<+10>-10",
"Etc/GMT-11|<+11>-11",
"Etc/GMT-12|<+12>-12",
"Etc/GMT-13|<+13>-13",
"Etc/GMT-14|<+14>-14",
"Etc/GMT+0|GMT0",
"Etc/GMT+1|<-01>1",
"Etc/GMT+2|<-02>2",
"Etc/GMT+3|<-03>3",
"Etc/GMT+4|<-04>4",
"Etc/GMT+5|<-05>5",
"Etc/GMT+6|<-06>6",
"Etc/GMT+7|<-07>7",
"Etc/GMT+8|<-08>8",
"Etc/GMT+9|<-09>9",
"Etc/GMT+10|<-10>10",
"Etc/GMT+11|<-11>11",
"Etc/GMT+12|<-12>12",
"Etc/UTC|UTC0",
"Europe/Athens|EET-2EEST,M3.5.0/3,M10.5.0/4",
"Europe/Berlin|CEST-1CET,M3.2.0/2:00:00,M11.1.0/2:00:00",
"Europe/Brussels|CET-1CEST,M3.5.0,M10.5.0/3",
"Europe/Chisinau|EET-2EEST,M3.5.0,M10.5.0/3",
"Europe/Dublin|IST-1GMT0,M10.5.0,M3.5.0/1",
"Europe/Lisbon|WET0WEST,M3.5.0/1,M10.5.0",
"Europe/London|GMT0BST,M3.5.0/1,M10.5.0",
"Europe/Moscow|MSK-3",
"Europe/Paris|CET-1CEST-2,M3.5.0/02:00:00,M10.5.0/03:00:00",
"Indian/Cocos|<+0630>-6:30",
"Pacific/Auckland|NZST-12NZDT,M9.5.0,M4.1.0/3",
"Pacific/Chatham|<+1245>-12:45<+1345>,M9.5.0/2:45,M4.1.0/3:45",
"Pacific/Easter|<-06>6<-05>,M9.1.6/22,M4.1.6/22",
"Pacific/Fiji|<+12>-12<+13>,M11.2.0,M1.2.3/99",
"Pacific/Guam|ChST-10",
"Pacific/Honolulu|HST10",
"Pacific/Marquesas|<-0930>9:30",
"Pacific/Midway|SST11",
"Pacific/Norfolk|<+11>-11<+12>,M10.1.0,M4.1.0/3"
];
loadGeneral() {
const pnl = get('divSystemSettings');
getJSONSync('/modulesettings', (err, settings) => {
if (err) {
logger.error('Failed to load general settings:', err);
return;
}
logger.setDebugEnabled(settings.enableDebugLogs);
logger.debug('General settings loaded:', settings);
if (typeof somfy !== 'undefined') somfy.initPins();
get('spanFwVersion').innerText = settings.fwVersion;
get('spanHwVersion').innerText = settings.chipModel.length > 0 ? '-' + settings.chipModel : '';
get('divContainer').setAttribute('data-chipmodel', settings.chipModel);
if (settings.hardwareProfile) {
get('divContainer').setAttribute('data-hardwareprofile', settings.hardwareProfile);
get('info-lbc').innerText = tr(settings.hardwareProfile);
}
this.setAppVersion();
this._ledSettings = { ledPin: settings.ledPin, ledActiveLow: settings.ledActiveLow, ledRfBlink: settings.ledRfBlink };
window.__ledPin = typeof settings.ledPin === 'number' ? settings.ledPin : -1;
this.updateLedBadge();
this._geoSettings = { geoLat: settings.geoLat, geoLon: settings.geoLon };
this.updateGeoBadge();
this._dashboardPrefs = {
headerMobileDisplay: typeof settings.headerMobileDisplay === 'number' ? settings.headerMobileDisplay : 0,
reverseDashboardColumns: !!settings.reverseDashboardColumns,
defaultMobileTab: settings.defaultMobileTab === 'devices' ? 'devices' : 'groups',
showRadioActivity: !!settings.showRadioActivity
};
this.applyDashboardPrefs(this._dashboardPrefs);
if (!this._defaultMobileTabApplied) {
this._defaultMobileTabApplied = true;
if (typeof somfy !== 'undefined' && typeof somfy.switchMobileTab === 'function') {
somfy.switchMobileTab(this._dashboardPrefs.defaultMobileTab);
}
}
if (_pendingGeoFromUrl) {
const prefill = _pendingGeoFromUrl;
_pendingGeoFromUrl = null;
this.GeoOverlay(prefill);
}
loadLang(() => {
ui.toElement(pnl, { general: settings });
this.populateLangSelect(settings.language);
});
if (settings.accentColor) {
this._savedAccent = settings.accentColor;
localStorage.setItem('accentColor', settings.accentColor);
}
else {
this._savedAccent = this._defaultAccent;
localStorage.removeItem('accentColor');
}
if (typeof settings.themeMode !== 'undefined') {
this._savedTheme = String(settings.themeMode);
localStorage.setItem('themeMode', this._savedTheme);
}
this.revertClientPreviews();
watchDirty(pnl);
});
}
setAppVersion() { get('spanAppVersion').innerText = this.appVersion; }
setTimeZones() {
const dd = get('selTimeZone');
dd.innerHTML = this.timeZones.map(tz => {
const [city, code] = tz.split('|');
return `<option value="${code}">${city}</option>`;
}).join('');
dd.value = 'UTC0';
}
setGeneral(done) {
let valid = true;
let pnl = get('divSystemSettings');
let obj = ui.fromElement(pnl).general;
logger.setDebugEnabled(obj.enableDebugLogs);
const msg = tr('ERR_HOSTNAME');
if (typeof obj.hostname === 'undefined' || !obj.hostname || obj.hostname === '') {
ui.errorMessage(msg, tr('ERR_INVALID_HOSTNAME'));
valid = false;
}
if (valid && !/^[a-zA-Z0-9-]+$/.test(obj.hostname)) {
ui.errorMessage(msg, tr('ERR_HOSTNAME_CHARS'));
valid = false;
}
if (valid && obj.hostname.length > 32) {
ui.errorMessage(msg, tr('ERR_HOSTNAME_LENGTH'));
valid = false;
}
if (valid && typeof obj.ntpServer === 'string' && obj.ntpServer.length > 64) {
ui.errorMessage(msg, tr('ERR_NTP_LENGTH'));
valid = false;
}
if (valid) {
putJSONSync('/setgeneral', obj, (err, response) => {
if (err) {
ui.serviceError(err);
} else {
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
logger.debug('General settings saved:', response);
if (obj.accentColor) {
this._savedAccent = obj.accentColor;
localStorage.setItem('accentColor', obj.accentColor);
}
if (typeof obj.themeMode !== 'undefined') {
this._savedTheme = String(obj.themeMode);
localStorage.setItem('themeMode', this._savedTheme);
}
clearDirty();
}
if (typeof done === 'function') done(err);
});
}
else if (typeof done === 'function') done(new Error('invalid'));
}
updateLedBadge() {
const badge = get('badgeLedState');
if (!badge) return;
const profile = get('divContainer').getAttribute('data-hardwareprofile') || '';
const s = this._ledSettings || { ledPin: -1 };
badge.classList.remove('state-disabled', 'state-success');
if (profile && profile !== 'GENERIC') {
badge.textContent = this._ledBoardLabel(profile);
badge.classList.add('state-success');
} else if (s.ledPin >= 0) {
badge.textContent = `GPIO ${s.ledPin}`;
badge.classList.add('state-success');
} else {
badge.textContent = tr('DISABLED');
badge.classList.add('state-disabled');
}
}
updateGeoBadge() {
const badge = get('badgeGeoState');
if (!badge) return;
const s = this._geoSettings || { geoLat: 99 };
badge.classList.remove('state-disabled', 'state-success');
if (s.geoLat >= -90 && s.geoLat <= 90) {
badge.textContent = `${s.geoLat.toFixed(2)}, ${s.geoLon.toFixed(2)}`;
badge.classList.add('state-success');
} else {
badge.textContent = tr('GENERAL_GEO_BADGE_DISABLED');
badge.classList.add('state-disabled');
}
}
GeoOverlay(prefill) {
if (get('divGeoOverlay')) return;
const s = this._geoSettings || { geoLat: 99, geoLon: 0 };
const isSet = s.geoLat >= -90 && s.geoLat <= 90;
const initLat = prefill ? prefill.lat : (isSet ? s.geoLat : null);
const initLon = prefill ? prefill.lon : (isSet ? s.geoLon : null);
const canDetectLocally = window.isSecureContext;
const canReadClipboard = window.isSecureContext && !!(navigator.clipboard && navigator.clipboard.readText);
const div = document.createElement('div');
div.id = 'divGeoOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content" id="divGeoPopupContent">
        ${modalHeader('GENERAL_GEO_TITLE', 'svg-location', {
subtitle: 'GEO_MODAL_DESC',
})}

        <div class="overlay-scroll-content">
        <div class="information">
        <div class="information-header">
        <svg><use href="#svg-info"></use></svg>
        <b>${tr('MSG_INFO')}</b>
        </div>
        <div class="information-text">
        <span>${tr('GEO_PRIVACY_NOTE')}</span>
        </div>
        </div>

        <div class="uniRow feedback-card">
        <button type="button" id="btnGeoExternal" class="buttonUpdate unibuttonPad">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-search"></use></svg></div>
        <div class="devButtonUpdate">
        <div>${tr('GEO_EXTERNAL')}</div>
        <div class="uniStatus">${tr('GEO_EXTERNAL_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <svg class="btnArrowRight"><use href="#svg-linkOut"></use></svg>
        </div>
        </button>
        </div>

        ${canDetectLocally ? `
        <div class="uniRow feedback-card">
        <button type="button" id="btnGeoDetect" class="buttonUpdate unibuttonPad">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-target"></use></svg></div>
        <div class="devButtonUpdate">
        <div>${tr('GEO_DETECT')}</div>
        <div class="uniStatus">${tr('GEO_DETECT_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <svg class="btnArrowRight"><use href="#svg-arrowRight"></use></svg>
        </div>
        </button>
        </div>
        <div class="uniStatus ledPinWarn" id="geoDetectError" style="display:none"></div>
        ` : ''}

        <div class="baseFlexRow">
        <div class="uniRow dirty-target">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-latitude"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="inputGeoLat">${tr('GEO_LAT')}</label>
        <input type="number" id="inputGeoLat" class="inputAndSelect" min="-90" max="90" step="0.01" value="${initLat !== null ? initLat.toFixed(2) : ''}" placeholder="37.24">
        <button type="button" class="input-paste-btn" id="btnGeoPasteLat" title="${tr('BT_PAST')}" aria-label="${tr('BT_PAST')}"><svg><use href="#svg-clipboard"></use></svg></button>
        </div>
        </div>
        </div>
        <div class="uniRow dirty-target">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-longitude"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="inputGeoLon">${tr('GEO_LON')}</label>
        <input type="number" id="inputGeoLon" class="inputAndSelect" min="-180" max="180" step="0.01" value="${initLon !== null ? initLon.toFixed(2) : ''}" placeholder="-115.81">
        <button type="button" class="input-paste-btn" id="btnGeoPasteLon" title="${tr('BT_PAST')}" aria-label="${tr('BT_PAST')}"><svg><use href="#svg-clipboard"></use></svg></button>
        </div>
        </div>
        </div>
        </div>
        <div class="uniStatus ledPinWarn" id="geoError" style="display:none"></div>
        </div>

        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        ${isSet ? `<button id="btnGeoClear" line type="button">${tr('BT_RESET')}</button>` : ''}
        <button id="btnGeoCancel" line type="button">${tr('BT_CANCEL')}</button>
        <button id="btnGeoApply" type="button"><svg><use href="#svg-save"></use></svg><span>${tr('BT_SAVE')}</span></button>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
watchDirty(div);
const setError = (msgKey) => {
const el = get('geoError');
if (!msgKey) { el.textContent = ''; el.style.display = 'none'; return; }
el.textContent = tr(msgKey);
el.style.display = '';
};
const setDetectError = (msgKey) => {
const el = get('geoDetectError');
if (!msgKey) { el.textContent = ''; el.style.display = 'none'; return; }
el.textContent = tr(msgKey);
el.style.display = '';
};
const GEO_PASTE_RE = /^(-?\d+(?:[.,]\d+)?)[\s,;]+(-?\d+(?:[.,]\d+)?)$/;
const applyPastedCoords = (raw) => {
const m = (raw || '').trim().match(GEO_PASTE_RE);
if (!m) return false;
const lat = parseFloat(m[1].replace(',', '.'));
const lon = parseFloat(m[2].replace(',', '.'));
if (!Number.isFinite(lat) || lat < -90 || lat > 90) return false;
if (!Number.isFinite(lon) || lon < -180 || lon > 180) return false;
get('inputGeoLat').value = lat.toFixed(2);
get('inputGeoLon').value = lon.toFixed(2);
setError(null);
return true;
};
const smartPaste = (e) => {
const raw = (e.clipboardData || window.clipboardData)?.getData('text') || '';
if (applyPastedCoords(raw)) e.preventDefault();
};
get('inputGeoLat').addEventListener('paste', smartPaste);
get('inputGeoLon').addEventListener('paste', smartPaste);
const applyPastedSingle = (raw, inputId, max) => {
const v = parseFloat((raw || '').trim().replace(',', '.'));
if (!Number.isFinite(v) || v < -max || v > max) return false;
get(inputId).value = v.toFixed(2);
setError(null);
return true;
};
const bindPasteButton = (btnId, inputId, max) => {
get(btnId)?.addEventListener('click', async () => {
setError(null);
if (canReadClipboard) {
try {
const raw = await navigator.clipboard.readText();
if (!applyPastedCoords(raw) && !applyPastedSingle(raw, inputId, max))
setError('ERR_GEO_PASTE_MANUAL');
return;
} catch (e) {
}
}
const input = get(inputId);
input.focus();
input.select();
setError('ERR_GEO_PASTE_MANUAL');
});
};
bindPasteButton('btnGeoPasteLat', 'inputGeoLat', 90);
bindPasteButton('btnGeoPasteLon', 'inputGeoLon', 180);
get('btnGeoDetect')?.addEventListener('click', () => {
if (!navigator.geolocation) {
setDetectError('ERR_GEO_UNAVAILABLE');
return;
}
setDetectError(null);
navigator.geolocation.getCurrentPosition(
(pos) => {
get('inputGeoLat').value = pos.coords.latitude.toFixed(2);
get('inputGeoLon').value = pos.coords.longitude.toFixed(2);
setError(null);
},
() => { setDetectError('ERR_GEO_DENIED'); },
{ timeout: 10000 }
);
});
get('btnGeoExternal').onclick = () => {
const params = new URLSearchParams({ return: window.location.origin });
const lang = localStorage.getItem('selectedLang');
if (lang) params.set('lang', lang);
window.open(`${GEO_HELPER_URL}?${params.toString()}`, '_blank');
};
get('btnGeoCancel').onclick = () => requestCloseOverlay(div);
get('btnGeoClear')?.addEventListener('click', () => {
putJSONSync('/setgeneral', { geoLat: 99, geoLon: 0 }, (err) => {
if (err) { ui.serviceError(err); return; }
this._geoSettings = { geoLat: 99, geoLon: 0 };
this.updateGeoBadge();
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
closeOverlay(div);
});
});
get('btnGeoApply').onclick = () => {
const lat = parseFloat(get('inputGeoLat').value);
const lon = parseFloat(get('inputGeoLon').value);
if (isNaN(lat) || lat < -90 || lat > 90) { setError('ERR_GEO_LAT_INVALID'); return; }
if (isNaN(lon) || lon < -180 || lon > 180) { setError('ERR_GEO_LON_INVALID'); return; }
setError(null);
putJSONSync('/setgeneral', { geoLat: lat, geoLon: lon }, (err) => {
if (err) {
if (err.code === 'GEO_LAT_INVALID') setError('ERR_GEO_LAT_INVALID');
else if (err.code === 'GEO_LON_INVALID') setError('ERR_GEO_LON_INVALID');
else ui.serviceError(err);
return;
}
this._geoSettings = { geoLat: lat, geoLon: lon };
this.updateGeoBadge();
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
clearDirty(div);
closeOverlay(div);
});
};
}
applyDashboardPrefs(p) {
const root = document.documentElement;
root.setAttribute('data-header-mobile-display', String(p.headerMobileDisplay));
root.setAttribute('data-show-radio-activity', p.showRadioActivity ? 'on' : 'off');
const homePnl = get('divHomePnl');
if (homePnl) homePnl.classList.toggle('reverse-columns', !!p.reverseDashboardColumns);
}
DashboardPrefsOverlay() {
if (get('divDashboardPrefsOverlay')) return;
const p = this._dashboardPrefs || { headerMobileDisplay: 0, reverseDashboardColumns: false, defaultMobileTab: 'groups', showRadioActivity: false };
const div = document.createElement('div');
div.id = 'divDashboardPrefsOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content" id="divDashboardPrefsPopupContent">
        ${modalHeader('TAB_DASHBOARD', 'svg-tabHome', { subtitle: 'DASHB_PREFS_MODAL_DESC' })}

        <div class="overlay-scroll-content">

        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('DASHB_PREFS_SECTION_HEADER')}</h3>
        <div class="uniRow dirty-target">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-header"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="selHeaderMobileDisplay">${tr('DASHB_PREFS_HEADER_MOBILE_DISPLAY')}</label>
        <select id="selHeaderMobileDisplay" class="inputAndSelect">
        <option value="0" ${p.headerMobileDisplay === 0 ? 'selected' : ''}>${tr('DASHB_PREFS_HEADER_MOBILE_ALL')}</option>
        <option value="1" ${p.headerMobileDisplay === 1 ? 'selected' : ''}>${tr('DASHB_PREFS_HEADER_MOBILE_NET')}</option>
        <option value="2" ${p.headerMobileDisplay === 2 ? 'selected' : ''}>${tr('DASHB_PREFS_HEADER_MOBILE_UPTIME')}</option>
        <option value="3" ${p.headerMobileDisplay === 3 ? 'selected' : ''}>${tr('DASHB_PREFS_HEADER_MOBILE_NONE')}</option>
        </select>
        </div>
        </div>
        </div>
        </div>

        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('DASHB_PREFS_SECTION_HEADER_1')}</h3>
        <label class="uniRow dirty-target" for="cbShowRadioActivity">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-tabRadio"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('DASHB_PREFS_RADIO_ACTIVITY')}</div>
        <div class="uniStatus">${tr('DASHB_PREFS_RADIO_ACTIVITY_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch"><input id="cbShowRadioActivity" type="checkbox" ${p.showRadioActivity ? 'checked' : ''}><div></div></span>
        </div>
        </label>
        </div>

        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('DASHB_PREFS_SECTION_HEADER_2')}</h3>
        <label class="uniRow dirty-target" for="cbReverseDashboardColumns">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-column"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('DASHB_PREFS_REVERSE_COLUMNS')}</div>
        <div class="uniStatus">${tr('DASHB_PREFS_REVERSE_COLUMNS_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch"><input id="cbReverseDashboardColumns" type="checkbox" ${p.reverseDashboardColumns ? 'checked' : ''}><div></div></span>
        </div>
        </label>

        <div class="unibloc-container">
        <div class="unifield-content">
        <label class="label">${tr('DASHB_PREFS_DEFAULT_TAB')}</label>

        </div>
        <div class="SwitchBig SwitchBig-2 dirty-target" id="dashboardDefaultTabSwitch">
        <input type="radio" name="defaultMobileTab" id="defaultTabGroups" value="groups" ${p.defaultMobileTab !== 'devices' ? 'checked' : ''}>
        <label for="defaultTabGroups">${tr('SUBTAB_GROUPS')}</label>
        <input type="radio" name="defaultMobileTab" id="defaultTabDevices" value="devices" ${p.defaultMobileTab === 'devices' ? 'checked' : ''}>
        <label for="defaultTabDevices">${tr('SUBTAB_DEVICES')}</label>
        <div class="nav-pill"></div>
        </div>
        </div>
        </div>

        </div>

        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnDashboardPrefsCancel" line type="button">${tr('BT_CANCEL')}</button>
        <button id="btnDashboardPrefsApply" type="button"><svg><use href="#svg-save"></use></svg><span>${tr('BT_SAVE')}</span></button>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
watchDirty(div);
get('btnDashboardPrefsCancel').onclick = () => requestCloseOverlay(div);
get('btnDashboardPrefsApply').onclick = () => {
const payload = {
headerMobileDisplay: parseInt(get('selHeaderMobileDisplay').value, 10),
reverseDashboardColumns: get('cbReverseDashboardColumns').checked,
defaultMobileTab: div.querySelector('input[name="defaultMobileTab"]:checked')?.value || 'groups',
showRadioActivity: get('cbShowRadioActivity').checked
};
putJSONSync('/setgeneral', payload, (err) => {
if (err) { ui.serviceError(err); return; }
this._dashboardPrefs = payload;
this.applyDashboardPrefs(payload);
if (typeof somfy !== 'undefined' && typeof somfy.switchMobileTab === 'function') {
somfy.switchMobileTab(payload.defaultMobileTab);
}
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
clearDirty(div);
closeOverlay(div);
});
};
}
_ledBoardLabel(profile) {
if (profile === 'BOX-ETH') return 'WT32-ETH01';
if (profile === 'BOX-WIFI') return 'ESP32-D1 mini';
return tr(profile);
}
_getRadioPins() {
const pk = ['SCKPin', 'CSNPin', 'MOSIPin', 'MISOPin', 'TXPin', 'RXPin'];
const bv = parseInt(get('selRadioBoardType')?.value, 10);
const isM = (bv === 255);
const out = {};
pk.forEach(k => {
const el = get((isM ? 'inputTrans' : 'selTrans') + k);
if (el && el.value !== '') out[k] = parseInt(el.value, 10);
});
return out;
}
_ledPinConflict(pin) {
const radio = this._getRadioPins();
for (const k in radio) {
if (radio[k] === pin) return k.replace('Pin', '');
}
return null;
}
_setLedPinError(msgKey, params) {
const el = get('ledPinError');
if (!el) return;
if (!msgKey) { el.textContent = ''; el.style.display = 'none'; return; }
let msg = tr(msgKey);
for (const k in (params || {})) msg = msg.replace(`{${k}}`, params[k]);
el.textContent = msg;
el.style.display = '';
}
_shakeLedPinInput() {
const container = get('divLedPinCustom');
if (!container || !container.offsetParent) return;
container.classList.remove('input-error');
void container.offsetWidth;
container.classList.add('input-error');
setTimeout(() => container.classList.remove('input-error'), 500);
}
LedOverlay() {
if (get('divLedOverlay')) return;
const profile = get('divContainer').getAttribute('data-hardwareprofile') || '';
const isGeneric = !profile || profile === 'GENERIC';
const s = this._ledSettings || { ledPin: -1, ledActiveLow: false, ledRfBlink: false };
const NONE = -1, PICK = 0, MANUAL = 255;
let presetVal = String(NONE);
if (s.ledPin === 5) presetVal = '5';
else if (s.ledPin === 2) presetVal = '2';
else if (s.ledPin > 0) presetVal = String(MANUAL);
const enabled = s.ledPin >= 0;
this._lastValidLedPin = (presetVal === String(MANUAL)) ? s.ledPin : 4;
const div = document.createElement('div');
div.id = 'divLedOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content ledOverlay-content" id="divLedPopupContent">
        ${modalHeader('FW_LED_TITLE', 'svg-led', {
subtitle: 'LED_MODAL_DESC',
})}
        <div class="overlay-scroll-content">

        ${isGeneric ? `
        <div class="SwitchBig marginB25" id="ledEnableSwitch">
        <input id="cbLedEnabled" type="checkbox" ${enabled ? 'checked' : ''}>
        <label for="cbLedEnabled" class="label-left">${tr('DISABLED')}</label>
        <label for="cbLedEnabled" class="label-right">${tr('ENABLED')}</label>
        <div class="nav-pill"></div>
        </div>

        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('LED_MODAL_PIN_SECTION')}</h3>



        <div class="uniStatus ledPinWarn" id="ledPinError" style="display:none"></div>






        <div class="baseFlexCol ">
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-esp"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="selLedBoardPreset">${tr('LED_MODAL_BOARD_PRESET')}</label>
        <select id="selLedBoardPreset" class="inputAndSelect">
        <option value="${NONE}" ${presetVal === String(NONE) ? 'selected' : ''}>${tr('LED_MODAL_PIN_NONE')}</option>
        <option value="${PICK}" ${presetVal === String(PICK) ? 'selected' : ''}>${tr('LED_MODAL_PRESET_PICK')}</option>
        <option value="5" ${presetVal === '5' ? 'selected' : ''}>WT32-ETH01</option>
        <option value="2" ${presetVal === '2' ? 'selected' : ''}>ESP32-D1 mini</option>
        <option value="${MANUAL}" ${presetVal === String(MANUAL) ? 'selected' : ''}>${tr('MANUAL_SETTINGS')}</option>
        </select>
        </div>
        </div>







        <div id="divLedManualBlock" style="display:${presetVal === String(MANUAL) ? 'block' : 'none'};">
        <div class="gpio-main-wrapper">
        <div class="gpio-group-block">
        <div class="gpio-flex-container">
        <div class="gpio-card">
        <div class="input-number-custom dirty-target" id="divLedPinCustom">
        <label class="input-label" for="inputLedPinManual">GPIO</label>
        <input type="number" id="inputLedPinManual" class="inputAndSelect" min="0" max="48" value="${this._lastValidLedPin}" autocomplete="new-password">
        <div class="step-buttons-warp">
        <div class="step-buttons">
        <button type="button" id="btnLedPinMinus">-</button>
        <button type="button" id="btnLedPinPlus">+</button>
        </div>
        </div>
        </div>
        <div class="uniStatus ledPinWarn" id="ledPinWarn" style="display:none"></div>
        </div>
        </div>
        </div>
        </div>
        <div class="manual-safety-block">
        <label class="safety-label" for="cbLedManualSafety">
        <span class="switch"><input id="cbLedManualSafety" type="checkbox"><div></div></span>
        <span class="safety-text">${tr('RADIO_SAFETY_TEXT')}</span>
        </label>
        </div>
        </div>
        </div>

        <div class="baseFlexCol">
        <div class="uniStatus led-pin-help">${tr('LED_MODAL_PIN_DESC')}</div>
        </div>
        ` : ''}

        <label class="uniRow dirty-target" for="cbLedActiveLow" id="rowLedActiveLow" style="display:${isGeneric ? 'flex' : 'none'};">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-gpioUp"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('LED_MODAL_ACTIVE_LOW')}</div>
        <div class="uniStatus">${tr('LED_MODAL_ACTIVE_LOW_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch"><input id="cbLedActiveLow" type="checkbox" ${s.ledActiveLow ? 'checked' : ''}><div></div></span>
        </div>
        </label>

        </div>

        <label class="uniRow dirty-target" for="cbLedRfBlink">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-wave"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('LED_MODAL_RF_BLINK')}</div>
        <div class="uniStatus">${tr('LED_MODAL_RF_BLINK_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch"><input id="cbLedRfBlink" type="checkbox" ${s.ledRfBlink ? 'checked' : ''}><div></div></span>
        </div>
        </label>
        </div>


        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnLedCancel" line type="button">${tr('BT_CANCEL')}</button>
        <button id="btnLedApply" type="button" disabled><svg><use href="#svg-save"></use></svg><span>${tr('BT_SAVE')}</span></button>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
watchDirty(div);
const markDirty = () => { get('btnLedApply').disabled = false; };
if (isGeneric) {
const swEnabled = get('cbLedEnabled');
const presetSel = get('selLedBoardPreset');
const manualBlock = get('divLedManualBlock');
const inputPin = get('inputLedPinManual');
const warn12 = get('ledPinWarn');
const cm = (get('divContainer').getAttribute('data-chipmodel') || '').toLowerCase();
const pm = (typeof somfy !== 'undefined' && somfy.pinMaps.find(x => x.name === cm)) || { maxPins: 39 };
const updateWarn = () => {
const v = parseInt(inputPin.value, 10);
const risky = v === 12 && (cm === '' || cm === 'esp32');
warn12.textContent = risky ? tr('GENERAL_LED_PIN_WARN_12') : '';
warn12.style.display = risky ? '' : 'none';
};
updateWarn();
const syncPreset = () => {
const val = parseInt(presetSel.value, 10);
manualBlock.style.display = (val === MANUAL) ? 'block' : 'none';
swEnabled.checked = (val !== NONE);
if (val === 5) get('cbLedActiveLow').checked = true;
else if (val === 2) get('cbLedActiveLow').checked = false;
if (val === MANUAL) updateWarn();
this._setLedPinError(null);
};
presetSel.addEventListener('change', () => { syncPreset(); markDirty(); });
swEnabled.addEventListener('change', () => {
if (!swEnabled.checked) {
presetSel.value = String(NONE);
} else if (parseInt(presetSel.value, 10) === NONE) {
presetSel.value = String(PICK);
}
syncPreset();
markDirty();
});
const onManualEdit = () => { updateWarn(); this._setLedPinError(null); markDirty(); };
inputPin.addEventListener('input', onManualEdit);
get('btnLedPinMinus').addEventListener('click', () => {
inputPin.value = Math.max(0, (parseInt(inputPin.value, 10) || 0) - 1);
onManualEdit();
});
get('btnLedPinPlus').addEventListener('click', () => {
inputPin.value = Math.min(pm.maxPins, (parseInt(inputPin.value, 10) || 0) + 1);
onManualEdit();
});
this._ledPinMax = pm.maxPins;
}
get('cbLedActiveLow')?.addEventListener('change', markDirty);
get('cbLedRfBlink').addEventListener('change', markDirty);
get('btnLedCancel').onclick = () => requestCloseOverlay(div);
get('btnLedApply').onclick = () => this.saveLedSettings(div, isGeneric);
}
saveLedSettings(div, isGeneric) {
const payload = { ledRfBlink: !!get('cbLedRfBlink').checked };
if (isGeneric) {
const NONE = -1, PICK = 0, MANUAL = 255;
const presetVal = parseInt(get('selLedBoardPreset').value, 10);
let pin = presetVal;
if (presetVal === PICK) {
this._setLedPinError('ERR_LED_PIN_UNSET');
return;
}
if (presetVal === MANUAL) {
pin = parseInt(get('inputLedPinManual').value, 10);
const max = this._ledPinMax ?? 39;
if (isNaN(pin) || pin < 0 || pin > max) {
this._setLedPinError('ERR_GPIO_NOT_EXIST', { pin: get('inputLedPinManual').value, maxPins: max });
this._shakeLedPinInput();
return;
}
}
if (pin >= 0) {
const owner = this._ledPinConflict(pin);
if (owner) {
this._setLedPinError('ERR_LED_PIN_IN_USE_SHORT', { pin: pin, owner: owner });
this._shakeLedPinInput();
return;
}
}
if (presetVal === MANUAL) {
if (!get('cbLedManualSafety')?.checked) {
this._setLedPinError('ERR_LED_SAFETY_REQUIRED');
return;
}
this._lastValidLedPin = pin;
}
this._setLedPinError(null);
payload.ledPin = pin;
payload.ledActiveLow = !!get('cbLedActiveLow').checked;
}
putJSONSync('/setgeneral', payload, (err, response) => {
if (err) {
if (err.code === 'LED_PIN_IN_USE') {
this._setLedPinError('ERR_LED_PIN_IN_USE_SHORT', { pin: err.pin, owner: err.owner || '?' });
this._shakeLedPinInput();
} else if (err.code === 'LED_PIN_INVALID') {
this._setLedPinError('ERR_LED_PIN_INVALID');
this._shakeLedPinInput();
} else {
ui.serviceError(err);
}
return;
}
this._ledSettings = {
ledPin: typeof payload.ledPin === 'number' ? payload.ledPin : this._ledSettings.ledPin,
ledActiveLow: typeof payload.ledActiveLow === 'boolean' ? payload.ledActiveLow : this._ledSettings.ledActiveLow,
ledRfBlink: payload.ledRfBlink
};
if (typeof payload.ledPin === 'number') window.__ledPin = payload.ledPin;
this.updateLedBadge();
if (typeof somfy !== 'undefined') somfy.applyLedFeedbackVisibility();
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
logger.debug('LED settings saved:', response);
clearDirty(div);
closeOverlay(div);
});
}
setSecurityConfig(security) {
this._currentSecurityType = security.type;
this._hasPin = !!security.hasPin;
this._hasPassword = !!security.hasPassword;
this._securityData = {
username: security.username || '',
password: '',
repeatpassword: '',
permissions: { configOnly: makeBool(security.permissions & 0x01) },
pin: { d0: '', d1: '', d2: '', d3: '' }
};
this.onSecurityTypeChanged();
}
rebootDevice() {
let prompt = ui.promptMessage(
get('divContainer'),
tr('PROMPT_REBOOT_CONFIRM_TITLE'),
() => {
if(typeof socket !== 'undefined') socket.close(3000, 'reboot');
putJSONSync('/reboot', {}, (err, response) => {
get('btnSaveGeneral').classList.remove('disabled');
logger.debug('Reboot requested:', response);
});
ui.clearErrors();
},
true,'svg-reboot'
);
prompt.querySelector('.sub-message').innerHTML = `<p>${tr('PROMPT_REBOOT_CONFIRM_SUB')}</p>`;
}
populateLangSelect(currentLang) {
document.documentElement.lang = currentLang;
const langDisplay = get('currentLangDisplay');
if (!langDisplay) return;
langDisplay.textContent = langLabel(currentLang);
loadLangManifest()
.then(manifest => {
if (manifest && manifest.langs && manifest.langs[currentLang]?.native) {
langDisplay.textContent = manifest.langs[currentLang].native;
}
})
.catch(err => {
logger.error('Failed to load manifest for current lang display:', err);
});
}
onLanguageChanged(lang, reload = true) {
const btn = get('btnOpenLangManager');
if (btn) btn.disabled = true;
return deviceFetch('/setLang?lang=' + lang)
.then(resp => {
if (resp.status !== "ok") throw new Error('unexpected /setLang response: ' + JSON.stringify(resp));
if (!reload) {
this.populateLangSelect(lang);
if (btn) btn.disabled = false;
return;
}
return new Promise((resolve, reject) => {
setTimeout(() => reject(new Error('reload-blocked: le rechargement de page n\'a pas eu lieu (fermeture bloquée ?)')), 5000);
appInitiatedReload();
});
})
.catch(err => {
logger.error("Failed to change language:", err);
if (btn) btn.disabled = false;
throw err;
});
}
openLangManager() {
if (get('divLangManagerOverlay')) return;
this._manualImportPending.clear();
const div = document.createElement('div');
div.id = 'divLangManagerOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content lang-manager-content">
        ${modalHeader('LANG_MODAL_TITLE', 'svg-language', {
subtitle: 'LANG_MODAL_TITLE_DESC',
})}

        <div class="overlay-scroll-content">

        <div id="langCatalog" class="lang-catalog"></div>

        <!-- Bloc d'importation manuelle globale -->

        <label for="fileLangGlobalImport" class="custom-file-upload">
        <span class="file-name-display">${tr('LANG_MODAL_IMPORT_FILE')}</span>
        <div class="file-icon-btn"><svg><use href="#svg-upload"></use></svg></div>
        </label>
        <input id="fileLangGlobalImport" type="file" accept="application/json,.json,application/gzip,.gz" style="display:none"
        onchange="general.handleGlobalLangUpload(this)"/>
        </div>

        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnLangManagerClose" line type="button">${tr('BT_CLOSE')}</button>
        </div>
        </div>
        </div>`;
shOverlay(div);
div.onclick = (e) => {
if (e.target.id === 'btnLangManagerClose' || e.target.closest('#btnLangManagerClose')) {
requestCloseOverlay(div);
}
};
this.loadLangCatalog();
}
handleGlobalLangUpload(input) {
const file = input.files && input.files[0];
if (!file) return;
const fileName = file.name.toLowerCase();
const codeMatch = fileName.match(/([a-z]{2})\.json(?:\.gz)?$/);
const code = codeMatch ? codeMatch[1] : null;
if (!code) {
ui.serviceError({ desc: tr('ERR_INVALID_LANG_FILENAME') });
input.value = '';
return;
}
const overlay = ui.waitMessage(get('divLangManagerOverlay') || get('divContainer'), 'WAIT_MSG_LANG_IMPORT');
setOverlayLock(get('divLangManagerOverlay'), 'confirm', {
titleKey: 'PROMPT_LANG_ACTION_TITLE',
msgKey: 'PROMPT_LANG_ACTION_MSG',
});
importLangFileManually(code, file)
.then(() => {
clearOverlayLock(get('divLangManagerOverlay'));
input.value = '';
return this.onLanguageChanged(code);
})
.catch(err => {
clearOverlayLock(get('divLangManagerOverlay'));
input.value = '';
if (overlay) overlay.remove();
logger.error('Global manual language upload failed for ' + code + ':', err);
ui.serviceError({ desc: err.message, service: '/uploadLang' });
});
}
loadLangCatalog() {
const panel = get('langCatalog');
if (!panel) return;
const overlay = ui.waitMessage(get('divLangManagerOverlay') || panel, 'WAIT_MSG_LANG_CATALOG');
Promise.all([
deviceFetch('/getAvailableLangs'),
loadLangManifest()
])
.then(([list, manifest]) => this.renderLangCatalog(list, manifest))
.catch(err => {
logger.error('Failed to load language catalog:', err);
ui.serviceError(err);
})
.finally(() => { if (overlay) overlay.remove(); });
}
renderLangCatalog(list, manifest) {
const panel = get('langCatalog');
if (!panel) return;
const activeLang = document.documentElement.lang || window.__defaultLangCode || 'en';
panel.innerHTML = list.map(entry => {
const manifestInfo = manifest && manifest.langs ? manifest.langs[entry.code] : null;
const label = (manifestInfo && manifestInfo.native) || langLabel(entry.code);
const isActive = entry.code === activeLang;
const isPending = window.__pendingLangCode === entry.code;
let badge = '';
if (isActive) badge = `<span class="lang-catalog-badge active">${tr('LANG_MODAL_ACTIVE')}</span>`;
else if (entry.installed) badge = `<span class="lang-catalog-badge">${tr('LANG_MODAL_INSTALLED')}</span>`;
else if (isPending) badge = `<span class="lang-catalog-badge">${tr('LANG_PENDING_BADGE')}</span>`;
let actions = '';
let manualImportBlock = '';
if (!isActive && entry.installed) {
actions = `<button type="button" pop onclick="general.useLang('${entry.code}')">${tr('LANG_MODAL_USE_LANG')}</button>`;
if (entry.code !== window.__defaultLangCode) {
actions += `<button type="button" pop line onclick="general.deleteLang('${entry.code}')">${tr('LANG_MODAL_DELETE_LANG')}</button>`;
}
} else if (!isActive && !entry.installed && entry.downloadable) {
if (isPending) {
manualImportBlock = `
                    <div class="lang-catalog-manual-import">
                        <p class="lang-catalog-manual-import-info">${tr('MSG_LANG_PENDING_INFO')}</p>
                        <button type="button" pop line onclick="general.cancelPendingLang('${entry.code}')">${tr('BT_CANCEL_PENDING')}</button>
                    </div>`;
}
else if (this._manualImportPending.has(entry.code)) {
const rawUrl = manifestInfo && manifestInfo.path ? `${GITHUB_RAW_ROOT}main/${manifestInfo.path}` : '';
manualImportBlock = `
                    <div class="lang-catalog-manual-import">
                        <p class="lang-catalog-manual-import-info">${tr('MSG_LANG_MANUAL_IMPORT_INFO')}</p>
                        ${rawUrl ? `<a href="${rawUrl}" target="_blank" rel="noopener" class="link" style="display:block; margin-bottom:8px;">${tr('LANG_MANUAL_IMPORT_LINK')}<svg class="svgInTextSmall"><use href="#svg-linkOut"></use></svg></a>` : ''}
                        <input id="fileLangImport_${entry.code}" type="file" accept="application/json,.json,application/gzip,.gz" style="display:none"
                        onchange="general.handleManualLangImport('${entry.code}', this)"/>
                        <label for="fileLangImport_${entry.code}" class="custom-file-upload">
                        <span class="file-name-display">${tr('LANG_MODAL_IMPORT_FILE')}</span>
                        <div class="file-icon-btn"><svg><use href="#svg-upload"></use></svg></div>
                        </label>
                        <button type="button" pop line style="margin-top:8px;" onclick="general.setPendingLang('${entry.code}')">${tr('BT_APPLY_LATER')}</button>
                    </div>`;
} else {
actions = `<button type="button" pop onclick="general.downloadLang('${entry.code}')">${tr('LANG_MODAL_DOWNLOAD')}</button>`;
}
}
return `
            <div class="lang-catalog-row" data-code="${entry.code}">
                <div class="lang-catalog-info">
                    <span class="lang-catalog-code">${entry.code}</span>
                    <span>${label}</span>
                    ${badge}
                </div>
                <div class="lang-catalog-progress" id="langProgress_${entry.code}">
                    <div class="progress-bar"><div class="progress-bar-fill"></div></div>
                    <span class="progress-bar-value">0%</span>
                </div>
                <div class="lang-catalog-actions">${actions}</div>
            </div>
            ${manualImportBlock}`;
}).join('');
}
useLang(code) {
this.onLanguageChanged(code).catch(err => ui.serviceError({ desc: err.message, service: '/setLang' }));
}
downloadLang(code) {
this.showLangProgress(code);
if (isApMode) {
this.relayLangDownload(code);
return;
}
setOverlayLock(get('divLangManagerOverlay'), 'confirm', {
titleKey: 'PROMPT_LANG_ACTION_TITLE',
msgKey: 'PROMPT_LANG_ACTION_MSG',
});
deviceFetch('/downloadLang?code=' + code, { method: 'POST' })
.then(resp => {
if (resp.status !== 'queued') {
clearOverlayLock(get('divLangManagerOverlay'));
ui.serviceError(resp);
this.loadLangCatalog();
}
})
.catch(err => {
clearOverlayLock(get('divLangManagerOverlay'));
logger.error('Failed to trigger language download:', err);
ui.serviceError(err);
this.loadLangCatalog();
});
}
relayLangDownload(code) {
setOverlayLock(get('divLangManagerOverlay'), 'confirm', {
titleKey: 'PROMPT_LANG_ACTION_TITLE',
msgKey: 'PROMPT_LANG_ACTION_MSG',
});
return relayLangViaBrowser(code)
.then(() => { clearOverlayLock(get('divLangManagerOverlay')); return this.onLanguageChanged(code); })
.catch(err => {
clearOverlayLock(get('divLangManagerOverlay'));
logger.error('Browser relay failed for language ' + code + ':', err);
if (err.message.startsWith('github-fetch-failed')) {
this._manualImportPending.add(code);
if (get('divLangManagerOverlay')) {
this.loadLangCatalog();
} else {
const pending = new Set(this._manualImportPending);
this.openLangManager();
this._manualImportPending = pending;
}
return;
}
ui.serviceError({ desc: `${tr('MSG_LANG_RELAY_UNAVAILABLE')} (${err.message})`, service: '/uploadLang' });
this.loadLangCatalog();
});
}
handleManualLangImport(code, input) {
const file = input.files && input.files[0];
if (!file) return;
const overlay = ui.waitMessage(get('divLangManagerOverlay') || get('divContainer'), 'WAIT_MSG_LANG_IMPORT');
setOverlayLock(get('divLangManagerOverlay'), 'confirm', {
titleKey: 'PROMPT_LANG_ACTION_TITLE',
msgKey: 'PROMPT_LANG_ACTION_MSG',
});
importLangFileManually(code, file)
.then(() => {
clearOverlayLock(get('divLangManagerOverlay'));
this._manualImportPending.delete(code);
return this.onLanguageChanged(code);
})
.catch(err => {
clearOverlayLock(get('divLangManagerOverlay'));
if (overlay) overlay.remove();
logger.error('Manual language import failed for ' + code + ':', err);
ui.serviceError({ desc: err.message, service: '/uploadLang' });
});
}
setPendingLang(code) {
deviceFetch('/setPendingLang?code=' + code, { method: 'POST' })
.then(resp => {
if (resp.status === 'ok') {
window.__pendingLangCode = code;
localStorage.setItem('pendingLangWatch', code);
this._manualImportPending.delete(code);
this.loadLangCatalog();
} else {
ui.serviceError(resp);
}
})
.catch(err => {
logger.error('Failed to set pending language:', err);
ui.serviceError({ desc: err.message, service: '/setPendingLang' });
});
}
cancelPendingLang(code) {
deviceFetch('/setPendingLang?clear=1', { method: 'POST' })
.then(resp => {
if (resp.status === 'ok') {
window.__pendingLangCode = '';
localStorage.removeItem('pendingLangWatch');
this.loadLangCatalog();
} else {
ui.serviceError(resp);
}
})
.catch(err => logger.error('Failed to cancel pending language:', err));
}
deleteLang(code) {
deviceFetch('/deleteLang?code=' + code, { method: 'POST' })
.then(resp => {
if (resp.status === 'ok') this.loadLangCatalog();
else ui.serviceError(resp);
})
.catch(err => logger.error('Failed to delete language:', err));
}
showLangProgress(code) {
const row = document.querySelector(`.lang-catalog-row[data-code="${code}"]`);
const actions = row ? row.querySelector('.lang-catalog-actions') : null;
if (actions) actions.innerHTML = '';
const prog = get(`langProgress_${code}`);
if (prog) prog.classList.add('active');
}
procLangDownloadProgress(prog) {
const block = get(`langProgress_${prog.code}`);
if (!block) return;
const bar = block.querySelector('.progress-bar');
if (!bar) return;
const pct = prog.total > 0 ? Math.round((prog.loaded / prog.total) * 100) : 0;
bar.style.setProperty('--progress', `${pct}%`);
const value = block.querySelector('.progress-bar-value');
if (value) value.textContent = `${pct}%`;
}
procLangDownloadComplete(msg) {
clearOverlayLock(get('divLangManagerOverlay'));
const toast = get('langPromptToast');
if (toast) toast.remove();
const missingToast = get('langMissingToast');
if (missingToast) missingToast.remove();
if (msg.success) {
this.onLanguageChanged(msg.code).catch(err => ui.serviceError({ desc: err.message, service: '/setLang' }));
} else {
ui.serviceError({ desc: `${msg.code}: download failed`, service: '/downloadLang' });
this.loadLangCatalog();
}
}
showBrowserLangPrompt(code, info) {
if (get('langPromptToast')) return;
const div = document.createElement('div');
div.id = 'langPromptToast';
div.className = 'lang-prompt-toast';
div.innerHTML = `
        <div class="lang-prompt-text">${tr('TOAST_LANG_MSG').replace('{LANG}', info.native)}</div>
        <div class="lang-prompt-actions">
        <button type="button" pop onclick="general.acceptLangPrompt('${code}')">${tr('BT_INSTALL_LANG')}</button>
        <button type="button" pop line onclick="general.snoozeLangPrompt()">${tr('BT_REMIND_LATER')}</button>
        <button type="button" pop line onclick="general.dismissLangPrompt('${code}')">${tr('BT_DONT_ASK_AGAIN')}</button>
        </div>`;
document.body.appendChild(div);
}
acceptLangPrompt(code) {
const toast = get('langPromptToast');
if (toast) {
toast.innerHTML = `<div class="lang-prompt-text">${tr('TOAST_LANG_DOWNLOADING_RELOAD')}</div>`;
}
deviceFetch('/downloadLang?code=' + code, { method: 'POST' })
.then(resp => { if (resp.status !== 'queued') { if (toast) toast.remove(); ui.serviceError(resp); } })
.catch(err => {
if (toast) toast.remove();
logger.error('Failed to trigger language download:', err);
ui.serviceError(err);
});
}
snoozeLangPrompt() {
const toast = get('langPromptToast');
if (toast) toast.remove();
}
dismissLangPrompt(code) {
localStorage.setItem('langPromptDismissed_' + code, '1');
const toast = get('langPromptToast');
if (toast) toast.remove();
}
showLangMissingPrompt(code) {
if (get('langMissingToast')) return;
const div = document.createElement('div');
div.id = 'langMissingToast';
div.className = 'lang-prompt-toast';
div.innerHTML = `
        <div class="lang-prompt-text">${tr('TOAST_LANG_MISSING_MSG').replace('{LANG}', code.toUpperCase())}</div>
        <div class="lang-prompt-actions">
        <button type="button" pop onclick="general.reinstallActiveLang('${code}')">${tr('BT_INSTALL_LANG')}</button>
        <button type="button" pop line onclick="general.dismissLangMissingPrompt()">${tr('BT_REMIND_LATER')}</button>
        </div>`;
document.body.appendChild(div);
}
reinstallActiveLang(code) {
const toast = get('langMissingToast');
if (toast) {
toast.innerHTML = `<div class="lang-prompt-text">${tr('TOAST_LANG_DOWNLOADING_RELOAD')}</div>`;
}
if (isApMode) {
const done = () => { const t = get('langMissingToast'); if (t) t.remove(); };
const chain = this.relayLangDownload(code);
if (chain && typeof chain.then === 'function') chain.then(done, done);
else done();
return;
}
deviceFetch('/downloadLang?code=' + code, { method: 'POST' })
.then(resp => { if (resp.status !== 'queued') { if (toast) toast.remove(); ui.serviceError(resp); } })
.catch(err => {
if (toast) toast.remove();
logger.error('Failed to trigger language download:', err);
ui.serviceError(err);
});
}
dismissLangMissingPrompt() {
const toast = get('langMissingToast');
if (toast) toast.remove();
}
showLangAppliedToast(code) {
if (get('langAppliedToast')) return;
const div = document.createElement('div');
div.id = 'langAppliedToast';
div.className = 'lang-prompt-toast';
const label = langLabel(code);
div.innerHTML = `
        <div class="lang-prompt-text">${tr('TOAST_LANG_PENDING_APPLIED').replace('{LANG}', label)}</div>
        <div class="lang-prompt-actions">
        <button type="button" pop line onclick="get('langAppliedToast').remove();">${tr('BT_CLOSE')}</button>
        </div>`;
document.body.appendChild(div);
}
onModeThemeChanged() {
const sel = get('selThemeMode');
this.applyTheme(sel.value);
}
onSecurityTypeChanged() {
const badge = get('badgeSecurityState');
if (!badge) return;
badge.classList.remove('state-disabled', 'state-pin', 'state-password');
if (this._currentSecurityType === 0) {
badge.textContent = tr('SECURITY_DESACTIVATE');
badge.classList.add('state-disabled');
} else if (this._currentSecurityType === 1) {
badge.textContent = tr('SECURITY_PIN_CODE');
badge.classList.add('state-pin');
} else if (this._currentSecurityType === 2) {
badge.textContent = tr('SECURITY_PASSWORD');
badge.classList.add('state-password');
}
}
SecurityOverlay() {
if (get('divSecurityOverlay')) return;
let div = document.createElement('div');
div.id = 'divSecurityOverlay';
div.className = 'modal-overlay';
const currentType = this._currentSecurityType || 0;
div.innerHTML = `
        <div class="message-content securityOverlay-content" id="divSecurityPopupContent">
        ${modalHeader('GENERAL_SECURITY', 'svg-lock', {
subtitle: 'SECURITY_MODAL_DESC',
})}

        <div class="overlay-scroll-content">

        <div class="SwitchBig SwitchBig-3 dirty-target" id="secTypeSwitch">
        <input type="radio" name="secTypeGroup" id="secType0" value="0" ${currentType === 0 ? 'checked' : ''}>
        <label for="secType0">${tr('SECURITY_DESACTIVATE')}</label>
        <input type="radio" name="secTypeGroup" id="secType1" value="1" ${currentType === 1 ? 'checked' : ''}>
        <label for="secType1">${tr('SECURITY_PIN_CODE')}</label>
        <input type="radio" name="secTypeGroup" id="secType2" value="2" ${currentType === 2 ? 'checked' : ''}>
        <label for="secType2">${tr('SECURITY_PASSWORD')}</label>
        <div class="nav-pill"></div>
        </div>
        <p id="secTypeDesc" class="sec-type-desc"></p>

        <label class="uniRow dirty-target">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#vr-favori"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('SECURITY_SECURE_CONFIG_ONLY')}</div>
        <div class="uniStatus">${tr('SECURITY_SECURE_CONFIG_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch">
        <input id="cbSecureConfigOnly" name="hardwired" type="checkbox" data-bind="security.permissions.configOnly"/>
        <div></div>
        </span>
        </div>
        </label>

        <div id="divPopupPin" class="uniblocCol" style="display: ${currentType === 1 ? 'block' : 'none'};">
        <label class="labelMAJ">${tr('SECURITY_ENTER_PIN')}</label>
        <div class="pin-digit-row">
        <input class="pin-digit" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="1" autocomplete="off">
        <input class="pin-digit" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="1" autocomplete="off">
        <input class="pin-digit" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="1" autocomplete="off">
        <input class="pin-digit" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="1" autocomplete="off">
        </div>
        <p id="secPinHint" class="sec-secret-hint"></p>
        </div>

        <div id="divPopupPassword" style="display: ${currentType === 2 ? 'block' : 'none'};">
        <div class="baseFlexCol">
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-user"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="fldUsername">${tr('SECURITY_USERNAME')}</label>
        <input id="fldUsername" class="inputAndSelect" name="secUsername" autocomplete="off" type="text" data-bind="security.username" placeholder="${tr('SECURITY_USERNAME_PLH')}">
        </div>
        </div>
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-lock"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="fldPassword">${tr('SECURITY_PASSWORD')}</label>
        <input id="fldPassword" class="inputAndSelect" name="secNewPassword" autocomplete="new-password" type="password" placeholder="${tr('SECURITY_PASSWORD_PLH')}">
        <div class="password-eye" onclick="security.toggleFieldPassword('fldPassword', this)"><svg class="pwd-icon pwd-iconeye"><use href="#svg-eyeOff"></use></svg></div>
        </div>
        </div>
        <p id="secPasswordHint" class="sec-secret-hint"></p>
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-lock"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="fldRenterPassword">${tr('SECURITY_CONFIRM_PASSWORD')}</label>
        <input id="fldRenterPassword" class="inputAndSelect" name="secConfirmPassword" autocomplete="new-password" type="password" placeholder="${tr('SECURITY_CONFIRM_PASSWORD')}">
        <div class="password-eye" onclick="security.toggleFieldPassword('fldRenterPassword', this)"><svg class="pwd-icon pwd-iconeye"><use href="#svg-eyeOff"></use></svg></div>
        </div>
        </div>
        </div>
        </div>
        </div>

        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnSecGoBack" line type="button">${tr('BT_CLOSE')}</button>
        <button id="btnPopupSaveSec" type="button"><svg><use href="#svg-save"></use></svg><span>${tr('BT_SAVE')}</span></button>
        </div>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
ui.toElement(div, { security: this._securityData || { username: '', permissions: { configOnly: false } } });
initSecretPinGroup(div.querySelectorAll('#divPopupPin .pin-digit'), this._hasPin);
initSecretField(div.querySelector('#fldPassword'), this._hasPassword);
initSecretField(div.querySelector('#fldRenterPassword'), false);
const setHint = (id, key, show) => {
const el = div.querySelector(id);
if (!el) return;
el.textContent = tr(key);
el.style.display = show ? '' : 'none';
};
setHint('#secPasswordHint', 'SECURITY_PASSWORD_STORED', this._hasPassword);
setHint('#secPinHint', 'SECURITY_PIN_STORED', this._hasPin);
watchDirty(div);
div.querySelector('#btnSecGoBack').onclick = () => requestCloseOverlay(div);
const selectedType = () => {
const checked = div.querySelector('input[name="secTypeGroup"]:checked');
return checked ? parseInt(checked.value, 10) : 0;
};
const SEC_DESC = { 0: 'SECURITY_INACTIVE_DESC', 1: 'SECURITY_PIN_CODE_DESC', 2: 'SECURITY_PASSWORD_DESC' };
const applyType = () => {
const val = selectedType();
div.querySelector('#divPopupPin').style.display = (val === 1) ? 'block' : 'none';
div.querySelector('#divPopupPassword').style.display = (val === 2) ? 'block' : 'none';
const desc = div.querySelector('#secTypeDesc');
if (desc) {
desc.textContent = tr(SEC_DESC[val]);
desc.classList.toggle('is-warning', val === 0);
}
};
div.querySelectorAll('input[name="secTypeGroup"]').forEach(r => r.addEventListener('change', applyType));
applyType();
div.querySelector('#btnPopupSaveSec').onclick = () => { this.saveSecurity(); };
const pinInputs = div.querySelectorAll('.pin-digit');
pinInputs.forEach((input, index) => {
input.addEventListener('input', (e) => {
e.target.value = (e.target.value || '').replace(/\D/g, '');
if (e.target.value.length === 1 && index < pinInputs.length - 1) pinInputs[index + 1].focus();
});
input.addEventListener('keydown', (e) => {
if (e.key === 'Backspace' && e.target.value.length === 0 && index > 0) pinInputs[index - 1].focus();
});
});
}
saveSecurity() {
const popupContent = get('divSecurityPopupContent');
let s;
let finalType = 0;
let pinInputs = [];
let pwdInput = null;
let repeatInput = null;
const overlay = popupContent ? popupContent.closest('.modal-overlay') : null;
if (popupContent) {
const boundData = ui.fromElement(popupContent);
s = (boundData && boundData.security) ? boundData.security : { username: '', permissions: { configOnly: false } };
pinInputs = popupContent.querySelectorAll('#divPopupPin .pin-digit');
pwdInput = popupContent.querySelector('#fldPassword');
repeatInput = popupContent.querySelector('#fldRenterPassword');
const checkedRadio = popupContent.querySelector('input[name="secTypeGroup"]:checked');
finalType = checkedRadio ? parseInt(checkedRadio.value, 10) : this._currentSecurityType;
} else {
s = this._securityData || { username: '', permissions: { configOnly: false } };
finalType = this._currentSecurityType;
}
const pin = secretPinValue(pinInputs);
const pinTouched = pin.length > 0;
const password = pwdInput ? secretValue(pwdInput) : '';
const repeatPassword = repeatInput ? secretValue(repeatInput) : '';
const passwordTouched = !!password || !!repeatPassword;
const clearPassword = finalType !== 2 && this._hasPassword;
const clearPin = finalType !== 1 && this._hasPin;
const clearWarning = (clearPassword || clearPin) ? `<p class="is-warning">${tr('PROMPT_SECURITY_CLEAR_SECRET_DESC')}</p>` : '';
let confirmText = '';
if (finalType === 0) {
confirmText = `<p>${tr('PROMPT_SECURITY_CONFIRM_DESACTIVE')}</p>${clearWarning}`;
}
else if (finalType === 1) {
if (pinTouched) {
if (!/^[0-9]{4}$/.test(pin)) return this.secError('ERR_PIN_INVALID', 'ERR_PIN_INVALID_DESC');
} else if (!this._hasPin) {
return this.secError('ERR_PIN_INVALID', 'ERR_PIN_INVALID_DESC');
}
confirmText = `<p>${tr('PROMPT_SECURITY_PIN_WARNING')}</p><p>${tr('PROMPT_SECURITY_PIN_CONFIRM')}</p>${clearWarning}`;
}
else if (finalType === 2) {
if (!s.username) return this.secError('ERR_USERNAME_MISSING', 'ERR_USERNAME_MISSING_DESC');
if (s.username.length > 32) return this.secError('ERR_USERNAME_INVALID', 'ERR_USERNAME_MAX_LENGTH_32');
if (passwordTouched) {
if (!password) return this.secError('ERR_PASSWORD_MISSING', 'ERR_PASSWORD_MISSING_DESC');
if (password.length > 32) return this.secError('ERR_PASSWORD_INVALID', 'ERR_PASSWORD_MAX_LENGTH_32');
if (!repeatPassword) return this.secError('ERR_PASSWORD_CONFIRM_MISSING', 'ERR_PASSWORD_CONFIRM_MISSING_DESC');
if (password !== repeatPassword) return this.secError('ERR_PASSWORD_MISMATCH', 'ERR_PASSWORD_MISMATCH_DESC');
} else if (!this._hasPassword) {
return this.secError('ERR_PASSWORD_MISSING', 'ERR_PASSWORD_MISSING_DESC');
}
confirmText = `<p>${tr('PROMPT_SECURITY_PASSWORD_WARNING')}</p><p>${tr('PROMPT_SECURITY_PASSWORD_CONFIRM')}</p>${clearWarning}`;
}
const data = {
type: finalType,
username: s.username || '',
password: passwordTouched ? password : '',
pin: pinTouched ? pin : '',
clearPassword: clearPassword,
clearPin: clearPin,
permissions: (s.permissions && s.permissions.configOnly) ? 0x01 : 0x00
};
const applyLocalState = () => {
this._currentSecurityType = finalType;
if (pinTouched) this._hasPin = true;
if (passwordTouched) this._hasPassword = true;
if (clearPin) this._hasPin = false;
if (clearPassword) this._hasPassword = false;
if (popupContent) this._securityData = { username: s.username, permissions: s.permissions };
this.onSecurityTypeChanged();
};
const prompt = ui.promptMessage(tr('PROMPT_SECURITY_CONFIRM'), () => {
if (overlay) { clearDirty(overlay); closeOverlay(overlay); }
putJSONSync('/saveSecurity', data, (e, resp) => {
prompt.remove();
if (e) {
ui.serviceError(e);
return;
}
if (resp && resp.apiKey) security.apiKey = resp.apiKey;
security.type = finalType;
security.permissions = data.permissions;
security.authenticated = (finalType !== 0);
if (finalType === 0) { security.apiKey = ''; security._clearSessionKey(); }
else security._persistSessionKey();
const cont = get('divContainer');
if (cont) cont.setAttribute('data-securitytype', finalType);
applyLocalState();
});
});
prompt.querySelector('.sub-message').innerHTML = confirmText;
}
secError(title, desc) {
ui.errorMessage(tr(title), tr(desc));
}
showHAOverlay() {
const div = document.createElement('div');
div.id = 'divHAConfig';
div.className = 'inst-overlay';
div.innerHTML = `
        <div class="instructions-content showHAOverlay-content">
        ${overlayHeader('HACS', 'HACS_DESC', 'svg-homeAssistant', {
subtitle: "HACS_DESC",
showInfo: false,
showExpert: false
})}
        <div class="overlay-scroll-content">
        <p><strong>${tr('HACS_PURPOSE_TITLE')}</strong></p>
        <p>${tr('HACS_PURPOSE_TEXT_1')}</p>
        <p>${tr('HACS_PURPOSE_TEXT_2')}</p>
        <p class="ha-section-title"><strong>${tr('HACS_INSTALL_TITLE')}</strong></p>
        <ol class="ha-install-list">
        <li>${tr('HACS_INSTALL_STEP_1')}</li>
        <li>${tr('HACS_INSTALL_STEP_2')}</li>
        <li>${tr('HACS_INSTALL_STEP_3')}</li>
        </ol>
        <div class="warning">
        <div class="warning-header">
        <svg><use href="#svg-warning"></use></svg>
        <b>${tr('MSG_WARNING')}</b>
        </div>
        <div class="information-text">
        <span>
        ${tr('HACS_REQ_START')}
        <a href="https://www.home-assistant.io" target="_blank" style="color: inherit; text-decoration: underline;"><strong>Home Assistant</strong></a>
        ${tr('HACS_REQ_MID')}
        <a href="https://hacs.xyz" target="_blank" style="color: inherit; text-decoration: underline;"><strong>HACS</strong></a>
        ${tr('HACS_REQ_END')}
        </span>
        </div>
        </div>
        <div class="ha-badge-container">
        <a href="https://my.home-assistant.io/redirect/hacs_repository/?owner=xkain&repository=ESPSomfy-RTS-enhanced&category=Integration" target="_blank" class="ha-badge-button">
        <span class="ha-badge-text-main">Open HACS repository on</span>
        <span class="ha-badge-pill"><span class="ha-badge-text-pill">MY</span><svg width="18" height="18"><use href="#svg-homeAssistant"></use></svg></span>
        </a>
        <p class="ha-github-link-container">
        ${tr('HACS_OR_VISIT')} <a href="https://github.com/xkain/ESPSomfy-RTS-enhanced" target="_blank" class="ha-github-link">${tr('HACS_GITHUB_LINK')}</a>
        </p>
        </div>
        </div>
        <div class="hrDivFooter-Instruc"></div>
         <div class="button-container-overlay">
        <button id="btnCloseHA" type="button" onclick="closeOverlay(get('divHAConfig'))">${tr('BT_CLOSE')}</button>
        </div>
        </div>`;
shOverlay(div);
}
}
var general = new General();
class Wifi {
initialized = false;
ethBoardTypes = [];
ethClockModes = [];
ethPhyTypes = [];
init() {
this.ethBoardTypes = [
{ val: 0, label: tr("MANUAL_SETTINGS") },
{ val: 1, label: 'WT32-ETH01 - Wireless Tag', clk: 0, ct: 0, addr: 1, pwr: 16, mdc: 23, mdio: 18 },
{ val: 7, label: 'EST-PoE-32 - Everything Smart', clk: 3, ct: 0, addr: 0, pwr: 12, mdc: 23, mdio: 18 },
{ val: 3, label: 'ESP32-EVB - Olimex', clk: 0, ct: 0, addr: 0, pwr: -1, mdc: 23, mdio: 18 },
{ val: 2, label: 'ESP32-POE - Olimex', clk: 3, ct: 0, addr: 0, pwr: 12, mdc: 23, mdio: 18 },
{ val: 4, label: 'T-Internet POE - LILYGO', clk: 3, ct: 0, addr: 0, pwr: 16, mdc: 23, mdio: 18 },
{ val: 5, label: 'wESP32 v7+ - Silicognition', clk: 0, ct: 2, addr: 0, pwr: -1, mdc: 16, mdio: 17 },
{ val: 6, label: 'wESP32 < v7 - Silicognition', clk: 0, ct: 0, addr: 0, pwr: -1, mdc: 16, mdio: 17 }
];
this.ethClockModes = [
{ val: 0, label: 'GPIO0 IN' },
{ val: 1, label: 'GPIO0 OUT' },
{ val: 2, label: 'GPIO16 OUT' },
{ val: 3, label: 'GPIO17 OUT' }
];
this.ethPhyTypes = [
{ val: 0, label: 'LAN8720' },
{ val: 1, label: 'TLK110' },
{ val: 2, label: 'RTL8201' },
{ val: 3, label: 'DP83848' },
{ val: 4, label: 'DM9051' },
{ val: 5, label: 'KZ8081' }
];
this.procWifiStrength({strength: -100, ssid: '', channel: -1});
if (this.initialized) return;
this.loadETHDropdown(get('selETHClkMode'), this.ethClockModes);
this.loadETHDropdown(get('selETHPhyType'), this.ethPhyTypes);
this.loadETHDropdown(get('selETHBoardType'), this.ethBoardTypes);
let addr = [];
for (let i = 0; i < 32; i++) {
addr.push({ val: i, label: `PHY ${i}` });
}
this.loadETHDropdown(get('selETHAddress'), addr);
ui.toElement(get('divNetAdapter'), {
wifi: { ssid: '', passphrase: '' },
ethernet: {
boardType: 1,
wirelessFallback: false,
dhcp: true,
dns1: '',
dns2: '',
ip: '',
gateway: ''
}
});
this.onETHBoardTypeChanged(get('selETHBoardType'));
this.initialized = true;
const inputPwr = get('inputETHPWRPin');
if (inputPwr) {
inputPwr.addEventListener('focus', () => {
if (inputPwr.value === 'None') {
inputPwr.type = 'number';
inputPwr.value = -1;
}
});
inputPwr.addEventListener('blur', () => {
if (inputPwr.value === '-1' || inputPwr.value === '') {
inputPwr.type = 'text';
inputPwr.value = 'None';
}
});
}
}
loadETHDropdown(sel, arr, selected) {
if (!sel) return;
while (sel.firstChild) sel.removeChild(sel.firstChild);
for (let i = 0; i < arr.length; i++) {
let elem = arr[i];
sel.options[sel.options.length] = new Option(elem.label, elem.val, elem.val === selected, elem.val === selected);
}
}
onETHBoardTypeChanged(sel) {
if (!sel) return;
let type = this.ethBoardTypes.find(elem => parseInt(sel.value, 10) === elem.val);
if (typeof type !== 'undefined') {
if (typeof type.ct !== 'undefined') get('selETHPhyType').value = type.ct;
if (typeof type.clk !== 'undefined') get('selETHClkMode').value = type.clk;
if (typeof type.addr !== 'undefined') get('selETHAddress').value = type.addr;
const inputPwr = get('inputETHPWRPin');
if (inputPwr && typeof type.pwr !== 'undefined') {
const isNone = (type.pwr === -1);
if (isNone) {
inputPwr.type = 'text';
inputPwr.value = 'None';
} else {
inputPwr.type = 'number';
inputPwr.value = type.pwr;
}
this.togglePowerIcon(isNone);
}
if (typeof type.mdc !== 'undefined') get('inputETHMDCPin').value = type.mdc;
if (typeof type.mdio !== 'undefined') get('inputETHMDIOPin').value = type.mdio;
get('divETHSettings').style.display = type.val === 0 ? '' : 'none';
}
}
updateEthernetSummary(pinKey, value) {
const targetLabel = pinKey.replace('Pin', '').toUpperCase() + ':';
document.querySelectorAll('#divEthernetSummary .gpioRadio-label').forEach(lbl => {
const text = lbl.textContent.trim();
if (text === targetLabel) {
const valSpan = lbl.nextElementSibling;
if (valSpan && valSpan.classList.contains('gpioRadio-val')) {
valSpan.textContent = (value === -1 || value === 'None') ? 'None' : `GPIO${value}`;
}
}
});
}
togglePowerIcon(isNone) {
const btnIcon = document.querySelector('#btnEthPwrShortcut use');
if (btnIcon) {
btnIcon.setAttribute('href', isNone ? '#svg-powerOff' : '#svg-power');
}
}
stepGpio(pinKey, direction) {
const inputEl = get(`inputETH${pinKey}`);
if (pinKey === 'PWRPin' && inputEl && inputEl.value === 'None' && direction === 1) {
inputEl.type = 'number';
inputEl.value = 0;
inputEl.dispatchEvent(new Event('change', { bubbles: true }));
this.updateEthernetSummary('PWRPin', 0);
this.togglePowerIcon(false);
return;
}
const newValue = stepDeviceGpio(pinKey, direction, 'ETH', 'selETHBoardType', val => val === 0, (typeof somfy !== 'undefined' && somfy.pinMaps) || [{ name: '', maxPins: 39 }]);
if (newValue === undefined) return;
if (pinKey === 'PWRPin' && inputEl) {
const isNone = (parseInt(newValue, 10) === -1 || newValue === '');
if (isNone) {
inputEl.type = 'text';
inputEl.value = 'None';
} else {
inputEl.type = 'number';
}
this.togglePowerIcon(isNone);
}
this.updateEthernetSummary(pinKey, newValue);
}
setPowerToNone() {
const inputPwr = get('inputETHPWRPin');
if (!inputPwr) return;
if (inputPwr.value === 'None') {
inputPwr.type = 'number';
inputPwr.value = 0;
inputPwr.dispatchEvent(new Event('change', { bubbles: true }));
this.updateEthernetSummary('PWRPin', 0);
this.togglePowerIcon(false);
return;
}
inputPwr.type = 'text';
inputPwr.value = -1;
inputPwr.dispatchEvent(new Event('change', { bubbles: true }));
inputPwr.type = 'text';
inputPwr.value = 'None';
this.updateEthernetSummary('PWRPin', -1);
this.togglePowerIcon(true);
}
loadNetwork() {
let pnl = get('divNetAdapter');
getJSONSync('/networksettings', (err, settings) => {
if (err) {
ui.serviceError(err);
return;
}
get('cbHardwired').checked = settings.connType >= 2;
get('cbFallbackWireless').checked = settings.connType === 3;
ui.toElement(pnl, settings);
const inputPwr = get('inputETHPWRPin');
if (inputPwr && settings.ethernet && settings.ethernet.PWRPin !== undefined) {
const pwrVal = parseInt(settings.ethernet.PWRPin, 10);
const isNone = (pwrVal === -1);
if (isNone) {
inputPwr.type = 'text';
inputPwr.value = 'None';
} else {
inputPwr.type = 'number';
inputPwr.value = pwrVal;
}
this.togglePowerIcon(isNone);
this.updateEthernetSummary('PWRPin', pwrVal);
}
this._ipData = settings.ip || { dhcp: true, ip: '', subnet: '', gateway: '', dns1: '', dns2: '' };
this._hasApPassword = !!(settings.wifi && settings.wifi.hasApPassword);
this._hasPassphrase = !!(settings.wifi && settings.wifi.hasPassphrase);
this.updateDHCPBadge(this._ipData.dhcp);
get('divETHSettings').style.display = settings.ethernet.boardType === 0 ? '' : 'none';
get('spanCurrentIP').innerHTML = this._ipData.ip;
this.updateStatusBadge(settings);
this.setConnectionType(settings.connType >= 2);
this.useEthernetClicked();
this.hiddenSSIDClicked();
watchDirty(pnl);
});
}
applyNetType(type) {
const isAP = type === 'hotspot';
const wifiBadge = document.getElementById('wifiBadge');
if (wifiBadge) {
wifiBadge.textContent = isAP ? 'AP' : 'WIFI';
wifiBadge.setAttribute('data-conn', isAP ? 'hotspot' : 'wifi');
wifiBadge.setAttribute('title', tr(isAP ? 'TOPBAR_TOOLTIP_AP' : 'TOPBAR_TOOLTIP_WIFI'));
}
const options = document.querySelectorAll('.opt-badge');
if (!options.length) return;
options.forEach(opt => {
opt.classList.toggle('active', opt.getAttribute('data-conn') === type);
});
this._netType = type;
this.updateMobileNetStatus();
}
updateStatusBadge(settings) {
let activeType = "wifi";
if (this.isHotspot) {
activeType = "hotspot";
}
else if (settings && parseInt(settings.connType) >= 2) {
const boardType = (settings.ethernet && settings.ethernet.boardType !== undefined) ? parseInt(settings.ethernet.boardType) : 0;
const pwrPin = (settings.ethernet && settings.ethernet.PWRPin !== undefined) ? parseInt(settings.ethernet.PWRPin) : -1;
if (boardType === 1) {
activeType = "lan";
} else if (pwrPin !== -1) {
activeType = "poe";
} else {
activeType = "lan";
}
}
this.applyNetType(activeType);
}
updateMobileNetStatus() {
const use = get('mobileNetIcon'), dot = get('mobileNetDot'), wrap = get('mobileNetStatus');
if (!use || !dot) return;
const type = this._netType || (this.isHotspot ? 'hotspot' : 'wifi');
const ICONS = { hotspot: '#svg-hotspot', wifi: '#svg-wifi', lan: '#svg-ethernet', poe: '#svg-ethernet0' };
use.setAttribute('href', ICONS[type] || '#svg-wifi');
const up = (type === 'hotspot') ? true
: (type === 'wifi') ? !!this._wifiLinkUp
: !!this._ethLinkUp;
dot.classList.toggle('is-up', up);
dot.classList.toggle('is-down', !up);
if (wrap) {
const label = (type === 'hotspot') ? 'HOTSPOT' : type.toUpperCase();
wrap.setAttribute('title', `${label} — ${tr(up ? 'NET_STATUS_UP' : 'NET_STATUS_DOWN')}`);
}
}
setConnectionType(isEthernet) {
this.useEthernetClicked();
}
useEthernetClicked() {
let useEthernet = get('cbHardwired').checked;
get('divWiFiMode').style.display = useEthernet ? 'none' : '';
get('divRoaming').style.display = useEthernet ? 'none' : '';
get('divHiddenSSID').style.display = useEthernet ? 'none' : '';
get('divEthernetSection').style.display = useEthernet ? '' : 'none';
get('divEthernetMode').style.display = useEthernet ? '' : 'none';
}
hiddenSSIDClicked() {
const cbHidden = get('cbHiddenSSID');
const cbRoaming = get('cbRoaming');
const divRoaming = get('divRoaming');
if (!cbHidden || !cbRoaming) return;
const isHiddenActive = cbHidden.checked;
if (isHiddenActive) {
cbRoaming.checked = false;
}
cbRoaming.disabled = isHiddenActive;
if (divRoaming) {
if (isHiddenActive) {
divRoaming.classList.add('is-disabled');
} else {
divRoaming.classList.remove('is-disabled');
}
}
}
apPasswordOverlay() {
if (get('divAPPasswordOverlay')) return;
let div = document.createElement('div');
div.id = 'divAPPasswordOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content apPassword-content">
        ${modalHeader('CONNEXION_AP_TITLE', 'svg-hotspot', {
subtitle: 'AP_MODAL_TITLE_DESC',
})}

        <div class="overlay-scroll-content">
        <div class="uniblocCol">
        <p>${tr('AP_MODAL_DESC')}</p>
        </div>
        <div class="uniblocCol dirty-target">
        <label class="label" for="fldAPPassword">${tr('CONNEXION_AP_PASSWORD')}</label>
        <div class="password-container">
        <input id="fldAPPassword" class="inputAndSelect" name="apPassword" type="password" minlength="8" placeholder="${tr('SECURITY_PASSWORD_PLH_SIMPLE')}">
        <div class="password-eye" onclick="security.toggleFieldPassword('fldAPPassword', this)"><svg class="pwd-icon pwd-iconeye"><use href="#svg-eyeOff"></use></svg></div>
        </div>
        </div>
        <div class="warning">
        <div class="warning-header">
        <svg><use href="#svg-warning"></use></svg>
        <b>${tr('MSG_WARNING')}</b>
        </div>
        <div class="information-text">
        <span>${tr('AP_MODAL_WARNING')}</span>
        </div>
        </div>
        </div>
        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnAPPasswordClose" line type="button">${tr('BT_CLOSE')}</button>
        <button id="btnSaveAPPassword" type="button">
        <svg><use href="#svg-save"></use></svg>
        <span>${tr('BT_SAVE')}</span>
        </button>
        </div>
        </div>
        </div>`;
shOverlay(div);
initSecretField(div.querySelector('#fldAPPassword'), this._hasApPassword);
watchDirty(div);
div.querySelector('#btnAPPasswordClose').onclick = () => requestCloseOverlay(div);
div.querySelector('#btnSaveAPPassword').onclick = () => this.saveAPPassword(div);
}
saveAPPassword(overlayEl) {
if (!overlayEl) overlayEl = get('divAPPasswordOverlay');
if (!overlayEl) return;
const pwd = secretValue(overlayEl.querySelector('#fldAPPassword'));
if (pwd.length > 0 && pwd.length < 8) {
ui.errorMessage(tr('ERR_AP_PASSWORD_INVALID'), tr('ERR_AP_PASSWORD_INVALID_DESC'));
return;
}
if (pwd.length > 63) {
ui.errorMessage(tr('ERR_AP_PASSWORD_INVALID'), tr('ERR_AP_PASSWORD_MAX_LENGTH_63'));
return;
}
putJSONSync('/setNetwork', { wifi: { apPassword: pwd } }, (err, response) => {
if (err) {
ui.serviceError(err);
} else {
if (pwd.length > 0) this._hasApPassword = true;
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
clearDirty();
closeOverlay(overlayEl);
}
});
}
wifiOverlay(modalTitle, startAtPage2 = false, onCapture = null) {
if (get('divWifiScanOverlay')) return;
let div = document.createElement('div');
div.id = 'divWifiScanOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content wifiOverlay-content">
        ${modalHeader(modalTitle, 'svg-wifi', {
subtitle: startAtPage2 ? 'CONNEXION_MODAL_SELECT_M_DESC' : 'CONNEXION_MODAL_SELECT_DESC',
rightContent: `<!-- Ton contenu de droite si nécessaire -->`
})}
        <!-- Seule cette zone défile -- le header et le pied de page restent fixes, comme sur
        les autres modal-overlay (cf. apPasswordOverlay/ledOverlay). -->
        <div class="overlay-scroll-content">
        <!-- CARROUSEL CONTAINER -->
        <div id="wifiCarousel">
        <!-- PAGE 1 : Liste des réseaux -->
        <div id="wifiPage1" class="wifiChoosePage">
        <div class="blocdivApsOverlay"><div id="divApsOverlay" data-lastloaded="0"></div></div>
        <div class="divbtsTButton">
        <button id="btnManualWifi" type="button" btsText><svg><use href="#svg-add"></use></svg><span>${tr("BT_ADD_MANUAL")}</span></button>
        <button id="btnRefreshWifiInModal" type="button" btsText><svg><use href="#svg-retry"></use></svg><span>${tr("BT_RETRY")}</span></button>
        </div>
        </div>

        <!-- PAGE 2 : Saisie SSID & Mot de passe -->
        <div id="wifiPage2" class="wifiChoosePage">
        <!-- On affiche le bouton Retour UNIQUEMENT si on n'a pas démarré directement à la page 2 -->
        <div class="marginB" style="display: ${startAtPage2 ? 'none' : 'flex'};">
        <button id="btnModalBackToPage1" type="button" btsText><svg><use href="#svg-arrowLeft"></use></svg><span>${tr("BT_GO_BACK")}</span></button>
        </div>
        <!-- Marge de compensation si le bouton retour est masqué -->
        <div style="height: ${startAtPage2 ? '25px' : '0px'};"></div>
        <!-- Bloc des inputs -->
        <div class="baseFlexCol">
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-ssid"></use></svg></div>
        <div class="unifield-content" style="width: 100%;">
        <label class="label">${tr("CONNEXION_WIFI_SSID")}</label>
        <input id="modalFldSsid" class="inputAndSelect" type="text" tr="CONNEXION_WIFI_ENTER_SSID" placeholder="Entrer votre SSID">
        </div>
        </div>
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-lock"></use></svg></div>
        <div class="unifield-content">
        <label class="label">${tr("SECURITY_PASSWORD")}</label>
        <input id="modalFldPassphrase" class="inputAndSelect" type="password" placeholder="${tr("SECURITY_PASSWORD_PLH")}">
        <div class="password-eye" onclick="security.toggleFieldPassword('modalFldPassphrase', this)">
        <svg class="pwd-icon pwd-iconeye"><use href="#svg-eyeOff"></use></svg>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        <!-- Pied de page commun aux 2 pages : hors du carrousel qui glisse (donc fixe, comme
        sur les autres modal-overlay), son contenu bascule au fil de slideCarousel(). -->
        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal" id="wifiFooterPage1">
        <button id="btnWifiGoBack" line type="button">${tr('BT_CLOSE')}</button>
        </div>
        <div class="button-content-modal" id="wifiFooterPage2" style="display: none;">
        <button id="btnModalCancelWifi2" line type="button">${tr('BT_CANCEL_1')}</button>
        <button id="btnModalSaveWifi" type="button"><svg><use href="#svg-succes"></use></svg><span>${tr("BT_CONFIRM")}</span></button>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
watchDirty(div);
get('btnRefreshWifiInModal').onclick = () => this.loadAPs(true);
get('btnWifiGoBack').onclick = () => this.cancelScan();
get('btnManualWifi').onclick = () => {
this.setupManualInputMode();
this.slideCarousel(1);
setTimeout(() => { get('modalFldSsid').focus(); }, 350);
};
get('btnModalBackToPage1').onclick = () => this.slideCarousel(0);
const btnCancel2 = get('btnModalCancelWifi2');
if (btnCancel2) {
btnCancel2.onclick = () => this.cancelScan();
}
get('btnModalSaveWifi').onclick = () => {
const ssidVal = get('modalFldSsid').value || '';
const passVal = get('modalFldPassphrase').value || '';
if (!ssidVal.trim()) {
ui.errorMessage(tr('ERR_WIFI_SSID_INVALID'));
return;
}
if (ssidVal.length > 64) {
ui.errorMessage(tr('ERR_WIFI_SSID_INVALID'), tr('ERR_WIFI_SSID_MAX_LENGTH_64'));
return;
}
if (passVal.length > 64) {
ui.errorMessage(tr('ERR_WIFI_PASSPHRASE_INVALID'), tr('ERR_WIFI_PASSPHRASE_MAX_LENGTH_64'));
return;
}
this.cancelScan();
if (typeof onCapture === 'function') { onCapture(); return; }
const currentHostname = window.__currentHostname || (window.settings && window.settings.hostname) || 'espsomfyrts';
this.networkConfirmationOverlay(currentHostname);
};
get('modalFldSsid').oninput = (e) => {
const realSsid = document.getElementsByName('ssid')[0];
if (realSsid) {
realSsid.value = e.target.value;
realSsid.dispatchEvent(new Event('input'));
}
};
get('modalFldPassphrase').oninput = (e) => {
const realPass = document.getElementsByName('passphrase')[0];
if (realPass) {
realPass.value = e.target.value;
realPass.dispatchEvent(new Event('input'));
}
};
if (startAtPage2) {
this.setupManualInputMode();
const carousel = get('wifiCarousel');
carousel.style.transition = 'none';
this.slideCarousel(1);
setTimeout(() => {
carousel.style.transition = 'transform 0.35s cubic-bezier(0.25, 1, 0.5, 1)';
get('modalFldSsid').focus();
}, 50);
} else {
this.loadAPs(true);
}
}
setupManualInputMode() {
const modalSsid = get('modalFldSsid');
if (modalSsid) {
modalSsid.value = document.getElementsByName('ssid')[0]?.value || '';
modalSsid.removeAttribute('readonly');
modalSsid.style.opacity = '1';
modalSsid.style.background = 'none';
}
const modalPass = get('modalFldPassphrase');
if (modalPass) {
modalPass.value = document.getElementsByName('passphrase')[0]?.value || '';
}
}
slideCarousel(pageIndex) {
const carousel = get('wifiCarousel');
if (carousel) {
carousel.style.transform = `translateX(-${pageIndex * 50}%)`;
}
const footer1 = get('wifiFooterPage1');
const footer2 = get('wifiFooterPage2');
if (footer1) footer1.style.display = pageIndex === 0 ? 'flex' : 'none';
if (footer2) footer2.style.display = pageIndex === 1 ? 'flex' : 'none';
}
async loadAPs(forceLoader = false) {
const btnScan = get('btnRefreshWifiInModal');
const divAps = get('divApsOverlay');
if (!divAps) {
this.wifiOverlay();
return;
}
if (btnScan && btnScan.classList.contains('disabled')) return;
divAps.innerHTML = `<div class="no-wifi"><div class="wifiConnectScan"><svg class="wait-spinner" viewBox="25 25 50 50"><circle class="wait-spinner-track" cx="50" cy="50" r="20" fill="none" stroke-width="3"/><circle class="wait-spinner-arc" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10"/></svg></div><div class="loadAPScan">${tr("WAIT_MSG_SCANNING")}</div></div>`;
if (btnScan) btnScan.classList.add('disabled');
const overlay = get('divWifiScanOverlay');
setOverlayLock(overlay, 'confirm', {
onConfirm: () => { if (btnScan) btnScan.classList.remove('disabled'); },
titleKey: 'PROMPT_WIFI_SCAN_TITLE',
msgKey: 'PROMPT_WIFI_SCAN_MSG',
});
setTimeout(() => {
getJSON('/scanaps', (err, aps) => {
if (err) logger.error('Wi-Fi scan failed:', err);
else logger.debug('Wi-Fi scan found', aps?.accessPoints?.length || 0, 'access points');
if (btnScan) btnScan.classList.remove('disabled');
clearOverlayLock(overlay);
if (err || !aps || !aps.accessPoints) {
this.displayAPs({ accessPoints: [] });
} else {
this.displayAPs(aps);
}
});
}, forceLoader ? 100 : 0);
}
displayAPs(aps) {
let nets = [];
if (aps && aps.accessPoints) {
for (let i = 0; i < aps.accessPoints.length; i++) {
let ap = aps.accessPoints[i];
let p = nets.find(elem => elem.name === ap.name);
if (p) {
p.channel = p.strength > ap.strength ? p.channel : ap.channel;
p.macAddress = p.strength > ap.strength ? p.macAddress : ap.macAddress;
p.strength = Math.max(p.strength, ap.strength);
} else {
nets.push(ap);
}
}
}
nets.sort((a, b) => b.strength - a.strength);
let div = "";
if (nets.length > 0) {
for (let i = 0; i < nets.length; i++) {
let ap = nets[i];
div += `<div class="network-wifi-row" onclick="wifi.selectSSID(this);" data-channel="${ap.channel}" data-encryption="${ap.encryption}" data-strength="${ap.strength}" data-mac="${escAttr(ap.macAddress)}"><span class="ssid">${escHtml(ap.name)}</span><span class="strength">${this.displaySignal(ap.strength)}</span></div>`;
}
} else {
div = `<div class="no-wifi"><div>${tr("ERR_NO_WIFI_FOUND")}</div></div>`;
}
let divAps = get('divApsOverlay');
if (divAps) {
divAps.setAttribute('data-lastloaded', new Date().getTime());
divAps.innerHTML = div;
}
}
cancelScan() {
const overlay = get('divWifiScanOverlay');
if (!overlay) return;
clearDirty(overlay);
requestCloseOverlay(overlay);
}
selectSSID(el) {
let obj = {
name: el.querySelector('span.ssid').textContent,
encryption: el.getAttribute('data-encryption'),
strength: parseInt(el.getAttribute('data-strength'), 10),
channel: parseInt(el.getAttribute('data-channel'), 10)
};
logger.debug('SSID selected:', obj);
const realSsidField = document.getElementsByName('ssid')[0];
if (realSsidField) {
realSsidField.value = obj.name;
realSsidField.dispatchEvent(new Event('input'));
}
const modalSsidField = get('modalFldSsid');
if (modalSsidField) {
modalSsidField.value = obj.name;
}
const realPassField = document.getElementsByName('passphrase')[0];
const modalPassField = get('modalFldPassphrase');
if (realPassField && modalPassField) {
modalPassField.value = realPassField.value;
}
this.slideCarousel(1);
setTimeout(() => {
if (modalPassField) modalPassField.focus();
}, 350);
}
networkConfirmationOverlay(hostname, pendingObj) {
if (get('divNetworkConfirmationOverlay')) return;
let div = document.createElement('div');
div.id = 'divNetworkConfirmationOverlay';
div.className = 'modal-overlay';
const host = hostname || 'espsomfyrts';
const hostUrl = host.toLowerCase();
div.innerHTML = `
        <div class="message-content confirmNetwork-content">
        <div class="modal-mobile-handle" onclick="handleMobileDismiss(this)"></div>
        <!-- Pas de modalHeader() ici (confirmNetwork-header est un en-tête custom), mais on
        garde le même principe que les autres modal-overlay : l'en-tête reste hors de
        overlay-scroll-content pour rester fixe pendant que le corps défile. -->
        <div class="confirmNetwork-header">
        <div class="confirmNetwork-icon"><svg><use href="#svg-save"></use></svg></div>
        <h3>${tr("SAVEWIFI_TITLE")}</h3>
        </div>
        <p class="confirmNetwork-intro">${tr("SAVEWIFI_INTRO")}</p>
        <div class="overlay-scroll-content">
        <div class="confirmNetwork-body">

        <p class="alert-desc-sub">${tr("FIRST_CONNECT_HOSTNAME_DESC")}</p>
        <div class="uniRow dirty-target">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-hostName"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="txtConfirmHostname">${tr("GENERAL_HOSTNAME")}</label>
        <input id="txtConfirmHostname" class="inputAndSelect" type="text" length="32" value="${host}">
        </div>
        </div>
        </div>
        <div>
        <div class="alert-title">${tr("SAVEWIFI_ACCES_AFTER")}</div>
        <p class="alert-desc-sub">${tr("SAVEWIFI_AFTER_DESC_0")}</p>
        <div class="links-container">
        <a id="lnkConfirmHostLocal" href="http://${hostUrl}.local" target="_blank">http://${hostUrl}.local</a>
        <span class="or-separator">${tr("SAVEWIFI_AFTER_DESC_1")}</span>
        <a id="lnkConfirmHostPlain" href="http://${hostUrl}" target="_blank">http://${hostUrl}</a>
        </div>
        <p class="alert-desc-sub">${tr("SAVEWIFI_AFTER_DESC_2")}</p>
        </div>
        </div>
        <div class="hrMessage"></div>
        <div class="confSaveWifi-divStepsTitle">
        <div class="confSaveWifi-stepsTitle">${tr("SAVEWIFI_STEP")}</div>
        <ol class="confSaveWifi-steps">
        <li>${tr("SAVEWIFI_STEP_0")}</li>
        <li>${tr("SAVEWIFI_STEP_1")}</li>
        <li>${tr("SAVEWIFI_STEP_2")}</li>
        </ol>
        </div>
        </div>

        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnConfirmNetCancel" type="button" line>${tr("BT_CANCEL_1")}</button>
        <button id="btnConfirmNetSave" type="button">
        <svg><use href="#svg-save"></use></svg>
        <span>${tr("BT_SAVE")}</span>
        </button>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
get('btnConfirmNetCancel').onclick = () => closeOverlay(div);
const hostFld = get('txtConfirmHostname');
const lnkLocal = get('lnkConfirmHostLocal');
const lnkPlain = get('lnkConfirmHostPlain');
const syncHostLinks = () => {
const h = ((hostFld.value || '').trim() || 'espsomfyrts').toLowerCase();
if (lnkLocal) { lnkLocal.href = `http://${h}.local`; lnkLocal.textContent = `http://${h}.local`; }
if (lnkPlain) { lnkPlain.href = `http://${h}`; lnkPlain.textContent = `http://${h}`; }
};
if (hostFld) hostFld.oninput = syncHostLinks;
get('btnConfirmNetSave').onclick = () => {
const hostVal = hostFld ? (hostFld.value || '').trim() : '';
if (hostFld && (!hostVal || !/^[a-zA-Z0-9-]+$/.test(hostVal) || hostVal.length > 32)) {
ui.errorMessage(tr('ERR_HOSTNAME'), tr('ERR_HOSTNAME_CHARS'));
return;
}
get('btnConfirmNetCancel').disabled = true;
get('btnConfirmNetSave').disabled = true;
ui.waitMessage(div, 'WAIT_MSG_NET_SWITCH');
const proceed = () => {
if (pendingObj) this.sendNetworkSettings(pendingObj);
else if (this.saveNetwork) this.saveNetwork();
};
if (hostVal && hostVal !== (window.__currentHostname || '')) {
putJSONSync('/setgeneral', { hostname: hostVal }, (err) => {
if (err) logger.error('Failed to save hostname from network confirmation:', err);
else window.__currentHostname = hostVal;
proceed();
});
}
else proceed();
};
}
calcWaveStrength(sig) {
let wave = 0;
if (sig > -90) wave = 0;
if (sig > -80) wave = 1;
if (sig > -70) wave = 2;
if (sig > -60) wave = 3;
return wave;
}
displaySignal(sig) {
let level = this.calcWaveStrength(sig);
if (level > 3) level = 3;
let colorSuffix = 'bad';
if (level >= 2) colorSuffix = 'good';
else if (level === 1) colorSuffix = 'medium';
const getPart = (idNum) => {
const active = idNum <= level;
const fillColor = active ? `var(--color-signal-${colorSuffix})` : '#ccc';
return `<use href="#svg-wifi-${idNum}" fill="${fillColor}" style="opacity:${active ? '1' : '0.3'}" />`;
};
return `
        <div class="signal">
        <svg>
        ${getPart(0)}
        ${getPart(1)}
        ${getPart(2)}
        ${getPart(3)}
        </svg>
        </div>`;
}
DHCPOverlay() {
if (get('divDHCPOverlay')) return;
let div = document.createElement('div');
div.id = 'divDHCPOverlay';
div.className = 'inst-overlay';
div.innerHTML = `
        <div class="instructions-content overlaydhcp" id="divDHCPPopupContent">

        ${overlayHeader("CONNEXION_DHCP", "CONNEXION_DHCP_DESC", "svg-hostName", { subtitle: "CONNEXION_DHCP_DESC", showInfo: false })}

        <div class="overlay-scroll-content" id="divDHCPScrollContent">

        <div class="SwitchBig">
        <input id="cbPopupDHCP" type="checkbox" name="dhcp" data-bind="ip.dhcp"/>
        <label for="cbPopupDHCP" class="label-left" >${tr('CONNEXION_BADGE_STATIC')}</label>
        <label for="cbPopupDHCP" class="label-right" >${tr('CONNEXION_BADGE_DHCP')}</label>
        <div class="nav-pill"></div>
        </div>

        <div id="divPopupStaticIP" style="display: none; margin-top: 15px;">
        <div class="uniblocCol">

        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-ip"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="fldIPAddress" tr="DHCP_OVERLAY_STATIC_IP"></label>
        <input id="fldIPAddress" class="inputAndSelect" name="staticIP" type="text" data-bind="ip.ip" length=32 placeholder="0.0.0.0">
        </div>
        </div>

        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-gatewayMask"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="fldSubnetMask" tr="DHCP_OVERLAY_SUBNET_MASK"></label>
        <input id="fldSubnetMask" class="inputAndSelect" name="subnet" type="text" data-bind="ip.subnet" length=32 placeholder="0.0.0.0">
        </div>
        </div>

        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-gateway"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="fldGateway" tr="DHCP_OVERLAY_GATEWAY"></label>
        <input id="fldGateway" class="inputAndSelect" name="gateway" type="text" data-bind="ip.gateway" length=32 placeholder="0.0.0.0">
        </div>
        </div>

        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-dns1"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="fldDNS1" tr="DHCP_OVERLAY_DNS1"></label>
        <input id="fldDNS1" class="inputAndSelect" name="dns1" type="text" data-bind="ip.dns1" length=32 placeholder="0.0.0.0">
        </div>
        </div>

        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-dns2"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="fldDNS2" tr="DHCP_OVERLAY_DNS2"></label>
        <input id="fldDNS2" class="inputAndSelect" name="dns2" type="text" data-bind="ip.dns2" length=32 placeholder="0.0.0.0">
        </div>
        </div>

        </div>
        </div>

        <div class="information">
        <div class="information-header">
        <svg><use href="#svg-info"></use></svg>
        <b>${tr('MSG_INFO')}</b>
        </div>
        <div class="information-text">
        <span>${tr('DHCP_OVERLAY_REBOOT_INFO')}</span>
        </div>
        </div>

        </div>
        <div class="hrDivFooter"></div>
        <div class="button-container-overlay">
        <button id="btnDHCPGoBack" line type="button">${tr('BT_CLOSE')}</button>
        <button id="btnPopupSaveIPSettings" type="button">
        <svg><use href="#svg-save"></use></svg>
        <span>${tr('BT_SAVE')}</span>
        </button>
        </div>

        </div>`;
shOverlay(div);
ui.toElement(div, { ip: this._ipData || { dhcp: true, ip: '', subnet: '', gateway: '', dns1: '', dns2: '' } });
watchDirty(div);
const cbDHCP = div.querySelector('#cbPopupDHCP');
const divStatic = div.querySelector('#divPopupStaticIP');
const toggleStaticFields = (isDhcpEnabled) => {
divStatic.style.display = isDhcpEnabled ? 'none' : 'block';
};
if (cbDHCP) {
toggleStaticFields(cbDHCP.checked);
cbDHCP.onclick = (e) => {
toggleStaticFields(e.target.checked);
};
}
div.querySelector('#btnDHCPGoBack').onclick = () => requestCloseOverlay(div);
div.querySelector('#btnPopupSaveIPSettings').onclick = () => {
clearDirty();
this.saveIPSettings();
closeOverlay(div);
};
}
updateDHCPBadge(isDhcp) {
const badge = get('badgeDHCPState');
if (badge) {
if (isDhcp) {
badge.innerText = tr('CONNEXION_BADGE_DHCP');
} else {
badge.innerText = tr('CONNEXION_BADGE_STATIC');
}
}
}
saveIPSettings() {
let overlay = get('divDHCPOverlay');
if (!overlay) return;
let obj = ui.fromElement(overlay).ip;
logger.debug('Saving IP settings:', obj);
if (!obj.dhcp) {
let fnValidateIP = (addr) => {
return /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(addr);
};
if (typeof obj.ip !== 'string' || obj.ip.length === 0 || obj.ip === '0.0.0.0') {
ui.errorMessage(tr('ERR_STATIC_IP_REQUIRED'));
return;
}
else if (!fnValidateIP(obj.ip)) {
ui.errorMessage(tr('ERR_STATIC_IP_INVALID'));
return;
}
if (typeof obj.subnet !== 'string' || obj.subnet.length === 0 || obj.subnet === '0.0.0.0') {
ui.errorMessage(tr('ERR_NETMASK_REQUIRED'));
return;
}
else if (!fnValidateIP(obj.subnet)) {
ui.errorMessage(tr('ERR_NETMASK_INVALID'));
return;
}
if (typeof obj.gateway !== 'string' || obj.gateway.length === 0 || obj.gateway === '0.0.0.0') {
ui.errorMessage(tr('ERR_GATEWAY_REQUIRED'));
return;
}
else if (!fnValidateIP(obj.gateway)) {
ui.errorMessage(tr('ERR_GATEWAY_INVALID'));
return;
}
if (obj.dns1.length !== 0 && !fnValidateIP(obj.dns1)) {
ui.errorMessage(tr('ERR_DNS1_INVALID'));
return;
}
if (obj.dns2.length !== 0 && !fnValidateIP(obj.dns2)) {
ui.errorMessage(tr('ERR_DNS2_INVALID'));
return;
}
}
putJSONSync('/setIP', obj, (err, response) => {
if (err) {
ui.serviceError(err);
} else {
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
logger.debug('IP settings saved:', response);
this._ipData = obj;
this.updateDHCPBadge(obj.dhcp);
closeOverlay(overlay);
}
});
}
saveNetwork() {
let pnl = get('divNetAdapter'), obj = ui.fromElement(pnl);
if (!obj.ethernet) obj.ethernet = {};
const ethPnl = get('divETHSettings');
if (ethPnl && !pnl.contains(ethPnl)) {
const extra = ui.fromElement(ethPnl);
if (extra && extra.ethernet) obj.ethernet = Object.assign({}, obj.ethernet, extra.ethernet);
}
const cbHardwired = get('cbHardwired');
if (cbHardwired) {
obj.ethernet.hardwired = cbHardwired.checked;
}
const eth = obj.ethernet;
if (isNaN(eth.PWRPin) || eth.PWRPin === 'None' || eth.PWRPin === '') {
eth.PWRPin = -1;
}
obj.connType = eth.hardwired ? (eth.wirelessFallback ? 3 : 2) : 1;
if (obj.connType >= 2) {
const container = get('divContainer');
const isBOXEth = container && container.getAttribute('data-hardwareprofile') === 'BOX-ETH';
if (isBOXEth) this.networkConfirmationOverlay(this._currentHostname(), obj);
else this.ethernetConfirmationOverlay(obj);
return;
}
this.sendNetworkSettings(obj);
}
_currentHostname() {
return window.__currentHostname || (window.settings && window.settings.hostname) || 'espsomfyrts';
}
ethernetConfirmationOverlay(obj) {
if (get('divEthernetConfirmationOverlay')) return;
const div = document.createElement('div');
div.id = 'divEthernetConfirmationOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content">
        ${modalHeader('ETH_SETTINGS_TITLE', 'svg-ethernet', {
subtitle: 'ETH_SETTINGS_DESC',
})}
        <div class="overlay-scroll-content">
        <div class="uniblocCol"><p>${tr("ETH_SETTINGS_WARNING_DESC_1")}</p></div>
        ${this._ethSummaryHtml(obj.ethernet)}
        </div>
        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnEthConfirmCancel" line type="button">${tr("BT_CANCEL_1")}</button>
        <button id="btnEthConfirmNext" type="button">
        <span>${tr("BT_CONFIRM")}</span>
        <svg class="btnArrowRight"><use href="#svg-arrowRight"></use></svg>
        </button>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
get('btnEthConfirmCancel').onclick = () => closeOverlay(div);
get('btnEthConfirmNext').onclick = () => {
closeOverlay(div);
this.networkConfirmationOverlay(this._currentHostname(), obj);
};
}
_ethSummaryHtml(eth) {
const board = this.ethBoardTypes.find(e => eth.boardType === e.val);
const phy = this.ethPhyTypes.find(e => eth.phyType === e.val);
const clk = this.ethClockModes.find(e => eth.CLKMode === e.val);
const line = (labelKey, value) => `<div class="eth-setting-line"><label>${tr(labelKey)}</label><span>${value}</span></div>`;
return `
        <div class="blocEthBoardSettings">
        <div>
        ${line("ETH_SETTINGS_BOARD_TYPE", `${board ? board.label : tr("MANUAL_SETTINGS")} [${board ? board.val : 0}]`)}
        ${line("ETH_SETTINGS_PHY_TYPE", `${phy ? phy.label : '---'} [${phy ? phy.val : 0}]`)}
        ${line("ETH_SETTINGS_PHY_ADDRESS", eth.phyAddress ?? 0)}
        ${line("ETH_SETTINGS_CLOCK_MODE", `${clk ? clk.label : '---'} [${clk ? clk.val : 0}]`)}
        ${line("ETH_SETTINGS_POWER_PIN", (eth.PWRPin === undefined || eth.PWRPin === -1) ? tr("ETH_SETTINGS_NONE") : eth.PWRPin)}
        ${line("ETH_SETTINGS_MDC_PIN", eth.MDCPin ?? 0)}
        ${line("ETH_SETTINGS_MDIO_PIN", eth.MDIOPin ?? 0)}
        </div>
        </div>`;
}
sendNetworkSettings(obj) {
const isOnboarding = isApMode && !window.__onboardingDone;
const doSend = () => {
putJSONSync('/setNetwork', obj, (err, response) => {
if (err) {
ui.serviceError(err);
return;
}
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
logger.debug("Network settings updated:", response);
clearDirty();
});
};
if (isOnboarding) {
onboarding.markDone()
.then(doSend)
.catch(err => {
logger.error('Failed to auto-complete onboarding before network save:', err);
doSend();
});
} else {
doSend();
}
}
procWifiStrength(strength) {
if (!strength) return;
const ssid = strength.ssid || strength.name;
const sVal = parseInt(strength.strength);
const elSSID = get('spanNetworkSSID');
const elChan = get('spanNetworkChannel');
const elStrength = get('spanNetworkStrength');
const elSvgCont = get('divWiFiStrength');
if (elSSID) elSSID.textContent = !ssid || ssid === '' ? '-------------' : ssid;
if (elChan) elChan.innerHTML = isNaN(strength.channel) || strength.channel < 0 ? '--' : strength.channel;
if (elStrength) elStrength.innerHTML = isNaN(sVal) || sVal <= -100 ? '----' : sVal;
let level = (isNaN(sVal) || sVal >= 0 || sVal <= -100) ? -1 : this.calcWaveStrength(sVal);
if (level >= 3) level = 3;
this._wifiLinkUp = level >= 0;
this.updateMobileNetStatus();
for (let i = 0; i <= 3; i++) {
const part = get('wifi_' + i);
if (part) {
if (i <= level) {
part.classList.add('active');
} else {
part.classList.remove('active');
}
}
}
if (elStrength && elSvgCont) {
const classes = ['sig-good', 'sig-medium', 'sig-bad'];
elStrength.classList.remove(...classes);
elSvgCont.classList.remove(...classes);
if (!isNaN(sVal) && sVal < 0 && sVal > -100) {
if (level >= 2) {
elStrength.classList.add('sig-good');
elSvgCont.classList.add('sig-good');
}
else if (level === 1) {
elStrength.classList.add('sig-medium');
elSvgCont.classList.add('sig-medium');
}
else {
elStrength.classList.add('sig-bad');
elSvgCont.classList.add('sig-bad');
}
}
}
}
procEthernet(ethernet) {
logger.debug('Ethernet status:', ethernet);
const spanStatus = get('spanEthernetStatus');
const divStatus = get('divEthernetStatus');
const divWifi = get('divWiFiStrength');
const spanSpeedVal = get('spanEthernetSpeedVal');
const spanSpeedDetails = get('spanEthernetSpeedDetails');
const isConnected = ethernet.connected;
this._ethLinkUp = !!isConnected;
this.updateMobileNetStatus();
if (divStatus) divStatus.style.display = isConnected ? '' : 'none';
if (divWifi) divWifi.style.display = isConnected ? 'none' : '';
spanStatus.innerHTML = isConnected ? 'Connected' : 'Disconnected';
spanStatus.style.color = isConnected ? 'var(--color-signal-good)' : '';
if (isConnected) {
divStatus.classList.add('sig-good');
divStatus.classList.remove('sig-bad');
const speed = parseInt(ethernet.speed);
spanSpeedVal.innerHTML = isNaN(speed) ? '--' : speed;
spanSpeedDetails.innerHTML = ` Mbps ${ethernet.fullduplex ? 'Full-duplex' : 'Half-duplex'}`;
spanSpeedVal.classList.remove('sig-good', 'sig-medium');
if (!isNaN(speed) && speed >= 100) {
spanSpeedVal.classList.add('sig-good');
} else {
spanSpeedVal.classList.add('sig-medium');
}
} else {
divStatus.classList.remove('sig-good', 'sig-bad');
spanSpeedVal.innerHTML = '--';
spanSpeedDetails.innerHTML = '';
spanSpeedVal.classList.remove('sig-good', 'sig-medium');
}
}
}
var wifi = new Wifi();
class Onboarding {
_step = 1;
_mode = 'wifi';
_ethBoardType = null;
_returnGrpid = null;
_donePersisted = null;
open() {
const div = get('divOnboardingWizard');
if (!div) return;
this._mode = 'wifi';
this._returnGrpid = null;
this._step = this._isModeChoiceUseful() ? 1 : 2;
div.style.display = 'flex';
this._paint();
}
_isModeChoiceUseful() {
return (window.__hardwareProfile || '') !== 'BOX-WIFI';
}
_paint() {
const div = get('divOnboardingWizard');
if (!div) return;
this._hostEthSettings(false);
div.innerHTML = this._render();
this._applyHardwareProfile();
this._applyMode();
this._goToStep(this._step, false);
}
_goToStep(step, animate = true) {
this._step = step;
const track = get('onboardingTrack');
if (track) {
if (!animate) track.style.transition = 'none';
track.style.transform = `translateX(-${(step - 1) * 50}%)`;
if (!animate) { void track.offsetWidth; track.style.transition = ''; }
}
this._applyStepChrome();
}
_applyStepChrome() {
const atChoice = (this._step === 1);
const back = get('onboardingBackBtn');
if (back) back.style.display = (!atChoice && this._isModeChoiceUseful()) ? '' : 'none';
const foot = get('onboardingFooter');
if (foot) foot.style.display = atChoice ? 'none' : '';
const choice = get('onboardingModePanel');
const net = get('onboardingNetPanel');
if (choice) choice.inert = !atChoice;
if (net) net.inert = atChoice;
}
goToModeChoice() {
this._goToStep(1);
}
chooseMode(mode) {
this._mode = mode;
this._applyMode();
this._goToStep(2);
}
_applyHardwareProfile() {
const profile = window.__hardwareProfile || '';
const container = get('divContainer');
if (container) container.setAttribute('data-hardwareprofile', profile);
const boardRow = get('onboardingEthBoardRow');
if (boardRow) boardRow.style.display = profile.startsWith('BOX') ? 'none' : '';
}
_render() {
return `
        <div class="Network-Ap-card" id="onboardingWizardRoot">
            <div class="onboarding-skip-wrap">
                <button id="onboardingBackBtn" type="button" class="onboarding-back" btsText style="display:none;" onclick="onboarding.goToModeChoice();"><svg><use href="#svg-arrowLeft"></use></svg><span>${tr('BT_GO_BACK')}</span></button>
                <button type="button" btsText onclick="onboarding.skip();"><span>${tr('FIRST_CONNECT_SKIP')}</span><svg class="btnArrowRight"><use href="#svg-arrowRight"></use></svg></button>
            </div>
            <div class="onboarding-viewport">
                <div id="onboardingTrack" class="onboarding-track">
                    ${this._modeChoicePanel()}
                    ${this._networkPanel()}
                </div>
            </div>
            ${this._footer()}
        </div>`;
}
_modeChoicePanel() {
const card = (mode, icon, title, desc) => `
                <div class="welcomeCard" onclick="onboarding.chooseMode('${mode}');">
                    <svg><use href="#${icon}"></use></svg>
                    <div class="welcomeCard-content">
                        <h1>${title}</h1>
                        <p>${desc}</p>
                    </div>
                </div>`;
return `
        <div id="onboardingModePanel" class="onboarding-panel">
            <h1 class="onboarding-panel-title">${tr('FIRST_CONNECT_MODE_TITLE')}</h1>
            <p class="onboarding-panel-desc">${tr('FIRST_CONNECT_MODE_DESC')}</p>
            <div class="setup-guide onboarding-modes">
                ${card('wifi', 'svg-wifi', tr('CONNEXION_WIFI'), tr('FIRST_CONNECT_MODE_WIFI_DESC'))}
                ${card('eth', 'svg-ethernet', tr('CONNEXION_ETHERNET'), tr('FIRST_CONNECT_MODE_ETH_DESC'))}
                ${card('both', 'svg-backWireless', `${tr('CONNEXION_ETHERNET')} + ${tr('CONNEXION_WIFI_FALLBACK')}`, tr('CONNEXION_WIFI_FALLBACK_DESC'))}
            </div>
        </div>`;
}
_networkPanel() {
return `
        <div id="onboardingNetPanel" class="onboarding-panel">
            <h1 class="onboarding-panel-title">${tr('TAB_NETWORK')}</h1>
            <p id="onboardingNetDesc" class="onboarding-panel-desc" style="display:none;">${tr('FIRST_CONNECT_NET_DESC')}</p>
            <div id="onboardingEthBlock" style="display:none;">
                <!-- Pas de .dirty-target ici, contrairement aux formulaires de la page Réseau : le
                     repère "champ modifié" suppose un état enregistré de référence, alors que tout
                     est saisie initiale dans l'assistant -- il serait posé d'emblée et n'indiquerait
                     rien. Il aurait fallu pour ça armer watchDirty() sur la carte, ce qui alimente
                     aussi l'alerte "modifications non enregistrées" : "Ignorer" aurait alors
                     demandé une confirmation d'abandon, exactement l'inverse de son rôle. -->
                <div id="onboardingEthBoardRow" class="uniRow">
                    <div class="uniLeft">
                        <div class="uniblocSvg-S"><svg><use href="#svg-esp"></use></svg></div>
                        <div class="unifield-content">
                            <label class="label" for="onboardingEthBoardType">${tr('CONNEXION_ETH_BOARD_TYPE')}</label>
                            <select id="onboardingEthBoardType" class="inputAndSelect" onchange="onboarding.onEthBoardTypeChanged(this);"></select>
                        </div>
                    </div>
                </div>
                <!-- Accueille le VRAI bloc #divETHSettings (broches GPIO) de la page Réseau, déplacé
                     ici tant que l'Ethernet est actif -- cf. Onboarding._hostEthSettings(). -->
                <div id="onboardingEthSettingsHost"></div>
            </div>
            <div id="onboardingWifiBlock" style="display:none;">
                <div id="onboardingFallbackInfo" class="information" style="display:none;">
                    <div class="information-text"><span>${tr('CONNEXION_WIFI_FALLBACK_DESC')}</span></div>
                </div>
                <button type="button" class="buttonUpdate unibuttonPad" onclick="onboarding.findWifi();">
                    <div class="uniLeft">
                        <div class="uniblocSvg-S"><svg><use href="#svg-addWifiAuto"></use></svg></div>
                        <div class="devButtonUpdate">
                            <div>${tr('CONNEXION_FIND_WIFI')}</div>
                            <div class="uniStatus">${tr('CONNEXION_FIND_WIFI_DESC')}</div>
                        </div>
                    </div>
                    <svg class="btnArrowRight"><use href="#svg-arrowRight"></use></svg>
                </button>
                <button type="button" class="buttonUpdate unibuttonPad" onclick="onboarding.addWifiManual();">
                    <div class="uniLeft">
                        <div class="uniblocSvg-S"><svg><use href="#svg-addWifiManuel"></use></svg></div>
                        <div class="devButtonUpdate">
                            <div>${tr('CONNEXION_ADD_WIFI_MANUAL')}</div>
                            <div class="uniStatus">${tr('CONNEXION_ADD_WIFI_MANUAL_DESC')}</div>
                        </div>
                    </div>
                    <svg class="btnArrowRight"><use href="#svg-arrowRight"></use></svg>
                </button>
                <!-- Retour visible après une saisie Wi-Fi : la modale se contente désormais de
                     RETENIR le réseau (cf. findWifi()), sans rien envoyer -- sans ce récapitulatif,
                     la fermeture de la modale donnerait l'impression que rien ne s'est passé. -->
                <div id="onboardingWifiStaged" class="uniRow" style="display:none;">
                    <div class="uniLeft">
                        <div class="uniblocSvg-S"><svg><use href="#svg-ssid"></use></svg></div>
                        <div class="uniText">
                            <div class="uniLabel" id="onboardingWifiStagedLabel"></div>
                            <div class="uniStatus" id="onboardingWifiStagedSsid"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="onboardingEthWarning" class="warning" style="display:none;">
                <div class="warning-header"><svg><use href="#svg-warning"></use></svg><b>${tr('MSG_WARNING')}</b></div>
                <div class="information-text"><span>${tr('FIRST_CONNECT_ETH_WIFI_FALLB_WARNING')}</span></div>
            </div>
        </div>`;
}
_footer() {
return `
        <div id="onboardingFooter" class="button-container-overlay onboarding-footer">
            <button id="onboardingSaveBtn" type="button" class="buttonUpdate unibuttonPad" onclick="onboarding.save();">
                <div class="uniLeft">
                    <div class="uniblocSvg-S"><svg><use href="#svg-save"></use></svg></div>
                    <div class="devButtonUpdate">
                        <div>${tr('BT_SAVE')}</div>
                        <div class="uniStatus">${tr('FIRST_CONNECT_SAVE_DESC')}</div>
                    </div>
                </div>
                <svg class="btnArrowRight"><use href="#svg-arrowRight"></use></svg>
            </button>
        </div>`;
}
_applyMode() {
const mode = this._mode;
const usesEth = (mode !== 'wifi');
const usesWifi = (mode !== 'eth');
const show = (id, visible) => { const el = get(id); if (el) el.style.display = visible ? '' : 'none'; };
show('onboardingEthBlock', usesEth);
show('onboardingWifiBlock', usesWifi);
show('onboardingNetDesc', mode === 'wifi');
show('onboardingFallbackInfo', mode === 'both');
this._hostEthSettings(usesEth);
this._syncRealNetFields(mode);
if (usesEth) this._populateEthBoardTypes();
this._updateWifiStaged();
this._updateEthWarning();
}
_syncRealNetFields(mode) {
const cbHardwired = get('cbHardwired');
if (!cbHardwired) return;
cbHardwired.checked = (mode !== 'wifi');
const cbFallback = get('cbFallbackWireless');
if (cbFallback) cbFallback.checked = (mode === 'both');
wifi.useEthernetClicked();
}
findWifi() {
this._openWifiCapture(tr('CONNEXION_FIND_WIFI'), false);
}
addWifiManual() {
this._openWifiCapture(tr('CONNEXION_ADD_WIFI_MANUAL'), true);
}
_openWifiCapture(title, manual) {
this._syncRealNetFields(this._mode);
wifi.wifiOverlay(title, manual, () => {
this._updateWifiStaged();
this._updateEthWarning();
});
}
_updateWifiStaged() {
const row = get('onboardingWifiStaged');
if (!row) return;
const ssidFld = get('fldSsid');
const ssid = ((ssidFld && ssidFld.value) || '').trim();
row.style.display = ssid ? '' : 'none';
if (!ssid) return;
const lbl = get('onboardingWifiStagedLabel');
const val = get('onboardingWifiStagedSsid');
if (lbl) lbl.textContent = tr(this._mode === 'both' ? 'CONNEXION_WIFI_FALLBACK' : 'CONNEXION_WIFI');
if (val) val.textContent = ssid;
}
_updateEthWarning() {
const warn = get('onboardingEthWarning');
if (!warn) return;
const ssidFld = get('fldSsid');
const hasSsid = !!((ssidFld && ssidFld.value) || '').trim();
warn.style.display = (this._mode === 'both' && !hasSsid) ? '' : 'none';
}
_populateEthBoardTypes() {
const sel = get('onboardingEthBoardType');
if (!sel || sel.options.length > 0) return;
const realSel = get('selETHBoardType');
const deviceType = realSel ? parseInt(realSel.value, 10) : NaN;
const preselect = (this._ethBoardType !== null) ? this._ethBoardType
: ((deviceType > 0) ? deviceType : 1);
wifi.loadETHDropdown(sel, wifi.ethBoardTypes, preselect);
this.onEthBoardTypeChanged(sel);
}
onEthBoardTypeChanged(sel) {
this._ethBoardType = parseInt(sel.value, 10);
const realSel = get('selETHBoardType');
if (realSel) {
realSel.value = sel.value;
wifi.onETHBoardTypeChanged(realSel);
}
}
_hostEthSettings(usesEth) {
const settings = get('divETHSettings');
const host = get('onboardingEthSettingsHost');
if (!settings || !host) return;
if (usesEth) {
if (!this._ethSettingsHome) this._ethSettingsHome = settings.parentElement;
if (settings.parentElement !== host) host.appendChild(settings);
}
else if (this._ethSettingsHome && settings.parentElement === host) {
this._ethSettingsHome.appendChild(settings);
}
}
save() {
this._syncRealNetFields(this._mode);
if (this._mode === 'wifi') {
const ssidFld = get('fldSsid');
if (!((ssidFld && ssidFld.value) || '').trim()) {
ui.errorMessage(tr('ERR_WIFI_SSID_INVALID'));
return;
}
wifi.networkConfirmationOverlay(wifi._currentHostname());
return;
}
wifi.saveNetwork();
}
markDone(retries = 0) {
if (this._donePersisted === null) this._donePersisted = !!window.__onboardingDone;
if (this._donePersisted) return Promise.resolve();
window.__onboardingDone = true;
return deviceFetch('/setOnboardingDone?done=1', { method: 'POST' })
.then(resp => { this._donePersisted = true; return resp; })
.catch(err => {
if (retries <= 0) throw err;
return new Promise(res => setTimeout(res, 1500)).then(() => this.markDone(retries - 1));
});
}
skip() {
this._hostEthSettings(false);
const persisted = this.markDone(3);
showAuthenticatedShellOrWizard();
activateGrpid(this._returnGrpid || 'divHomePnl', { updateHash: false });
persisted.catch(err => {
logger.error('Failed to persist onboarding completion:', err);
ui.serviceError(err);
});
}
relaunch() {
confirmDiscardChanges(() => this._openManually());
}
_openManually() {
const from = ROUTE_SLUG_TO_GRPID[location.hash.slice(1)] || null;
const auth = get('divAuthenticated');
if (auth) auth.style.display = 'none';
setOnboardingLock(true);
this.open();
this._returnGrpid = from;
}
}
var onboarding = new Onboarding();
class Somfy {
initialized = false;
dataLoaded = false;
frames = [];
frameLimit = 300;
frameCount = 0;
frameBaseSeq = 0;
frameFilter = '';
frameValidOnly = false;
frameLogPaused = false;
frameLogStale = false;
frameLogBound = false;
frameLogVisible = false;
frameStamps = [];
frameRateTimer = null;
rfNoiseUntil = 0;
rfNoiseEpisodes = 0;
isScanClosing = false;
scanObserver = null;
txPowerLevels = [-30, -20, -15, -10, -6, 0, 5, 7, 10, 11, 12];
shadeTypes = [
{ type: 0, name: 'Roller Shade', ico: 'svg-window-shade', indic: 'svg-indicRoller', lift: true, sun: true, fcmd: true, fpos: true },
{ type: 1, name: 'Blind', ico: 'svg-window-blind', indic: 'svg-indicblind', lift: true, tilt: true, sun: true, fcmd: true, fpos: true },
{ type: 2, name: 'Drapery (left)', ico: 'svg-ldrapery', indic: 'svg-indicDrapery', lift: true, sun: true, fcmd: true, fpos: true },
{ type: 3, name: 'Awning', ico: 'svg-awning', indic: 'svg-indicAwning', lift: true, sun: true, fcmd: true, fpos: true },
{ type: 4, name: 'Shutter', ico: 'svg-shutter', indic: 'svg-indicShutter', lift: true, sun: true, fcmd: true, fpos: true },
{ type: 5, name: 'Garage (1-button)', ico: 'svg-garage', indic: 'svg-indicGarage', lift: true, light: true, fpos: true },
{ type: 6, name: 'Garage (3-button)', ico: 'svg-garage', indic: 'svg-indicGarage', lift: true, light: true, fcmd: true, fpos: true },
{ type: 7, name: 'Drapery (right)', ico: 'svg-rdrapery', indic: 'svg-indicDrapery', lift: true, sun: true, fcmd: true, fpos: true },
{ type: 8, name: 'Drapery (center)', ico: 'svg-cdrapery', indic: 'svg-indicDrapery', lift: true, sun: true, fcmd: true, fpos: true },
{ type: 9, name: 'Dry Contact (1-button)', ico: 'svg-contactBulb', indic: 'svg-indicDryContact', fpos: true },
{ type: 10, name: 'Dry Contact (2-button)', ico: 'svg-contactBulb', indic: 'svg-indicDryContact', fcmd: true, fpos: true },
{ type: 11, name: 'Gate (left)', ico: 'svg-lgate', indic: 'svg-indicGate', lift: true, fcmd: true, fpos: true },
{ type: 12, name: 'Gate (center)', ico: 'svg-cgate', indic: 'svg-indicGate', lift: true, fcmd: true, fpos: true },
{ type: 13, name: 'Gate (right)', ico: 'svg-rgate', indic: 'svg-indicGate', lift: true, fcmd: true, fpos: true },
{ type: 14, name: 'Gate (1-button left)', ico: 'svg-lgate', indic: 'svg-indicGate', lift: true, fcmd: true, fpos: true },
{ type: 15, name: 'Gate (1-button center)', ico: 'svg-cgate', indic: 'svg-indicGate', lift: true, fcmd: true, fpos: true },
{ type: 16, name: 'Gate (1-button right)', ico: 'svg-rgate', indic: 'svg-indicGate', lift: true, fcmd: true, fpos: true },
];
noMyShadeTypes = [5, 9, 10, 14, 15, 16];
radioBoardTypes = [
{ val: 0, label: 'DEFAULT', showGPIO: false },
{ val: 1, label: 'ESP32-D1 mini', showGPIO: false, chips: ['esp32'], pins: { SCKPin: 18, CSNPin: 5, MOSIPin: 23, MISOPin: 19, TXPin: 21, RXPin: 22 } },
{ val: 2, label: 'WT32-ETH01', showGPIO: false, chips: ['esp32'], pins: { SCKPin: 14, CSNPin: 12, MOSIPin: 15, MISOPin: 4, TXPin: 2, RXPin: 35 } },
{ val: 3, label: 'Olimex ESP32-PoE/EVB', showGPIO: false, chips: ['esp32'], pins: { SCKPin: 14, CSNPin: 13, MOSIPin: 15, MISOPin: 16, TXPin: 4, RXPin: 36 } },
{ val: 4, label: 'LilyGO T-Internet POE', showGPIO: false, chips: ['esp32'], pins: { SCKPin: 14, CSNPin: 12, MOSIPin: 15, MISOPin: 16, TXPin: 4, RXPin: 35 } },
{ val: 5, label: 'wESP POE', showGPIO: false, chips: ['esp32'], pins: { SCKPin: 18, CSNPin: 5, MOSIPin: 13, MISOPin: 32, TXPin: 4, RXPin: 39 } },
{ val: 6, label: 'ESP-PoE-32', showGPIO: false, chips: ['esp32'], pins: { SCKPin: 14, CSNPin: 5, MOSIPin: 13, MISOPin: 32, TXPin: 4, RXPin: 35 } },
{ val: 7, label: 'ESP32s3 Mini', showGPIO: false, chips: ['s3'], pins: { SCKPin: 7, CSNPin: 6, MOSIPin: 9, MISOPin: 8, TXPin: 3, RXPin: 4 } },
{ val: 8, label: 'XIAO-ESP32-C3', showGPIO: false, chips: ['c3'], pins: { SCKPin: 8, CSNPin: 6, MOSIPin: 10, MISOPin: 9, TXPin: 3, RXPin: 4 } },
{ val: 255, label: 'MANUAL_SETTINGS', showGPIO: true }
];
init() {
if (this.initialized) return;
this.bindVRKeyboard();
initMultiClickToggle('#divTransceiverSettings .main-headerTitle', 'show-expert-gpio', 5);
initMultiClickToggle('.sidebar-brand, #showLogoHeader', () => this.screenShade(), 5);
this.initialized = true;
}
initPins() {
document
.getElementById('selRadioBoardType')
.addEventListener('change', e => this.onRadioBoardTypeChanged(e.target));
const sel = get('selRadioBoardType');
sel.addEventListener('change', e => this.onRadioBoardTypeChanged(e.target));
this.loadPins('inout', get('selTransSCKPin'));
this.loadPins('inout', get('selTransCSNPin'));
this.loadPins('inout', get('selTransMOSIPin'));
this.loadPins('input', get('selTransMISOPin'));
this.loadPins('out', get('selTransTXPin'));
this.loadPins('input', get('selTransRXPin'));
ui.toElement(get('divTransceiverSettings'), {
transceiver: { config: { proto: 0, radioBoardType: 0, SCKPin: 18, CSNPin: 5, MOSIPin: 23, MISOPin: 19, TXPin: 13, RXPin: 12, frequency: 433.42, rxBandwidth: 97.96, type: 56, txPower: 10, enabled: false } }
});
this.loadPins('out', get('selShadeGPIOUp'));
this.loadPins('out', get('selShadeGPIODown'));
this.loadPins('out', get('selShadeGPIOMy'));
this.loadRadioBoardTypes(get('selRadioBoardType'));
this.loadRadioBoardTypes(sel);
this.onRadioBoardTypeChanged(sel);
}
loadRadioBoardTypes(sel) {
while (sel.firstChild) sel.removeChild(sel.firstChild);
let rawCm = get('divContainer').getAttribute('data-chipmodel') || "";
let cm = rawCm.toLowerCase().trim();
if (cm.includes("s3")) cm = "s3";
else if (cm.includes("c3")) cm = "c3";
else if (cm.includes("s2")) cm = "s2";
else cm = "esp32";
this.radioBoardTypes.forEach(t => {
if (t.chips && !t.chips.includes(cm)) {
return;
}
let labelKey = t.label;
if (t.val === 0 && labelKey === 'DEFAULT') {
labelKey = `BOARD_DEFAULT_${cm.toUpperCase()}`;
}
const labelText = tr(labelKey);
sel.options.add(new Option(labelText, t.val));
});
}
onRadioBoardTypeChanged(sel) {
const val = parseInt(sel.value, 10),
cm = (get('divContainer').getAttribute('data-chipmodel') || "").toLowerCase(),
divS = get('divGPIOSummary'),
divG = get('divShowGpio'),
pk = ['SCKPin', 'CSNPin', 'MOSIPin', 'MISOPin', 'TXPin', 'RXPin'],
isM = (val === 255),
board = this.radioBoardTypes.find(t => t.val === val);
let def = { SCKPin: 18, CSNPin: 5, MOSIPin: 23, MISOPin: 19, TXPin: 13, RXPin: 12 };
if (cm === "s3") def = { SCKPin: 12, CSNPin: 10, MOSIPin: 11, MISOPin: 13, TXPin: 15, RXPin: 14 };
else if (cm === "s2") def = { SCKPin: 36, CSNPin: 34, MOSIPin: 35, MISOPin: 37, TXPin: 15, RXPin: 14 };
else if (cm === "c3") def = { SCKPin: 15, CSNPin: 14, MOSIPin: 16, MISOPin: 17, TXPin: 13, RXPin: 12 };
const target = val === 0 ? def : (board?.pins || null);
if (target) {
const labels = ['SCK:', 'CSN:', 'MOSI:', 'MISO:', 'TX:', 'RX:'];
let html = `<div class="gpioRadio-container">`;
pk.forEach((k, i) => {
const v = target[k], selP = get(`selTrans${k}`), inpP = get(`inputTrans${k}`);
if (selP) {
if (![...selP.options].some(o => parseInt(o.value, 10) === v)) {
selP.options.add(new Option(`GPIO-${v < 10 ? '0' + v : v}`, v));
}
selP.value = v;
}
if (inpP) inpP.value = v;
html += `<div class="gpioRadio-item"><span class="gpioRadio-label">${labels[i]}</span><span class="gpioRadio-val">GPIO${v}</span></div>${i < 5 ? `<div class="gpioRadio-sep${i === 2 ? ' gpioRadioSep' : ''}">|</div>` : ''}`;
});
divS.innerHTML = html + `</div>`;
}
pk.forEach(k => {
const selP = get(`selTrans${k}`), inpP = get(`inputTrans${k}`);
if (selP) selP.style.display = target ? 'inline-block' : 'none';
if (inpP) {
if (isM) {
const courant = parseInt(selP ? selP.value : inpP.value, 10);
inpP.value = isNaN(courant) ? def[k] : courant;
}
inpP.style.display = isM ? 'inline-block' : 'none';
}
});
get('divManualSafety').style.display = isM ? 'block' : 'none';
divS.style.display = target ? 'block' : 'none';
divG.style.display = target ? 'none' : 'inline-block';
}
setRadioEnabled(isEnabled) {
const txtStatus = get('divRadioEnableStatus');
const radioTab = document.querySelector('.tab-container span[data-grpid="divRadioSettings"]');
const isActuallyEnabled = radioTab && !radioTab.classList.contains('radio-error');
if (txtStatus) {
if (isEnabled === isActuallyEnabled) {
txtStatus.textContent = isEnabled ? tr('RADIO_ENABLED') : tr('RADIO_DISABLED');
} else {
txtStatus.textContent = tr('RADIO_SAVE_REQUIRED');
}
}
}
async loadSomfy() {
getJSONSync('/controller', (err, somfy) => {
this.dataLoaded = true;
if (err) {
logger.error('Failed to load Somfy controller data:', err);
ui.serviceError(err);
this.checkEmptyState();
} else {
logger.debug('Somfy controller data loaded');
const spanMaxRooms = get('spanMaxRooms');
const spanMaxShades = get('spanMaxShades');
const spanMaxGroups = get('spanMaxGroups');
if (spanMaxRooms) spanMaxRooms.innerText = (somfy.maxRooms - 2);
if (spanMaxShades) spanMaxShades.innerText = (somfy.maxShades - 2);
if (spanMaxGroups) spanMaxGroups.innerText = (somfy.maxGroups - 2);
this.maxSchedules = somfy.maxSchedules;
ui.toElement(get('divTransceiverSettings'), somfy);
if (typeof this.updateRadioGraph === 'function') {
this.updateRadioGraph();
}
this.restoreRadioMode();
this.watchRadioEdits();
if (somfy.transceiver && somfy.transceiver.config)
this._radioApplied = Object.assign({}, somfy.transceiver.config);
const selBoard = get('selRadioBoardType');
if (selBoard) {
this.loadRadioBoardTypes(selBoard);
}
if (somfy.transceiver && somfy.transceiver.config) {
if (selBoard) selBoard.value = somfy.transceiver.config.radioBoardType || 0;
this.onRadioBoardTypeChanged(selBoard);
}
const cbEnableRadio = get('cbEnableRadio');
const row = get('divRadioEnableColor');
const radioTab = document.querySelector('.tab-container span[data-grpid="divRadioSettings"]');
const isConfigEnabled = !!(somfy.transceiver && somfy.transceiver.config && somfy.transceiver.config.enabled);
if (cbEnableRadio) {
cbEnableRadio.checked = isConfigEnabled;
}
const isRadioInit = somfy.transceiver?.config?.radioInit;
const sideNote = get('barsideRadioDisable');
if (radioTab) {
radioTab.classList.toggle('radio-error', !isRadioInit);
if (sideNote) sideNote.style.display = isRadioInit ? 'none' : 'inline';
if (row) row.classList.toggle('radioOn', !!isRadioInit);
}
this.setVRRadioState(isConfigEnabled && !!isRadioInit);
this.setRadioEnabled(isConfigEnabled);
watchDirty(get('divTransceiverSettings'));
this.setRoomsList(somfy.rooms);
this.setShadesList(somfy.shades);
this.setGroupsList(somfy.groups);
this.setRepeaterList(somfy.repeaters);
this.setScheduleList(somfy.schedules);
if (typeof somfy.version !== 'undefined') {
firmware.procFwStatus(somfy.version);
}
}
});
}
stepGpio(pinKey, direction) {
stepDeviceGpio(pinKey, direction, 'Trans', 'selRadioBoardType', val => val === 255, this.pinMaps);
}
saveRadio() {
let valid = true;
const d = get('divTransceiverSettings'),
t = ui.fromElement(d).transceiver,
pk = ['SCKPin', 'CSNPin', 'MOSIPin', 'MISOPin', 'TXPin', 'RXPin'],
bv = parseInt(get('selRadioBoardType').value, 10),
isM = (bv === 255);
if (!t.config) t.config = {};
t.config.radioBoardType = bv;
if (isM && !get('cbManualSafety')?.checked) {
return ui.errorMessage(d, tr('ERR_RADIO_SAFETY_REQUIRED'));
}
pk.forEach(k => {
const el = get((isM ? 'inputTrans' : 'selTrans') + k);
if (el) t.config[k] = parseInt(el.value, 10);
});
if (!t.config.type || t.config.type === 'none') {
ui.errorMessage(d, tr('ERR_RADIO_TYPE_REQUIRED'));
valid = false;
}
if (valid) {
const cm = (get('divContainer').getAttribute('data-chipmodel') || "").toLowerCase(),
pm = this.pinMaps.find(x => x.name === cm) || { maxPins: 39 };
try {
for (const k of pk) {
const v = t.config[k];
if (v === undefined || isNaN(v)) {
ui.errorMessage(d, tr('ERR_RADIO_PINS_REQUIRED'));
valid = false; break;
}
if (v < 0 || v > pm.maxPins) {
ui.errorMessage(d, tr('ERR_GPIO_NOT_EXIST').replace('{pin}', v).replace('{maxPins}', pm.maxPins));
valid = false; break;
}
for (let s in t.config) {
if (s.endsWith('Pin') && s !== k && t.config[s] === v) {
if ((k === 'TXPin' && s === 'RXPin') || (k === 'RXPin' && s === 'TXPin')) continue;
ui.errorMessage(d, tr('ERR_GPIO_PIN_DUPLICATED').replace('%1', k.replace('Pin', '')).replace('%2', s.replace('Pin', '')));
valid = false; break;
}
}
if (!valid) break;
}
} catch (err) {
logger.error('Radio settings validation error:', err);
valid = false;
}
}
if (!valid) return;
const proceedSave = () => {
putJSONSync('/saveRadio', t, (err, res) => {
if (err) return ui.serviceError(err);
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
clearDirty();
get('btnSaveRadio').classList.remove('disabled');
this._radioApplied = Object.assign({}, res.config);
this.updateRadioGraph();
const init = res.config.radioInit,
tab = document.querySelector('.tab-container span[data-grpid="divRadioSettings"]'),
sn = get('barsideRadioDisable'),
cb = get('cbEnableRadio');
if (tab) {
tab.classList.toggle('radio-error', !init);
if (sn) sn.style.display = init ? 'none' : 'inline';
get('divRadioEnableColor').classList.toggle('radioOn', !!init);
}
if (cb) {
get('divRadioEnableStatus').textContent = tr(cb.checked === init ? (cb.checked ? 'RADIO_ENABLED' : 'RADIO_DISABLED') : 'RADIO_SAVE_REQUIRED');
}
});
};
if (isM) {
let prompt = ui.promptMessage(get('divContainer'), tr('PROMPT_RADIO_MANUAL_TITLE'), () => {
proceedSave();
});
prompt.querySelector('.sub-message').innerHTML = `<p>${tr("PROMPT_RADIO_MANUAL_WARNING")}</p>`;
} else {
proceedSave();
}
}
pinMaps = [
{ name: '', maxPins: 39, inputs: [0, 1, 6, 7, 8, 9, 10, 11, 37, 38], outputs: [3, 6, 7, 8, 9, 10, 11, 34, 35, 36, 37, 38, 39] },
{ name: 's2', maxPins: 46, inputs: [0, 19, 20, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 45], outputs: [0, 19, 20, 26, 27, 28, 29, 30, 31, 32, 45, 46]},
{ name: 's3', maxPins: 48, inputs: [19, 20, 22, 23, 24, 25, 27, 28, 29, 30, 31, 32], outputs: [19, 20, 22, 23, 24, 25, 27, 28, 29, 30, 31, 32] },
{ name: 'c3', maxPins: 21, inputs: [11, 12, 13, 14, 15, 16, 17, 18, 19, 20], outputs: [11, 12, 13, 14, 15, 16, 17, 21] }
];
loadPins(type, sel, opt) {
if (!sel) return;
let currentVal = (typeof opt !== 'undefined') ? opt : parseInt(sel.value, 10);
while (sel.firstChild) sel.removeChild(sel.firstChild);
let cm = get('divContainer').getAttribute('data-chipmodel');
let pm = this.pinMaps.find(x => x.name === cm);
if (!pm) {
pm = { name: '', maxPins: 39, inputs: [0, 1, 6, 7, 8, 9, 10, 11, 37, 38], outputs: [3, 6, 7, 8, 9, 10, 11, 34, 35, 36, 37, 38, 39] };
}
for (let i = 0; i <= pm.maxPins; i++) {
if (type.includes('in') && pm.inputs.includes(i)) continue;
if (type.includes('out') && pm.outputs.includes(i)) continue;
sel.options[sel.options.length] = new Option(
`GPIO-${i > 9 ? i.toString() : '0' + i.toString()}`,
i
);
}
if (!isNaN(currentVal)) {
sel.value = currentVal;
}
}
procFrequencyScan(scan) {
if (this.wiz || this.wizStopping) {
if (this.wiz && this.wiz.etat === 'ecoute') this.wizOnScan(scan);
if (!scan.scanning) this.wizStopping = false;
return;
}
let div = this.scanFrequency();
let spanTestFreq = get('spanTestFreq');
let spanTestRSSI = get('spanTestRSSI');
let spanBestFreq = get('spanBestFreq');
let spanBestRSSI = get('spanBestRSSI');
if (spanBestFreq) {
spanBestFreq.innerHTML = scan.RSSI !== -100 ? scan.frequency.fmt('###.00') : '----';
}
if (spanBestRSSI) {
const bestRSSIVal = scan.RSSI !== -100 ? scan.RSSI : '----';
spanBestRSSI.innerHTML = bestRSSIVal;
this.updateCardState(document.querySelector('.scan-card.optimal'), bestRSSIVal);
}
if (spanTestFreq) {
spanTestFreq.innerHTML = scan.testFreq.fmt('###.00');
}
if (spanTestRSSI) {
const testRSSIVal = scan.testRSSI !== -100 ? scan.testRSSI : '----';
spanTestRSSI.innerHTML = testRSSIVal;
this.updateCardState(document.querySelector('.scan-card:not(.optimal)'), testRSSIVal);
if (this.rssiGraphWave) this.rssiGraphWave.update(scan.testRSSI);
}
if (scan.RSSI !== -100)
div.setAttribute('data-frequency', scan.frequency);
}
updateCardState(cardElement, rssiVal) {
if (!cardElement) return;
cardElement.classList.remove('state-success', 'state-warning', 'state-error');
const v = parseInt(rssiVal);
if (isNaN(v) || rssiVal === '----') return;
if (v >= -60) {
cardElement.classList.add('state-success');
} else if (v < -60 && v >= -90) {
cardElement.classList.add('state-warning');
} else {
cardElement.classList.add('state-error');
}
}
scanFrequency(initScan) {
if (initScan && !this.radioPrete()) return;
if (initScan) this.wizStopping = false;
if (this.isScanClosing) return;
let div = get('divScanFrequency');
if (!div) {
div = document.createElement('div');
div.id = 'divScanFrequency';
div.className = 'inst-overlay';
div.innerHTML = `
            <div class="instructions-content">

            ${overlayHeader('SCANFREQ_TITLE', 'SCANFREQ_SCAN_DESC', 'svg-tabRadio', { subtitle: 'SCANFREQ_SCAN_DESC', showInfo: false })}
            <div class="overlay-scroll-content">

            <div class="scan-cards">
            <div class="scan-card">
            <div class="labelMAJ">${tr("SCANFREQ_SCAN")}</div>
            <div class="scan-card-content">
            <div class="scan-card-icon">
            <svg><use href="#svg-search"></use></svg>
            </div>
            <div class="scan-card-info">
            <div class="scan-card-main">
            <span id="spanTestFreq">433.14</span>
            <small>${tr("UNIT_MHZ")}</small>
            </div>
            <div class="scan-card-rssi-row">
            <span class="rssi-label">${tr('SCANFREQ_DIV_RSSI')}</span>
            <strong id="spanTestRSSI" class="rssi-value">----</strong>
            <small class="rssi-unit">${tr("UNIT_DBM")}</small>
            </div>
            </div>
            </div>
            </div>

            <div class="scan-card optimal">
            <div class="labelMAJ">${tr("SCANFREQ_FREQUENCY")}</div>
            <div class="scan-card-content">
            <div class="scan-card-icon target">
            <svg><use href="#svg-target"></use></svg>
            </div>
            <div class="scan-card-info">
            <div class="scan-card-main best">
            <span id="spanBestFreq">---.--</span>
            <small>${tr("UNIT_MHZ")}</small>
            </div>
            <div class="scan-card-rssi-row best">
            <span class="rssi-label">${tr('SCANFREQ_DIV_RSSI')}</span>
            <strong id="spanBestRSSI" class="rssi-value">----</strong>
            <small class="rssi-unit">${tr("UNIT_DBM")}</small>
            </div>
            </div>
            </div>
            </div>
            </div>

            <div class="scan-dashboard-bloc">
            <div class="dashboard-main-action">
            <div id="scanStatusText" class="scan-status-waiting-text">
            <span class="spinner-inline"></span>${tr('WAIT_MSG_SCANNING')}
            </div>

            <div id="scanStatusResult" class="scan-status-result-text" style="display:none">
            <span>${tr('SCANFREQ_NO_SIGNAL')}</span>
            </div>

            <button id="btnCopyFrequency" type="button" class="btn-scan-main" style="display:none" onclick="somfy.setScannedFrequency()">
            <svg class="icon-btn"><use href="#svg-save"></use></svg>
            ${tr("BT_COPY_FREQUENCY")}
            </button>
            </div>
            </div>

            <details id="graphAccordion" class="uniblocCol scanfreq-help-accordion" open>
            <summary class="scanfreq-help-trigger">
            <div class="scanfreq-title-wrapper">
            <svg class="help-svg"><use href="#svg-wave"></use></svg>
            <span>${tr('SCANFREQ_GRAPH_TITLE')}</span>
            </div>
            <svg class="accordion-arrow"><use href="#svg-arrowDown"></use></svg>
            </summary>

            <div class="graph-zone-wrapper">
            <div id="graphCanvasContainer" class="uniblocrRssiCanvas">
            <canvas id="rssiWave"></canvas>
            </div>
            </div>
            </details>

            <details class="uniblocCol scanfreq-help-accordion">
            <summary class="scanfreq-help-trigger">
            <div class="scanfreq-title-wrapper">
            <svg class="help-svg"><use href="#icon-question"></use></svg>
            <span>${tr('SCANFREQ_UNDERSTANDING_RSSI')}</span>
            </div>
            <svg class="accordion-arrow"><use href="#svg-arrowDown"></use></svg>
            </summary>

            <div class="rssi-scale-container">
            <div class="rssi-scale-zone zone-success">
            <div class="rssi-zone-header">
            <span class="rssi-badge">
            <svg class="icon-inline"><use href="#svg-succes"></use></svg>
            ${tr('SCANFREQ_RSSI_EXCELLENT')}
            </span>
            </div>
            <p class="rssi-zone-desc">${tr('SCANFREQ_RSSI_EXCELLENT_DESC')}</p>
            <div class="rssi-visual-bar bar-success">
            <span></span><span></span><span></span><span></span><span></span><span class="off"></span><span class="off"></span>
            </div>
            </div>

            <div class="rssi-scale-zone zone-warning">
            <div class="rssi-zone-header">
            <span class="rssi-badge">
            <svg class="icon-inline"><use href="#svg-warning"></use></svg>
            ${tr('SCANFREQ_RSSI_WEAK')}
            </span>
            </div>
            <p class="rssi-zone-desc">${tr('SCANFREQ_RSSI_WEAK_DESC')}</p>
            <div class="rssi-visual-bar bar-warning">
            <span></span><span></span><span></span><span class="off"></span><span class="off"></span><span class="off"></span><span class="off"></span>
            </div>
            </div>

            <div class="rssi-scale-zone zone-error">
            <div class="rssi-zone-header">
            <span class="rssi-badge">
            <svg class="icon-inline"><use href="#svg-error"></use></svg>
            ${tr('SCANFREQ_RSSI_NOISE')}
            </span>
            </div>
            <p class="rssi-zone-desc">${tr('SCANFREQ_RSSI_NOISE_DESC')}</p>
            <div class="rssi-visual-bar bar-error">
            <span></span><span class="off"></span><span class="off"></span><span class="off"></span><span class="off"></span><span class="off"></span><span class="off"></span>
            </div>
            </div>
            </div>
            </details>
            </div>

            <div class="hrDivFooter-Instruc"></div>

            <div class="button-container-overlay footer-controls-row">
            <button id="btnCloseScanning" type="button" line class="btn-scan-action btn-secondary">${tr("BT_CLOSE")}</button>

            <button id="btnRestartScanning" type="button" line class="btn-scan-action btn-success" style="display:none" onclick="somfy.scanFrequency(true)" title="${tr('BT_START_SCAN')}">
            <svg class="icon-btn"><use href="#svg-play"></use></svg>
            <span>${tr('BT_START')}</span>
            </button>
            <button id="btnStopScanning" type="button" class="btn-scan-action btn-danger" onclick="somfy.stopScanningFrequency(true)" title="${tr('BT_STOP_SCAN')}">
            <svg class="icon-btn"><use href="#svg-stop"></use></svg>
            <span>${tr('BT_STOP')}</span>
            </button>

            </div>
            </div>`;
shOverlay(div);
div.querySelector('#btnCloseScanning').onclick = () => requestCloseOverlay(div);
if (this.scanObserver) this.scanObserver.disconnect();
this.scanObserver = new MutationObserver(() => { if (!get('divScanFrequency')) this.terminateScanUI(true); });
this.scanObserver.observe(get('divContainer'), { childList: true });
const graphAccordion = div.querySelector('#graphAccordion');
if (graphAccordion) {
graphAccordion.addEventListener('toggle', () => {
if (graphAccordion.open && this.rssiGraphWave) this.rssiGraphWave.draw();
});
}
if (this._graphResizeObs) this._graphResizeObs.disconnect();
if (typeof ResizeObserver === 'function') {
this._graphResizeObs = new ResizeObserver(() => {
if (this.rssiGraphWave) this.rssiGraphWave.draw();
});
this._graphResizeObs.observe(div.querySelector('#rssiWave'));
}
this.rssiGraphWave = {
points: [],
maxPoints: 80,
canvas: get('rssiWave'),
freqMin: 433.00,
freqMax: 434.00,
currentIdx: 0,
optimalFreq: null,
stopped: false,
reset() {
this.currentIdx = 0;
this.optimalFreq = null;
this.stopped = false;
this.points = Array(this.maxPoints).fill(-110);
},
update(val, currentFreq) {
if (this.points.length === 0) this.points = Array(this.maxPoints).fill(-110);
currentFreq = get('spanTestFreq') ? get('spanTestFreq').innerText : currentFreq;
let v = parseInt(val);
if (isNaN(v) || v < -110) v = -110;
if (v > -30) v = -30;
let freq = NaN;
if (currentFreq !== undefined && currentFreq !== null) {
freq = parseFloat(String(currentFreq).replace(/[^0-9.]/g, ''));
}
if (!isNaN(freq) && freq >= this.freqMin && freq <= this.freqMax) {
const pct = (freq - this.freqMin) / (this.freqMax - this.freqMin);
this.currentIdx = Math.min(Math.max(Math.floor(pct * (this.maxPoints - 1)), 0), this.maxPoints - 1);
} else {
this.currentIdx = (this.currentIdx + 1) % this.maxPoints;
}
this.points[this.currentIdx] = v;
this.draw();
},
markResult(bestFreq) {
this.stopped = true;
const f = parseFloat(bestFreq);
this.optimalFreq = (!isNaN(f) && f > 0) ? f : null;
this.draw();
},
draw() {
const c = this.canvas;
if (!c) return;
if (typeof c.checkVisibility === 'function' && !c.checkVisibility()) return;
const displayW = c.clientWidth;
const displayH = c.clientHeight;
if (!displayW || !displayH) return;
if (this.points.length === 0) this.points = Array(this.maxPoints).fill(-110);
const ctx = c.getContext('2d');
const dpr = window.devicePixelRatio || 1;
c.width = displayW * dpr;
c.height = displayH * dpr;
ctx.scale(dpr, dpr);
ctx.clearRect(0, 0, displayW, displayH);
const rootStyles = getComputedStyle(document.documentElement);
let accent = rootStyles.getPropertyValue('--color-accent').trim() || '#1a5fb4';
let subTextColor = rootStyles.getPropertyValue('--color-text-secondary').trim() || '#888888';
const lblW = 30;
const gW = displayW - lblW - 35;
const paddingT = 20;
const paddingB = 25;
const graphH = displayH - paddingT - paddingB;
const getPointY = (rssiVal) => displayH - (((rssiVal + 110) / 80) * graphH) - paddingB;
const getPointX = (index) => lblW + (index * (gW / (this.maxPoints - 1)));
ctx.strokeStyle = `color-mix(in srgb, ${subTextColor} 10%, transparent)`;
ctx.font = "9px monospace";
ctx.fillStyle = subTextColor;
ctx.lineWidth = 0.5;
ctx.textAlign = "left";
ctx.save();
ctx.font = "bold 9px monospace";
ctx.fillText("dBm", 2, getPointY(-30) - 12);
ctx.restore();
[-30, -50, -70, -90, -110].forEach(lv => {
const y = getPointY(lv);
ctx.beginPath();
ctx.moveTo(lblW, y);
ctx.lineTo(lblW + gW, y);
ctx.stroke();
ctx.fillText(lv, 2, y + 3);
});
ctx.fillStyle = subTextColor;
ctx.font = "9px monospace";
ctx.textBaseline = "top";
const yLabel = displayH - paddingB + 6;
const etendue = this.freqMax - this.freqMin;
const texteEchelon = (pas, unite, i, n) =>
(this.freqMin + i * pas).toFixed(2) + (unite && i === n - 1 ? ' MHz' : '');
const xEchelon = (i, n) => lblW + (i / (n - 1)) * gW;
const tient = (pas, unite) => {
const n = Math.round(etendue / pas) + 1;
if (n < 2) return null;
const emprises = [];
for (let i = 0; i < n; i++) {
const large = ctx.measureText(texteEchelon(pas, unite, i, n)).width;
const x = xEchelon(i, n);
const debut = i === 0 ? x : (i === n - 1 ? x - large : x - large / 2);
emprises.push([debut, debut + large]);
}
for (let i = 1; i < n; i++) {
if (emprises[i][0] - emprises[i - 1][1] < 6) return null;
}
return {pas, n, unite};
};
let echelle = null;
for (const pas of [0.10, 0.20, 0.25, 0.50, 1.00]) {
echelle = tient(pas, true) || tient(pas, false);
if (echelle) break;
}
if (!echelle) echelle = {pas: etendue, n: 2, unite: false};
for (let i = 0; i < echelle.n; i++) {
const dernier = i === echelle.n - 1;
ctx.textAlign = dernier ? 'right' : (i === 0 ? 'left' : 'center');
ctx.fillText(texteEchelon(echelle.pas, echelle.unite, i, echelle.n), xEchelon(i, echelle.n), yLabel);
}
ctx.save();
ctx.beginPath();
ctx.moveTo(getPointX(0), getPointY(this.points[0]));
for (let i = 0; i < this.points.length - 1; i++) {
const x1 = getPointX(i);
const y1 = getPointY(this.points[i]);
const x2 = getPointX(i + 1);
const y2 = getPointY(this.points[i + 1]);
ctx.quadraticCurveTo(x1, y1, (x1 + x2) / 2, (y1 + y2) / 2);
}
ctx.lineTo(getPointX(this.points.length - 1), displayH - paddingB);
ctx.lineTo(getPointX(0), displayH - paddingB);
ctx.closePath();
const fillGrad = ctx.createLinearGradient(0, paddingT, 0, displayH - paddingB);
fillGrad.addColorStop(0, `color-mix(in srgb, ${accent} 35%, transparent)`);
fillGrad.addColorStop(0.7, `color-mix(in srgb, ${accent} 5%, transparent)`);
fillGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
ctx.fillStyle = fillGrad;
ctx.fill();
ctx.restore();
ctx.save();
ctx.strokeStyle = `color-mix(in srgb, ${accent} 85%, #ffffff)`;
ctx.lineWidth = 2.5;
ctx.lineCap = 'round';
ctx.lineJoin = 'round';
ctx.shadowBlur = 8;
ctx.shadowColor = accent;
ctx.beginPath();
ctx.moveTo(getPointX(0), getPointY(this.points[0]));
for (let i = 0; i < this.points.length - 1; i++) {
const x1 = getPointX(i);
const y1 = getPointY(this.points[i]);
const x2 = getPointX(i + 1);
const y2 = getPointY(this.points[i + 1]);
ctx.quadraticCurveTo(x1, y1, (x1 + x2) / 2, (y1 + y2) / 2);
}
ctx.stroke();
ctx.restore();
let centerX = getPointX(this.currentIdx);
let centerY = getPointY(this.points[this.currentIdx]);
let lineStyle = `color-mix(in srgb, ${accent} 60%, transparent)`;
let isTargetMode = false;
if (this.stopped && this.optimalFreq !== null) {
let optPct = (this.optimalFreq - this.freqMin) / (this.freqMax - this.freqMin);
if (optPct >= 0 && optPct <= 1) {
let optIdx = Math.floor(optPct * (this.maxPoints - 1));
centerX = getPointX(optIdx);
centerY = getPointY(this.points[optIdx]);
lineStyle = '#47a4f5';
isTargetMode = true;
}
}
ctx.save();
ctx.strokeStyle = lineStyle;
ctx.lineWidth = isTargetMode ? 1.5 : 1;
ctx.setLineDash(isTargetMode ? [] : [3, 3]);
ctx.beginPath();
ctx.moveTo(centerX, paddingT);
ctx.lineTo(centerX, displayH - paddingB);
ctx.stroke();
ctx.restore();
ctx.save();
ctx.fillStyle = '#ffffff';
ctx.strokeStyle = isTargetMode ? '#47a4f5' : accent;
ctx.lineWidth = 3;
ctx.shadowBlur = 12;
ctx.shadowColor = isTargetMode ? '#47a4f5' : accent;
ctx.beginPath();
ctx.arc(centerX, centerY, 5, 0, Math.PI * 2);
ctx.fill();
ctx.stroke();
ctx.restore();
if (isTargetMode) {
ctx.save();
ctx.fillStyle = "rgba(15, 23, 42, 0.9)";
ctx.strokeStyle = "rgba(71, 164, 245, 0.5)";
ctx.lineWidth = 1;
const txt1 = `${this.optimalFreq.toFixed(2)} MHz`;
const idxForDbm = Math.floor((centerX - lblW) / (gW / (this.maxPoints - 1)));
const txt2 = `${this.points[idxForDbm] || -110} dBm`;
ctx.font = "9px Arial";
const boxW = Math.max(ctx.measureText(txt1).width, ctx.measureText(txt2).width) + 16;
const boxH = 30;
const boxX = Math.max(lblW, Math.min(centerX - boxW / 2, (lblW + gW) - boxW));
const boxY = Math.max(5, centerY - boxH - 10);
ctx.beginPath();
ctx.roundRect(boxX, boxY, boxW, boxH, 4);
ctx.fill();
ctx.stroke();
ctx.fillStyle = "#ffffff";
ctx.textAlign = "center";
ctx.fillText(txt1, boxX + boxW / 2, boxY + 10);
ctx.fillStyle = "#47a4f5";
ctx.fillText(txt2, boxX + boxW / 2, boxY + 22);
ctx.restore();
}
}
};
}
if (initScan) {
div.setAttribute('data-initscan', true);
if (this.rssiGraphWave && typeof this.rssiGraphWave.reset === 'function') {
this.rssiGraphWave.reset();
}
putJSONSync('/beginFrequencyScan', {}, (err) => {
if (!err) {
if(get('scanStatusText')) get('scanStatusText').style.display = '';
if(get('scanStatusResult')) get('scanStatusResult').style.display = 'none';
if(get('btnStopScanning')) get('btnStopScanning').style.display = '';
['btnRestartScanning', 'btnCopyFrequency'].forEach(id => {
if(get(id)) get(id).style.display = 'none';
});
setOverlayLock(div, 'confirm', {
titleKey: 'PROMPT_FREQ_SCAN_TITLE',
msgKey: 'PROMPT_FREQ_SCAN_MSG',
});
}
});
}
return div;
}
setScannedFrequency() {
let div = get('divScanFrequency');
let freq = parseFloat(div.getAttribute('data-frequency'));
let slid = get('slidFrequency');
slid.value = Math.round(freq * 1000);
somfy.frequencyChanged(slid);
slid.dispatchEvent(new Event('change', { bubbles: true }));
closeOverlay(div);
}
stopScanningFrequency(killScan) {
let div = get('divScanFrequency');
if (!div) return;
if (killScan !== true) {
closeOverlay(div);
return;
}
putJSONSync('/endFrequencyScan', {}, (err, trans) => {
if (err) {
ui.serviceError(err);
} else {
let freqAttr = div.getAttribute('data-frequency');
let freq = parseFloat(freqAttr);
clearOverlayLock(div);
if (this.rssiGraphWave) this.rssiGraphWave.markResult(freq);
if (get('scanStatusText')) get('scanStatusText').style.display = 'none';
if (get('btnStopScanning')) get('btnStopScanning').style.display = 'none';
if (get('btnRestartScanning')) get('btnRestartScanning').style.display = '';
if (typeof freq === 'number' && !isNaN(freq) && freq > 0) {
if (get('btnCopyFrequency')) get('btnCopyFrequency').style.display = '';
if (get('scanStatusResult')) get('scanStatusResult').style.display = 'none';
} else {
if (get('btnCopyFrequency')) get('btnCopyFrequency').style.display = 'none';
if (get('scanStatusResult')) get('scanStatusResult').style.display = '';
}
}
});
}
terminateScanUI(killScan) {
this.isScanClosing = true;
if (this.scanObserver) {
this.scanObserver.disconnect();
this.scanObserver = null;
}
if (this._graphResizeObs) {
this._graphResizeObs.disconnect();
this._graphResizeObs = null;
}
if (killScan) {
putJSONSync('/endFrequencyScan', {}, (err) => {
if (err) logger.error('Failed to end frequency scan:', err);
});
}
let div = get('divScanFrequency');
if (div) closeOverlay(div);
setTimeout(() => { this.isScanClosing = false; }, 1000);
}
btnDown = null;
btnTimer = null;
holdTickMs = 60;
holdSweepMs = 6000;
holdRampMs = 2000;
holdDelayMs = 500;
stepValue(sliderId, direction, multiplier = 1) {
const slider = get(sliderId);
if (!slider) return;
const currentVal = parseFloat(slider.value);
const step = parseFloat(slider.step) || 1;
const min = parseFloat(slider.min);
const max = parseFloat(slider.max);
let newVal = currentVal + (step * direction * multiplier);
if (newVal < min) newVal = min;
if (newVal > max) newVal = max;
slider.value = newVal;
slider.dispatchEvent(new Event('input', { bubbles: true }));
}
startStepHold(sliderId, direction) {
this.stopStepHold();
this.stepValue(sliderId, direction, 1);
this.sliderStartTime = Date.now();
const slider = get(sliderId);
const span = slider
? Math.abs(parseFloat(slider.max) - parseFloat(slider.min)) / (parseFloat(slider.step) || 1)
: 1;
const maxStep = Math.max(1, span * this.holdTickMs / this.holdSweepMs);
const runHold = () => {
const held = Date.now() - this.sliderStartTime - this.holdDelayMs;
if (held >= 0) {
const t = Math.min(1, held / this.holdRampMs);
this.stepValue(sliderId, direction, Math.max(1, Math.round(maxStep * t * t)));
}
this.sliderTimer = setTimeout(runHold, this.holdTickMs);
};
this.sliderTimer = setTimeout(runHold, this.holdDelayMs);
}
stopStepHold() {
if (this.sliderTimer) {
clearTimeout(this.sliderTimer);
this.sliderTimer = null;
}
}
checkEmptyState() {
if (isApMode && !window.__onboardingDone) return;
if (!this.dataLoaded) return;
const getEl = id => get(id);
const setDisp = (el, show, style = 'block') => { if (el) el.style.display = show ? style : 'none'; };
const togglePair = (hasData, emptyId, contentId) => {
setDisp(getEl(emptyId), !hasData);
setDisp(getEl(contentId), hasData);
};
const divShadeControls = getEl('divShadeControls');
const divGroupControls = getEl('divGroupControls');
const divConfigPnl = getEl('divConfigPnl');
const divHomePnl = getEl('divHomePnl');
if (!divShadeControls || !divGroupControls) return;
const activePill = document.querySelector('.room-pill.active');
const currentRoomId = activePill ? parseInt(activePill.getAttribute('data-roomid'), 10) : 0;
const isConfigOpen = divConfigPnl && divConfigPnl.style.display !== 'none';
const shades = divShadeControls.querySelectorAll('.somfyShadeCtl');
const groups = divGroupControls.querySelectorAll('.somfyGroupCtl');
const hasRooms = _rooms.length > 1;
const totalDevices = shades.length + groups.length;
togglePair(hasRooms, 'divRoomEmptyState', 'divRoomListContent');
togglePair(groups.length > 0, 'divGroupEmptyState', 'divGroupListContent');
togglePair(shades.length > 0, 'divShadeEmptyState', 'divShadeListContent');
const divRepeatList = getEl('divRepeatList');
togglePair(divRepeatList && divRepeatList.children.length > 0, 'divRepeaterEmptyState', 'divRepeaterListContent');
let visibleShadesCount = 0, visibleGroupsCount = 0;
shades.forEach(el => { if (currentRoomId === 0 || parseInt(el.getAttribute('data-roomid'), 10) === currentRoomId) visibleShadesCount++; });
groups.forEach(el => { if (currentRoomId === 0 || parseInt(el.getAttribute('data-roomid'), 10) === currentRoomId) visibleGroupsCount++; });
const visibleCount = visibleShadesCount + visibleGroupsCount;
const showLogoHeader = getEl('showLogoHeader');
if (showLogoHeader) {
showLogoHeader.style.visibility = (isConfigOpen || totalDevices > 0 || hasRooms) ? 'visible' : 'hidden';
}
const isEmptyState = totalDevices === 0 && !hasRooms;
if (divHomePnl) divHomePnl.style.display = (isConfigOpen || isEmptyState) ? 'none' : '';
const divGetStarted = getEl('divGetStarted');
const divNoDevice = getEl('divNoDevice');
if (isEmptyState) {
setDisp(divGetStarted, !isConfigOpen, 'flex');
setDisp(divNoDevice, false);
setDisp(divShadeControls, false);
setDisp(divGroupControls, false);
} else {
setDisp(divGetStarted, false);
setDisp(divNoDevice, visibleCount === 0 && !isConfigOpen, 'flex');
if (divShadeControls) divShadeControls.style.display = isConfigOpen ? 'none' : '';
if (divGroupControls) divGroupControls.style.display = isConfigOpen ? 'none' : '';
const divShadeListContent = getEl('divShadeListContent');
const divGroupListContent = getEl('divGroupListContent');
if (divShadeListContent) divShadeListContent.style.display = visibleShadesCount === 0 ? 'none' : '';
if (divGroupListContent) divGroupListContent.style.display = visibleGroupsCount === 0 ? 'none' : '';
}
if (divHomePnl) divHomePnl.classList.toggle('no-groups', visibleGroupsCount === 0);
}
pulseRadioActivity() {
document.querySelectorAll('.radio-activity-dot').forEach(el => {
el.classList.add('pulse');
clearTimeout(el._radioActivityTimer);
el._radioActivityTimer = setTimeout(() => el.classList.remove('pulse'), 200);
});
}
switchMobileTab(tab) {
const container = get('dashboardContainer');
const btnGroups = get('tabGroups');
const btnDevices = get('tabDevices');
if (tab === 'devices') {
container?.classList.add('show-devices');
btnDevices?.classList.add('active');
btnGroups?.classList.remove('active');
} else {
container?.classList.remove('show-devices');
btnGroups?.classList.add('active');
btnDevices?.classList.remove('active');
}
}
setListDraggable(list, cl, cb) {
let el = null, gh = null, ch = false, sA = null;
let r = null, sY = 0, cY = 0, its = [];
const stop = () => { if(sA) cancelAnimationFrame(sA); sA = null; };
const scroll = (y) => {
stop();
let sp = 0;
if (y < 100) sp = -14;
else if (y > window.innerHeight - 100) sp = 14;
if (sp && gh) {
window.scrollBy(0, sp);
cY += sp;
gh.style.transform = "translateY(" + (cY - sY) + "px)";
sA = requestAnimationFrame(() => scroll(y));
sort();
}
};
const sort = () => {
if (!el || !gh) return;
let mid = gh.getBoundingClientRect().top + (r.height / 2);
let idx = its.indexOf(el);
its.forEach((it, i) => {
if (it === el) return;
let iM = it.getBoundingClientRect().top + (r.height / 2);
let o = 0;
if (mid < iM && its.indexOf(el) > i) {
o = r.height + 10;
if(i < idx) idx = i;
} else if (mid > iM && its.indexOf(el) < i) {
o = -(r.height + 10);
if(i >= idx) idx = i + 1;
}
it.style.transform = o ? "translateY(" + o + "px)" : "";
});
el.dataset.idx = idx;
};
const end = () => {
stop();
if (gh) { gh.remove(); gh = null; }
if (el) {
el.classList.remove('drag-orig');
let n = parseInt(el.dataset.idx, 10), o = its.indexOf(el);
if (!isNaN(n) && n !== o) {
list.insertBefore(el, its[n] || null);
ch = true;
}
}
its.forEach(it => it.style.transform = "");
if (ch && typeof cb === 'function') cb(list);
el = null; ch = false; its = [];
list.classList.remove('dragging-active');
window.removeEventListener('touchmove', move);
window.removeEventListener('touchend', end);
window.removeEventListener('mousemove', move);
window.removeEventListener('mouseup', end);
};
const move = (e) => {
if (!gh) return;
if (e.cancelable) e.preventDefault();
let t = e.touches ? e.touches[0] : e;
cY = t.clientY;
gh.style.transform = "translateY(" + (cY - sY) + "px)";
scroll(cY);
sort();
};
const start = (e, it) => {
if (e.type === 'mousedown') e.preventDefault();
el = it;
r = el.getBoundingClientRect();
its = Array.prototype.slice.call(list.querySelectorAll(cl));
let t = e.touches ? e.touches[0] : e;
sY = cY = t.clientY;
gh = el.cloneNode(true);
gh.className = 'drag-ghost';
const style = window.getComputedStyle(el);
Object.assign(gh.style, {
width: r.width + 'px',
height: r.height + 'px',
top: r.top + 'px',
left: r.left + 'px',
});
document.body.appendChild(gh);
el.classList.add('drag-orig');
list.classList.add('dragging-active');
if (navigator.vibrate) navigator.vibrate(30);
window.addEventListener('touchmove', move, {passive:false});
window.addEventListener('touchend', end);
window.addEventListener('mousemove', move);
window.addEventListener('mouseup', end);
};
list.querySelectorAll(cl).forEach(it => {
let h = it.querySelector('.drag-handle');
if (h) {
h.addEventListener('touchstart', (e) => start(e, it), {passive:true});
h.addEventListener('mousedown', (e) => start(e, it));
}
});
}
_handleLinkFrame(frame) {
const repeaterDiv = get('divLinkRepeater');
if (repeaterDiv) {
const overlay = ui.waitMessage(repeaterDiv);
putJSON('/linkRepeater', { address: frame.address }, (err, data) => {
overlay.remove();
repeaterDiv.remove();
if (err) ui.serviceError(err);
else this.setRepeaterList(data);
});
return;
}
const div = get('divRemotesOverlay');
if (!div || div.dataset.searching !== 'true' || div.classList.contains('overlay-exit') || div.dataset.searchbusy === 'true') return;
const shadeId = parseInt(div.dataset.shadeid, 10);
div.dataset.searchbusy = 'true';
putJSON('/linkRemote', { shadeId, remoteAddress: frame.address, rollingCode: frame.rcode }, (err, data) => {
delete div.dataset.searchbusy;
if (err) { ui.serviceError(err); return; }
const linked = (data.linkedRemotes || []).find(r => r.remoteAddress === frame.address);
if (linked && (typeof linked.lastRssi !== 'number' || linked.lastRssi <= -128)) linked.lastRssi = frame.rssi;
this.setRemoteSearchState(div, false);
this.setLinkedRemotesList(data);
ui.successMessage(tr('MSG_REMOTE_LINKED_SUCCESS').replace('%s', frame.rssi));
});
}
_updateLiveRemoteSignal(frame) {
const overlay = get('divRemotesOverlay');
if (!overlay) return;
const row = overlay.querySelector(`.somfyLinkedRemote[data-remoteaddress="${frame.address}"]`);
if (!row) return;
const signalEl = row.querySelector('.linkedRemote-signal');
if (signalEl) signalEl.outerHTML = this.remoteSignalHtml(frame.rssi, frame.address);
}
procRemoteFrame(frame) {
this.radioTestOnFrame(frame);
const dt = new Date();
frame.time = `${dt.getHours().fmt('00')}:${dt.getMinutes().fmt('00')}:${dt.getSeconds().fmt('00')}.${dt.getMilliseconds().fmt('000')}`;
const spanRssi = get('spanRssi');
if (spanRssi) spanRssi.innerHTML = frame.rssi;
const spanCount = get('spanFrameCount');
if (spanCount) spanCount.innerHTML = parseInt(spanCount.innerHTML || 0, 10) + 1;
this._handleLinkFrame(frame);
this._updateLiveRemoteSignal(frame);
this.frames.push(frame);
this.frameCount++;
while (this.frames.length > this.frameLimit) {
this.frames.shift();
this.frameBaseSeq++;
}
const now = Date.now();
this.frameStamps.push(now);
while (this.frameStamps.length && this.frameStamps[0] < now - 60000) this.frameStamps.shift();
if (!this.isFrameLogVisible()) {
this.frameLogStale = true;
return;
}
this.updateFrameLogStatus();
if (this.frameLogPaused) return;
const list = get('divFrames');
if (!list) return;
if (this.frameMatches(frame)) {
this.ensureFrameLogBound();
list.insertAdjacentHTML('afterbegin', this.frameRowHtml(frame, this.frameBaseSeq + this.frames.length - 1, true));
while (list.children.length > this.frameLimit) list.lastElementChild.remove();
if (list.children.length === 1) this.updateFrameLogEmptyState();
}
else if (this.frames.length === 1) this.updateFrameLogEmptyState();
}
isFrameLogVisible() {
return this.frameLogVisible;
}
procRfNoise(msg) {
if (typeof msg.episodes === 'number') this.rfNoiseEpisodes = msg.episodes;
this.rfNoiseUntil = Date.now() + 3000;
if (this.isFrameLogVisible()) this.updateFrameLogStatus();
}
showFrameLog() {
this.frameLogVisible = true;
const lim = get('spanLogLimit');
if (lim) lim.textContent = this.frameLimit;
this.ensureFrameLogBound();
if (this.frameLogStale) {
this.frameLogStale = false;
this.renderFrameLog();
}
else {
this.updateFrameLogStatus();
this.updateFrameLogEmptyState();
}
this.startFrameRateTimer();
}
ensureFrameLogBound() {
if (this.frameLogBound) return;
const list = get('divFrames');
if (!list) return;
list.addEventListener('click', (evt) => {
const row = evt.target.closest('.frame-row');
if (row) this.toggleFrameDetails(row);
});
this.frameLogBound = true;
}
startFrameRateTimer() {
if (this.frameRateTimer) return;
this.frameRateTimer = setInterval(() => {
if (!this.isFrameLogVisible()) {
clearInterval(this.frameRateTimer);
this.frameRateTimer = null;
return;
}
const now = Date.now();
while (this.frameStamps.length && this.frameStamps[0] < now - 60000) this.frameStamps.shift();
this.updateFrameLogStatus();
}, 2000);
}
frameBySeq(seq) {
const idx = seq - this.frameBaseSeq;
return (idx >= 0 && idx < this.frames.length) ? this.frames[idx] : null;
}
frameMatches(frame) {
if (this.frameValidOnly && !frame.valid) return false;
if (!this.frameFilter) return true;
const known = this.frameAddressName(frame.address);
const hay = [frame.address, frame.command, frame.rcode, frame.encKey, known ? known.name : ''].join(' ').toLowerCase();
return hay.indexOf(this.frameFilter) >= 0;
}
frameAddressName(address) {
const addr = Number(address);
for (const shade of (this.shades || [])) {
if (Number(shade.remoteAddress) === addr) return { name: shade.name, own: true };
if ((shade.linkedRemotes || []).some(r => Number(r.remoteAddress) === addr)) return { name: shade.name, own: false };
}
const group = (this.groups || []).find(g => Number(g.remoteAddress) === addr);
return group ? { name: group.name, own: true } : null;
}
frameProtoLabel(proto) {
return proto === 1 ? 'RTW' : proto === 2 ? 'RTV' : 'RTS';
}
frameCommandIcon(command) {
switch (String(command || '').toLowerCase()) {
case 'up':
case 'step up':
return 'svg-up';
case 'down':
case 'step down':
return 'svg-down';
case 'my':
return 'svg-my';
case 'my+up':
case 'my+down':
case 'my+up+down':
case 'up+down':
case 'toggle':
return 'svg-toggle';
case 'prog':
return 'svg-pair';
case 'sun flag':
return 'vr-sunflag-o';
case 'flag':
return 'vr-sunflag-c';
case 'sensor':
return 'svg-sensorlight';
case 'favorite':
return 'svg-favori';
case 'stop':
return 'svg-stop';
default:
return 'svg-wave';
}
}
rssiLevel(rssi) {
if (typeof rssi !== 'number' || rssi <= -128) return 'unknown';
return rssi > -70 ? 'good' : rssi > -85 ? 'medium' : 'bad';
}
frameRowHtml(frame, seq, isNew) {
const known = this.frameAddressName(frame.address);
const step = frame.stepSize ? `<sup>${escHtml(frame.stepSize)}</sup>` : '';
const badge = frame.valid ? '' : `<span class="frame-badge-invalid">${tr('LOG_INVALID')}</span>`;
const name = known
? `<span class="frame-addr-name${known.own ? ' is-own' : ''}">${escHtml(known.name)}</span>`
: `<span class="frame-addr-name is-unknown">${tr('LOG_UNKNOWN')}</span>`;
return `<div class="frame-row${isNew ? ' frame-row-new' : ''}" data-seq="${seq}" data-valid="${frame.valid}">
            <div class="frame-main">
                <span class="frame-cell frame-time" data-label="${escAttr(tr('RADIO_TIME'))}">${escHtml(frame.time)}</span>
                <span class="frame-cell frame-cmd" data-label="${escAttr(tr('RADIO_COMMAND'))}"><svg class="frame-cmd-icon"><use href="#${this.frameCommandIcon(frame.command)}"></use></svg><span class="frame-cmd-text">${escHtml(frame.command)}${step}</span>${badge}</span>
                <span class="frame-cell frame-addr" data-label="${escAttr(tr('RADIO_ADRESS'))}"><span class="frame-addr-value">${escHtml(frame.address)}</span>${name}</span>
                <span class="frame-cell frame-rssi sig-${this.rssiLevel(frame.rssi)}" data-label="${escAttr(tr('SCANFREQ_RSSI'))}">${escHtml(frame.rssi)}<em>${tr('UNIT_DBM')}</em></span>
                <span class="frame-cell frame-key" data-label="${escAttr(tr('RADIO_KEY'))}">${escHtml(frame.encKey)}</span>
                <span class="frame-cell frame-code" data-label="${escAttr(tr('RADIO_CODE'))}">${escHtml(frame.rcode)}</span>
                <span class="frame-cell frame-bits" data-label="${escAttr(tr('RADIO_BITS'))}">${escHtml(frame.bits)}<em>${this.frameProtoLabel(frame.proto)}</em></span>
                <span class="frame-cell frame-toggle"><svg><use href="#svg-arrowDown"></use></svg></span>
            </div>
            <div class="frame-details"></div>
        </div>`;
}
frameDetailsHtml(frame) {
const pulses = Array.isArray(frame.pulses) ? frame.pulses : [];
const duration = pulses.reduce((sum, p) => sum + p, 0) / 1000;
const items = [
[tr('PROTOCOL'), this.frameProtoLabel(frame.proto)],
[tr('LOG_SYNC'), frame.sync],
[tr('LOG_DURATION'), `${duration.toFixed(1)} ms`]
];
const grid = items.map(([label, value]) =>
`<div class="frame-detail-item"><span class="frame-detail-label">${escHtml(label)}</span><span class="frame-detail-value">${escHtml(value)}</span></div>`).join('');
return `<div class="frame-detail-grid">${grid}</div>
        <div class="frame-pulses-block">
            <div class="frame-pulses-head"><span>${tr('LOG_PULSES')}</span><span class="frame-pulses-count">${pulses.length}</span></div>
            <div class="frame-pulses">${escHtml(pulses.join(', '))}</div>
        </div>`;
}
toggleFrameDetails(row) {
const box = row.querySelector('.frame-details');
if (!box) return;
const open = row.classList.toggle('expanded');
if (!open) {
box.innerHTML = '';
return;
}
const frame = this.frameBySeq(parseInt(row.dataset.seq, 10));
box.innerHTML = frame ? this.frameDetailsHtml(frame) : '';
}
renderFrameLog() {
const list = get('divFrames');
if (!list) return;
this.ensureFrameLogBound();
let html = '';
for (let i = this.frames.length - 1; i >= 0; i--) {
if (this.frameMatches(this.frames[i])) html += this.frameRowHtml(this.frames[i], this.frameBaseSeq + i, false);
}
list.innerHTML = html;
this.updateFrameLogStatus();
this.updateFrameLogEmptyState();
}
updateFrameLogStatus() {
const count = get('spanLogCount');
if (count) count.textContent = this.frameCount;
const rate = get('spanLogRate');
if (rate) rate.textContent = this.frameStamps.length;
const last = this.frames.length ? this.frames[this.frames.length - 1] : null;
const rssi = get('spanLogRssi');
if (rssi) {
rssi.textContent = last ? last.rssi : '--';
rssi.className = `log-metric-value sig-${last ? this.rssiLevel(last.rssi) : 'unknown'}`;
}
const state = get('divLogLiveState');
const text = get('spanLogLiveText');
if (state && text) {
const online = (typeof sockIsOpen === 'undefined') || sockIsOpen;
const jammed = Date.now() < this.rfNoiseUntil;
const mode = this.frameLogPaused ? 'paused' : !online ? 'offline' : jammed ? 'jammed' : 'live';
const keys = { paused: 'LOG_PAUSED', offline: 'LOG_OFFLINE', jammed: 'LOG_JAMMED', live: 'LOG_LIVE' };
const key = keys[mode];
state.dataset.state = mode;
text.setAttribute('tr', key);
text.textContent = tr(key);
}
}
updateFrameLogEmptyState() {
const list = get('divFrames');
const empty = get('divFramesEmpty');
if (!list || !empty) return;
const shown = list.children.length;
list.style.display = shown ? '' : 'none';
empty.style.display = shown ? 'none' : '';
if (shown) return;
const titleKey = this.frames.length ? 'LOG_NOMATCH_TITLE' : 'LOG_EMPTY_TITLE';
const descKey = this.frames.length ? 'LOG_NOMATCH_DESC' : 'LOG_EMPTY_DESC';
const title = get('spanFramesEmptyTitle');
const desc = get('spanFramesEmptyDesc');
if (title) {
title.setAttribute('tr', titleKey);
title.textContent = tr(titleKey);
}
if (desc) {
desc.setAttribute('tr', descKey);
desc.textContent = tr(descKey);
}
}
setFrameFilter(value) {
const raw = String(value || '');
this.frameFilter = raw.trim().toLowerCase();
const fld = get('fldLogFilter');
if (fld && fld.value !== raw) fld.value = raw;
const clear = get('btnLogFilterClear');
if (clear) clear.style.display = this.frameFilter ? '' : 'none';
this.renderFrameLog();
}
toggleFrameValidOnly() {
this.frameValidOnly = !this.frameValidOnly;
const btn = get('btnLogValidOnly');
if (btn) btn.classList.toggle('active', this.frameValidOnly);
this.renderFrameLog();
}
toggleFrameLogPause() {
this.frameLogPaused = !this.frameLogPaused;
const btn = get('btnLogPause');
if (btn) btn.classList.toggle('active', this.frameLogPaused);
const icon = get('svgLogPause');
if (icon && icon.firstElementChild) icon.firstElementChild.setAttribute('href', this.frameLogPaused ? '#svg-play' : '#svg-stop');
const label = get('spanLogPause');
if (label) {
const key = this.frameLogPaused ? 'BT_RESUME' : 'BT_PAUSE';
label.setAttribute('tr', key);
label.textContent = tr(key);
}
if (this.frameLogPaused) this.updateFrameLogStatus();
else this.renderFrameLog();
}
clearFrames() {
this.frames = [];
this.frameStamps = [];
this.frameCount = 0;
this.frameBaseSeq = 0;
const list = get('divFrames');
if (list) list.innerHTML = '';
this.updateFrameLogStatus();
this.updateFrameLogEmptyState();
}
JSONPretty(obj, indent = 2) {
if (Array.isArray(obj)) {
let output = '[';
for (let i = 0; i < obj.length; i++) {
if (i !== 0) output += ',\n';
output += this.JSONPretty(obj[i], indent);
}
output += ']';
return output;
}
else {
let output = JSON.stringify(obj, function (k, v) {
if (Array.isArray(v)) return JSON.stringify(v);
return v;
}, indent).replace(/\\/g, '')
.replace(/\"\[/g, '[')
.replace(/\]\"/g, ']')
.replace(/\"\{/g, '{')
.replace(/\}\"/g, '}')
.replace(/\{\n\s+/g, '{');
return output;
}
}
framesToClipboard() {
const frames = this.frames.filter(f => this.frameMatches(f));
if (typeof navigator.clipboard !== 'undefined')
navigator.clipboard.writeText(this.JSONPretty(frames, 2));
else {
let dummy = document.createElement('textarea');
document.body.appendChild(dummy);
dummy.value = this.JSONPretty(frames, 2);
dummy.focus();
dummy.select();
document.execCommand('copy');
document.body.removeChild(dummy);
}
}
vrTarget() {
const t = this._vrTarget;
if (!t) return null;
if (t.type === 'group') {
const g = (this.groups || []).find(x => x.groupId === t.id);
return g ? { type: 'group', id: t.id, name: g.name, address: g.remoteAddress, bitLength: g.bitLength, group: g } : null;
}
const s = (this.shades || []).find(x => x.shadeId === t.id);
return s ? { type: 'shade', id: t.id, name: s.name, address: s.remoteAddress, bitLength: s.bitLength, shadeType: s.shadeType, shade: s } : null;
}
vrContent() {
if (!this._vrContent) this._vrContent = get('divVRContent');
return this._vrContent;
}
vrEl(id) {
const content = this.vrContent();
return content ? content.querySelector('#' + id) : null;
}
restoreVRHome() {
const home = get('divVRHome');
const content = this.vrContent();
if (home && content && content.parentElement !== home) home.appendChild(content);
this._vrTarget = null;
}
updateVRPosition(shade, root) {
const ov = root || document.querySelector('.vr-overlay');
const el = ov ? ov.querySelector('.vr-target-pos') : null;
if (!el) return;
if (!shade || typeof shade.position !== 'number') { el.textContent = ''; return; }
let txt = `${tr('POS_SHORT')} ${Math.round(shade.position)}%`;
if (shade.tiltType) txt += ` ${tr('TILT_SHORT')} ${Math.round(shade.tiltPosition)}%`;
el.textContent = txt;
}
closeVirtualRemote() {
const ov = document.querySelector('.vr-overlay');
if (ov) closeOverlay(ov);
else this.restoreVRHome();
}
openVirtualRemote(type, id) {
const content = this.vrContent();
if (!content || document.querySelector('.vr-overlay')) return;
this._vrTarget = { type: type, id: parseInt(id, 10) };
const info = this.vrTarget();
if (!info) { this._vrTarget = null; return; }
let div = document.createElement('div');
div.className = 'modal-overlay vr-overlay';
div.setAttribute('data-radio', content.getAttribute('data-radio') || 'on');
div.innerHTML = `
        <div class="message-content vr-overlay-content">
        <div class="overlayHeader vr-overlay-header">
        <div class="overlayHeader-block">
        <div class="overlayHeader-badge">
        <svg><use href="#${info.type === 'group' ? 'svg-group' : 'svg-remote'}"></use></svg>
        </div>
        <div class="overlayHeader-texts">
        <span class="overlayHeader-title">${tr('SUBTAB_VIRTUAL_REMOTE_L')}</span>
        <span class="overlayHeader-subtitle"><span class="vr-target-name"></span><span class="vr-target-pos"></span></span>
        </div>
        </div>
        <div class="overlayHeader-right">
        <div close title="${tr('BT_CLOSE')}"><svg><use href="#svg-closeOverlay"></use></svg></div>
        </div>
        </div>
        <div class="overlay-scroll-content"></div>
        </div>`;
const name = div.querySelector('.vr-target-name');
if (name) name.textContent = info.name;
this.updateVRPosition(info.shade, div);
if (div.getAttribute('data-radio') === 'off') {
const badge = div.querySelector('.overlayHeader-badge');
if (badge) badge.setAttribute('title', tr('RADIO_DISABLED'));
}
this.syncVRLayout();
this.loadVRState();
div.querySelector('.overlay-scroll-content').appendChild(content);
const obs = new MutationObserver(() => {
if (div.isConnected) return;
obs.disconnect();
this.restoreVRHome();
});
obs.observe(get('divContainer'), { childList: true });
shOverlay(div);
}
sendVRCommand(el, evt) {
if (!isPrimaryPress(evt)) return;
const info = this.vrTarget();
if (!info) return;
let o = {
type: info.type,
address: info.address,
cmd: el.getAttribute('data-cmd')
};
if (info.type === 'group') o.groupId = info.id;
else {
o.shadeId = info.id;
o.shadeType = info.shadeType;
}
if (o.cmd === 'Sensor') {
const cbSunny = this.vrEl('cbSunny'), cbWindy = this.vrEl('cbWindy');
if (cbSunny) o.sunny = cbSunny.checked;
if (cbWindy) o.windy = cbWindy.checked;
}
else if (o.cmd === 'StepUp' || o.cmd === 'StepDown') {
const slider = this.vrEl('vrslidStepSize');
if (slider) o.stepSize = parseInt(slider.value, 10);
}
let fnVRError = (err) => { if (err) ui.serviceError(err); };
if (el.getAttribute('data-tilt') === 'true') {
if (info.type !== 'shade') return;
logger.debug('Virtual remote tilt command:', o);
this.pulseVRBadge();
if (o.cmd === 'My') {
const my = info.shade.myTiltPos;
if (typeof my !== 'number' || my < 0) return;
somfy.sendTiltCommand(info.id, my, fnVRError);
}
else somfy.sendTiltCommand(info.id, o.cmd, fnVRError);
return;
}
logger.debug('Virtual remote command:', o);
this.pulseVRBadge();
let fnRepeatCommand = (err, shade) => {
if (this.btnTimer) {
clearTimeout(this.btnTimer);
this.btnTimer = null;
}
if (err) {
ui.serviceError(err);
return;
}
if (mouseDown) {
if (o.cmd === 'Sensor')
somfy.sendSetSensor(o, fnVRError);
else if (o.type === 'group')
somfy.sendGroupRepeat(o.groupId, o.cmd, null, fnRepeatCommand, o.stepSize);
else
somfy.sendCommandRepeat(o, fnRepeatCommand);
}
}
o.command = o.cmd;
if (o.cmd === 'Sensor') {
somfy.sendSetSensor(o, fnVRError);
}
else if (o.type === 'group')
somfy.sendGroupCommand(o.groupId, o.cmd, null, (err, group) => { fnRepeatCommand(err, group); }, o.stepSize);
else
somfy.sendCommand(o, (err, shade) => { fnRepeatCommand(err, shade); });
}
sendSetSensor(obj, cb) {
putJSON('/setSensor', obj, (err, device) => {
if (typeof cb === 'function') cb(err, device);
});
}
vrIsImpulse(info) {
if (!info) return false;
if (info.type === 'group') {
const linked = info.group.linkedShades || [];
return linked.length > 0 && linked.every(s => this.noMyShadeTypes.includes(s.shadeType));
}
return this.noMyShadeTypes.includes(info.shadeType);
}
syncVRLayout() {
const content = this.vrContent();
if (!content) return;
const info = this.vrTarget();
if (!info) {
if (this._vrTarget) this.closeVirtualRemote();
return;
}
content.setAttribute('data-bitlength', info.bitLength);
const impulse = this.vrIsImpulse(info);
content.setAttribute('data-kind', impulse ? 'impulse' : 'standard');
this.setVRCenterButton(impulse, this.vrIsMoving(info.shade));
this.setVRSunFlag((info.shade || info.group).flags);
this.setVRSunSensor(!!(info.shade || info.group).sunSensor);
content.setAttribute('data-tilt', this.vrTiltUsable(info) ? 'yes' : 'no');
this.setVRTiltMy(info.shade);
this.setVRTiltLabels();
}
loadVRState() {
const info = this.vrTarget();
const cbSunny = this.vrEl('cbSunny'), cbWindy = this.vrEl('cbWindy'), slider = this.vrEl('vrslidStepSize');
const flags = (info && info.type === 'shade') ? (info.shade.flags || 0) : 0;
if (cbSunny) cbSunny.checked = (flags & 0x20) !== 0;
if (cbWindy) cbWindy.checked = (flags & 0x10) !== 0;
if (slider) {
slider.value = slider.getAttribute('value') || 1;
syncSliderProgress(slider);
const span = this.vrEl('vrspanStepSize');
if (span) span.innerText = slider.value;
}
}
setVRCenterButton(impulse, moving) {
const btn = this.vrEl('divVRCenter');
const icon = this.vrEl('divVRCenterIcon');
if (!btn || !icon) return;
const cle = moving ? 'BT_STOP' : (impulse ? 'VR_TOGGLE' : 'BT_MY');
btn.setAttribute('data-cmd', impulse ? 'toggle' : 'my');
btn.setAttribute('tr', cle);
btn.setAttribute('title', tr(cle));
icon.setAttribute('href', moving ? '#svg-toggleHand' : (impulse ? '#svg-toggle' : '#svg-my'));
}
setVRSunSensor(has) {
const content = this.vrContent();
if (content) content.setAttribute('data-sunsensor', has ? 'yes' : 'no');
}
setVRSunFlag(flags) {
const btn = this.vrEl('divVRSunFlag');
const icon = this.vrEl('divVRSunFlagIcon');
if (!btn || !icon) return;
const on = ((flags || 0) & 0x01) === 0x01;
const cle = on ? 'VR_SUN_FLAG_OFF' : 'VR_SUN_FLAG_ON';
btn.setAttribute('data-on', on ? 'true' : 'false');
btn.setAttribute('data-cmd', on ? 'Flag' : 'SunFlag');
btn.setAttribute('tr', cle);
btn.setAttribute('title', tr(cle));
icon.setAttribute('href', on ? '#vr-sunflag-o' : '#vr-sunflag-c');
}
vrTiltUsable(info) {
if (!info || info.type !== 'shade') return false;
const t = parseInt(info.shade.tiltType, 10) || 0;
return t === 1 || t === 2 || t === 4;
}
setVRTiltLabels() {
const pre = tr('OPT_PAGE_TILT');
[['divVRTiltUp', 'BT_OPEN'], ['divVRTiltMy', 'BT_MY'], ['divVRTiltDown', 'BT_CLOSE']].forEach(([id, cle]) => {
const el = this.vrEl(id);
if (el) el.setAttribute('title', `${pre} · ${tr(cle)}`);
});
}
setVRTiltMy(shade) {
const content = this.vrContent();
if (!content) return;
const my = shade ? shade.myTiltPos : -1;
content.setAttribute('data-tiltmy', (typeof my === 'number' && my >= 0) ? 'yes' : 'no');
}
vrIsMoving(shade) {
if (!shade) return false;
return (shade.direction || 0) !== 0 || (shade.tiltDirection || 0) !== 0;
}
bindVRKeyboard() {
const content = this.vrContent();
if (!content) return;
content.addEventListener('keydown', (evt) => {
if (evt.key !== 'Enter' && evt.key !== ' ' && evt.key !== 'Spacebar') return;
const btn = evt.target.closest('.vr-cmd-btn');
if (!btn || !content.contains(btn)) return;
evt.preventDefault();
this.sendVRCommand(btn, evt);
});
}
setVRRadioState(isOn) {
const content = this.vrContent();
if (!content) return;
content.setAttribute('data-radio', isOn ? 'on' : 'off');
const txt = tr(isOn ? 'RADIO_ENABLED' : 'RADIO_DISABLED');
const status = this.vrEl('divVRRadioStatus');
if (status) status.innerText = txt;
const ov = document.querySelector('.vr-overlay');
if (!ov) return;
ov.setAttribute('data-radio', isOn ? 'on' : 'off');
const badge = ov.querySelector('.overlayHeader-badge');
if (badge) {
if (isOn) badge.removeAttribute('title');
else badge.setAttribute('title', txt);
}
}
pulseVRBadge() {
const ov = document.querySelector('.vr-overlay');
const badge = ov ? ov.querySelector('.overlayHeader-badge') : null;
if (!badge) return;
badge.classList.remove('pulse');
void badge.offsetWidth;
badge.classList.add('pulse');
clearTimeout(badge._vrPulseTimer);
badge._vrPulseTimer = setTimeout(() => badge.classList.remove('pulse'), 600);
}
get radioDefaults() {
return { frequency: 433.42, rxBandwidth: 99.97, txPower: 10 };
}
resetRadioSettings() {
const prompt = ui.promptMessage(tr('PROMPT_RADIO_RESET_TITLE'), () => this.applyRadioDefaults());
const sub = prompt && prompt.querySelector('.sub-message');
if (sub) sub.innerHTML = `<p>${tr('PROMPT_RADIO_RESET_MSG')}</p>`;
}
applyRadioDefaults() {
const d = this.radioDefaults;
const put = (id, v, fn) => {
const el = get(id);
if (!el) return;
el.value = v;
if (typeof this[fn] === 'function') this[fn](el);
el.dispatchEvent(new Event('change', { bubbles: true }));
};
put('slidFrequency', Math.round(d.frequency * 1000), 'frequencyChanged');
put('slidRxBandwidth', Math.round(d.rxBandwidth * 100), 'rxBandwidthChanged');
const iTx = this.txPowerLevels.indexOf(d.txPower);
if (iTx >= 0) put('slidTxPower', iTx, 'txPowerChanged');
put('selRadioProto', 0, null);
put('selRadioType', 56, null);
this.updateRadioGraph();
const st = get('divRadioEnableStatus');
if (st) st.textContent = tr('RADIO_SAVE_REQUIRED');
}
get wizConst() {
return {
seuil: -75,
pasKHz: 10,
bwUsine: 99.97,
bwMin: 58.03, bwMax: 812.50,
silenceMs: 26000
};
}
get radioApplied() { return this._radioApplied || null; }
refreshRadio() {
getJSON('/getRadio', (err, res) => {
if (err || !res || !res.config) return;
this._radioApplied = Object.assign({}, res.config);
ui.toElement(get('divTransceiverSettings'), { transceiver: res });
const cb = get('cbEnableRadio');
if (cb) cb.checked = !!res.config.enabled;
const sel = get('selRadioBoardType');
if (sel) {
sel.value = res.config.radioBoardType || 0;
this.onRadioBoardTypeChanged(sel);
}
clearDirty(get('divTransceiverSettings'));
this.setRadioEnabled(!!res.config.enabled);
this.updateRadioGraph();
});
}
watchRadioEdits() {
const panneau = get('divTransceiverSettings');
if (!panneau || this._radioEditWatched) return;
this._radioEditWatched = true;
const signaler = () => {
const st = get('divRadioEnableStatus');
if (st) st.textContent = tr('RADIO_SAVE_REQUIRED');
this.updateRadioRecap();
};
panneau.addEventListener('input', signaler);
panneau.addEventListener('change', signaler);
}
setRadioMode(mode) {
const m = (mode === 'manual') ? 'manual' : 'assist';
const assiste = get('divRadioAssist'), man = get('divRadioManual');
if (assiste) assiste.style.display = (m === 'assist') ? '' : 'none';
if (man) man.style.display = (m === 'manual') ? '' : 'none';
const rb = get(m === 'assist' ? 'radioModeAssist' : 'radioModeManual');
if (rb) rb.checked = true;
try { localStorage.setItem('espsomfy_radio_mode', m); }
catch (e) { }
}
restoreRadioMode() {
let m = 'assist';
try { m = localStorage.getItem('espsomfy_radio_mode') || 'assist'; }
catch (e) { }
this.setRadioMode(m);
}
radioPrete() {
const onglet = document.querySelector('.tab-container span[data-grpid="divRadioSettings"]');
if (!onglet || !onglet.classList.contains('radio-error')) return true;
const cb = get('cbEnableRadio');
ui.infoMessage('RADIO_OFF_TITLE', (cb && cb.checked) ? 'RADIO_OFF_UNSAVED' : 'RADIO_OFF_MSG');
return false;
}
radioWizard() {
if (!this.radioPrete()) return;
this.wizStopping = false;
this.wiz = { etat: 'intro', mesures: [], pas: {}, meilleur: -100, depuis: 0, exclue: null };
let div = get('divRadioWizard');
if (!div) {
div = document.createElement('div');
div.id = 'divRadioWizard';
div.className = 'inst-overlay';
div.innerHTML = `
            <div class="instructions-content">
            ${overlayHeader('RADIO_WIZ_TITLE', 'RADIO_WIZ_DESC', 'svg-tabRadio',
{ subtitle: 'RADIO_WIZ_DESC', showInfo: false })}
            <div class="overlay-scroll-content">
            <div id="wizBody"></div>
            </div>
            <!-- Pied de page au patron des .inst-overlay (cf. la fenetre de balayage), et non a
            celui des modales : .button-content-modal porte un padding taille pour
            .message-content, qui ne correspond pas a la geometrie de .instructions-content. -->
            <div class="hrDivFooter-Instruc"></div>
            <div class="button-container-overlay" id="wizFooter"></div>
            </div>`;
shOverlay(div, () => this.wizAbandon());
}
this.wizRender();
return div;
}
wizRender() {
const w = this.wiz, body = get('wizBody'), foot = get('wizFooter');
if (!w || !body || !foot) return;
const btn = (id, key, cls, action) =>
`<button id="${id}" type="button" ${cls} onclick="somfy.${action}">${tr(key)}</button>`;
const liste = () => w.mesures.length
? `<ul class="wiz-liste">${w.mesures.map((m, i) =>
`<li>${tr('RADIO_WIZ_REMOTE').replace('{n}', i + 1)} — <b>${m.freq.toFixed(3)} MHz</b> (${m.rssi} ${tr('UNIT_DBM')})</li>`).join('')}</ul>`
: '';
switch (w.etat) {
case 'intro':
body.innerHTML = `
                    <div class="empty-state wiz-accueil">
                    <svg class="empty-icon"><use href="#svg-linkRemot"></use></svg>
                    <div class="label">${tr('RADIO_WIZ_STEP1_TITLE')}</div>
                    <div class="empty-subtext">${tr('RADIO_WIZ_STEP1_DESC')}</div>
                    </div>`;
foot.innerHTML = btn('btnWizCancel', 'BT_CANCEL', 'line', 'wizFermer();')
+ btn('btnWizGo', 'BT_BEGIN', '', 'wizEcouter();');
break;
case 'ecoute':
body.innerHTML = `<div class="information-text">
                    <span class="wiz-title">${tr('RADIO_WIZ_PRESS_TITLE').replace('{n}', w.mesures.length + 1)}</span>
                    <span>${tr('RADIO_WIZ_PRESS_DESC')}</span></div>
                    <div class="progress-bar-header">
                        <span class="progress-bar-label" id="wizNiveau">${tr('RADIO_WIZ_LISTENING')}</span>
                        <span class="progress-bar-value" id="wizChrono">0 s</span>
                    </div>
                    <div class="progress-bar" id="wizBarre"><div class="progress-bar-fill"></div></div>
                    ${liste()}`;
foot.innerHTML = btn('btnWizStop', 'BT_CANCEL', 'line', 'wizFermer();');
break;
case 'mesuree': {
const m = w.mesures[w.mesures.length - 1];
body.innerHTML = `<div class="information-text">
                    <span class="wiz-title">${tr('RADIO_WIZ_MEASURED_TITLE').replace('{n}', w.mesures.length)}</span>
                    <span>${tr('RADIO_WIZ_MEASURED_DESC').replace('{freq}', m.freq.toFixed(3)).replace('{rssi}', m.rssi)}</span>
                    </div>${liste()}`;
foot.innerHTML = btn('btnWizMore', 'BT_ANOTHER', 'line', 'wizEcouter();')
+ btn('btnWizDone', 'BT_FINISH', '', 'wizTerminer();');
break;
}
case 'silence':
body.innerHTML = `<div class="wiz-notice warning">
                    <svg><use href="#svg-warning"></use></svg>
                    <div class="wiz-notice-texte">
                    <span class="wiz-title">${tr('RADIO_WIZ_SILENT_TITLE')}</span>
                    <span>${tr(w.meilleur > this.wizConst.seuil ? 'RADIO_WIZ_PARTIAL_DESC' : 'RADIO_WIZ_SILENT_DESC')}</span>
                    </div></div>${liste()}`;
foot.innerHTML = btn('btnWizSkip', 'BT_SKIP', 'line',
w.mesures.length ? 'wizTerminer();' : 'wizFermer();')
+ btn('btnWizRetry', 'BT_RETRY', '', 'wizEcouter();');
break;
case 'aberrante': {
const r = this.wizCalcul(), i = this.wizAberrante();
body.innerHTML = `<div class="wiz-notice warning">
                    <svg><use href="#svg-warning"></use></svg>
                    <div class="wiz-notice-texte">
                    <span class="wiz-title">${tr('RADIO_WIZ_OUTLIER_TITLE')}</span>
                    <span>${tr('RADIO_WIZ_OUTLIER_DESC')
.replace('{n}', i + 1)
.replace('{freq}', w.mesures[i].freq.toFixed(3))
.replace('{ecart}', Math.round(r.etendueKHz))}</span>
                    </div></div>${liste()}`;
foot.innerHTML = btn('btnWizKeepAll', 'BT_CANCEL', 'line', 'wizFermer();')
+ btn('btnWizDrop', 'BT_SKIP_DROP', '', `wizExclure(${i});`);
break;
}
case 'resultat': {
const r = this.wizCalcul();
const usine = Math.abs(r.bande - this.wizConst.bwUsine) < 0.01;
body.innerHTML = `<div class="information-text">
                    <span class="wiz-title">${tr('RADIO_WIZ_RESULT_TITLE')}</span>
                    <span>${tr(usine ? 'RADIO_WIZ_RESULT_STOCK' : 'RADIO_WIZ_RESULT_WIDENED')}</span></div>
                    <div class="wiz-resultat">
                        <div><span>${tr('RADIO_BASE_FREQUENCY')}</span><b>${r.centre.toFixed(3)} MHz</b></div>
                        <div><span>${tr('RADIO_RX_BANDWIDTH')}</span><b>${r.bande.toFixed(2)} kHz</b></div>
                    </div>${liste()}
`;
foot.innerHTML = btn('btnWizBack', 'BT_GO_BACK', 'line', 'wizRetour();')
+ btn('btnWizApply', 'BT_SAVE', '', 'wizAppliquer();');
break;
}
}
this.wizMajVerrou();
}
wizEcouter() {
const w = this.wiz;
if (!w) return;
w.etat = 'ecoute'; w.pas = {}; w.meilleur = -100; w.depuis = Date.now();
this.wizRender();
if (this._wizTick) clearInterval(this._wizTick);
this._wizTick = setInterval(() => this.wizMajEcoute(), 250);
putJSONSync('/beginFrequencyScan', {}, (err) => {
if (err) { ui.serviceError(err); this.wizFermer(); return; }
});
}
wizMajEcoute() {
const w = this.wiz, C = this.wizConst;
if (!w || w.etat !== 'ecoute') return;
const ecoule = Date.now() - w.depuis;
const el = get('wizNiveau');
if (el) {
const entendu = w.meilleur > C.seuil;
el.textContent = entendu
? tr('RADIO_WIZ_HEARD').replace('{rssi}', w.meilleur)
: tr('RADIO_WIZ_LISTENING');
el.classList.toggle('heard', entendu);
}
const c = get('wizChrono');
if (c) c.textContent = Math.floor(ecoule / 1000) + ' s';
const b = get('wizBarre');
if (b && b.firstElementChild)
b.firstElementChild.style.width = Math.min(100, ecoule / C.silenceMs * 100).toFixed(1) + '%';
this.wizVerifierDelai();
}
wizVerifierDelai() {
const w = this.wiz;
if (!w || w.etat !== 'ecoute') return;
if (Date.now() - w.depuis > this.wizConst.silenceMs) this.wizSilence();
}
wizOnScan(scan) {
const w = this.wiz;
if (!w || w.etat !== 'ecoute') return;
const f = parseFloat(scan.testFreq), r = parseInt(scan.testRSSI, 10);
if (!isFinite(f) || !isFinite(r)) return;
const k = Math.round(f * 100);
w.pas[k] = Math.max(w.pas[k] === undefined ? -100 : w.pas[k], r);
if (r > w.meilleur) w.meilleur = r;
const m = this.wizFenetre();
if (m) this.wizMesureFinie(m);
else this.wizVerifierDelai();
}
wizFenetre() {
const w = this.wiz, C = this.wizConst;
const cles = Object.keys(w.pas).map(Number).sort((a, b) => a - b);
const plages = [];
let cur = null;
for (const k of cles) {
if (w.pas[k] > C.seuil) {
if (cur && k - cur.fin <= 2) cur.fin = k;
else { if (cur) plages.push(cur); cur = { debut: k, fin: k }; }
}
}
if (cur) plages.push(cur);
if (!plages.length) return null;
const pic = (p) => Math.max(...cles.filter(k => k >= p.debut && k <= p.fin).map(k => w.pas[k]));
plages.sort((a, b) => pic(b) - pic(a));
const p = plages[0];
const avant = w.pas[p.debut - 1], apres = w.pas[p.fin + 1];
if (avant === undefined || apres === undefined) return null;
if (avant > C.seuil || apres > C.seuil) return null;
return { freq: (p.debut + p.fin) / 200, rssi: pic(p) };
}
wizMesureFinie(m) {
const w = this.wiz;
this.wizArreterBalayage();
w.mesures.push(m);
w.etat = 'mesuree';
this.wizRender();
}
wizSilence() {
this.wizArreterBalayage();
this.wiz.etat = 'silence';
this.wizRender();
}
wizRetour() {
if (!this.wiz) return;
this.wiz.etat = this.wiz.mesures.length ? 'mesuree' : 'intro';
this.wizRender();
}
wizTerminer() {
const w = this.wiz;
if (!w.mesures.length) { this.wizFermer(); return; }
const r = this.wizCalcul();
w.etat = (r.horsPortee || this.wizSuspecte() !== null) ? 'aberrante' : 'resultat';
this.wizRender();
}
wizSuspecte() {
const w = this.wiz;
if (!w || w.mesures.length < 3) return null;
const etendue = (l) => (Math.max(...l) - Math.min(...l)) * 1000;
const fs = w.mesures.map(m => m.freq);
const avec = etendue(fs);
if (avec <= 100) return null;
const i = this.wizAberrante();
const sans = etendue(fs.filter((_, k) => k !== i));
return (sans < 0.3 * avec) ? i : null;
}
wizAberrante() {
const fs = this.wiz.mesures.map(m => m.freq);
const med = [...fs].sort((a, b) => a - b)[Math.floor(fs.length / 2)];
let pire = 0;
fs.forEach((f, i) => { if (Math.abs(f - med) > Math.abs(fs[pire] - med)) pire = i; });
return pire;
}
wizExclure(i) {
this.wiz.mesures.splice(i, 1);
this.wizTerminer();
}
wizCalcul() {
const C = this.wizConst, fs = this.wiz.mesures.map(m => m.freq);
if (!fs.length) return null;
const min = Math.min(...fs), max = Math.max(...fs);
const etendueKHz = (max - min) * 1000;
const voulue = Math.max(C.bwUsine, etendueKHz + 2 * C.pasKHz);
return {
centre: (min + max) / 2,
bande: Math.min(Math.max(voulue, C.bwMin), C.bwMax),
min, max, etendueKHz,
horsPortee: voulue > C.bwMax
};
}
wizAppliquer() {
const r = this.wizCalcul();
if (!r) { this.wizFermer(); return; }
const put = (id, v, fn) => {
const el = get(id);
if (!el) return;
el.value = v;
if (typeof this[fn] === 'function') this[fn](el);
};
put('slidFrequency', Math.round(r.centre * 1000), 'frequencyChanged');
put('slidRxBandwidth', Math.round(r.bande * 100), 'rxBandwidthChanged');
this.updateRadioGraph();
const st = get('divRadioEnableStatus');
if (st) st.textContent = tr('RADIO_SAVE_REQUIRED');
this.wizFermer();
this.saveRadio();
}
wizMajVerrou() {
const div = get('divRadioWizard');
if (!div) return;
const w = this.wiz;
if (w && w.etat === 'ecoute')
setOverlayLock(div, 'confirm', { titleKey: 'PROMPT_FREQ_SCAN_TITLE', msgKey: 'PROMPT_FREQ_SCAN_MSG' });
else if (w && w.mesures.length)
setOverlayLock(div, 'confirm', { titleKey: 'PROMPT_WIZ_ABANDON_TITLE', msgKey: 'PROMPT_WIZ_ABANDON_MSG' });
else
clearOverlayLock(div);
}
wizArreterBalayage() {
this.wizStopping = true;
if (this._wizTick) { clearInterval(this._wizTick); this._wizTick = null; }
putJSONSync('/endFrequencyScan', {}, (err) => {
if (err) logger.error('Failed to end frequency scan:', err);
});
}
wizAbandon() {
if (this.wiz && this.wiz.etat === 'ecoute') this.wizArreterBalayage();
if (this._wizTick) { clearInterval(this._wizTick); this._wizTick = null; }
this.wiz = null;
}
wizFermer() {
const div = get('divRadioWizard');
this.wizAbandon();
if (div) closeOverlay(div);
}
get radioRecapOpen() { return this._recapOpen === true; }
toggleRadioRecap() {
this._recapOpen = !this.radioRecapOpen;
this.updateRadioRecap();
}
updateRadioRecap() {
const box = get('radioRecap');
if (!box) return;
const val = (id, div) => {
const el = get(id);
return el ? parseFloat(el.value) / div : NaN;
};
const tx = () => {
const el = get('slidTxPower');
if (!el) return NaN;
const v = this.txPowerLevels[parseInt(el.value, 10)];
return v === undefined ? NaN : v;
};
const d = this.radioDefaults;
const lignes = [
{ cle: 'RADIO_BASE_FREQUENCY', champ: 'frequency', v: val('slidFrequency', 1000), u: 'MHz', dec: 3, ref: d.frequency },
{ cle: 'RADIO_RX_BANDWIDTH', champ: 'rxBandwidth', v: val('slidRxBandwidth', 100), u: 'kHz', dec: 2, ref: d.rxBandwidth },
{ cle: 'RADIO_TX_POWER', champ: 'txPower', v: tx(), u: tr('UNIT_DBM'), dec: 0, ref: d.txPower }
];
const ecarte = (l) => isFinite(l.v) && Math.abs(l.v - l.ref) > Math.pow(10, -l.dec) / 2;
const montrees = lignes;
const usine = !lignes.some(ecarte);
const applique = this.radioApplied;
const enAttente = (l) => {
if (!applique || !l.champ || !isFinite(l.v)) return false;
const a = applique[l.champ];
return typeof a === 'number' && Math.abs(l.v - a) > Math.pow(10, -l.dec) / 2;
};
const rienEnAttente = !lignes.some(enAttente);
if (!rienEnAttente && this._recapPending !== true) this._recapOpen = true;
this._recapPending = !rienEnAttente;
const ouvert = this.radioRecapOpen;
const nbEcartes = lignes.filter(ecarte).length;
const resume = !rienEnAttente
? { cle: 'RADIO_RECAP_SUM_PENDING', classe: 'pending', n: null }
: usine
? { cle: 'RADIO_RECAP_SUM_STOCK', classe: 'stock', n: null }
: { cle: 'RADIO_RECAP_SUM_CHANGED', classe: 'changed', n: nbEcartes };
box.classList.toggle('expanded', ouvert);
box.innerHTML = `
        <button type="button" class="buttonUpdate unibuttonPad" aria-expanded="${ouvert}"
                aria-controls="radioRecapBody" onclick="somfy.toggleRadioRecap();">
            <div class="uniLeft">
                <div class="devButtonUpdate">
                    <div>${tr('RADIO_RECAP_TITLE')}</div>
                    <div class="uniStatus">${tr('RADIO_RECAP_DESC')}</div>
                    <div class="uniStatus radio-recap-sum ${resume.classe}">${
tr(resume.cle).replace('{n}', resume.n)}</div>
                </div>
            </div>
            <div class="uniRight">
                <svg class="btnArrowRight"><use href="#svg-arrowDown"></use></svg>
            </div>
        </button>
        <div class="radio-recap-body" id="radioRecapBody">
            <!-- La phrase rassurante vit ICI et non dans l'en-tete : repliee, elle allongeait a
            146 caracteres une ligne dont la mediane du projet est de 50, et elle repondait a une
            question que personne ne se pose tant que le bloc est ferme. Ouvert, au contraire, on
            a les trois valeurs sous les yeux et on se demande s'il faut y toucher. -->
            <div class="uniStatus radio-recap-note">${tr('RADIO_RECAP_NOTE')}</div>
            <div class="radio-recap-legende">
                <span class="lg-defaut">${tr('RADIO_RECAP_LG_DEFAULT')}</span>
                <span class="lg-modifie">${tr('RADIO_RECAP_LG_CHANGED')}</span>
                <span class="lg-attente">${tr('RADIO_RECAP_LG_PENDING')}</span>
            </div>
        <div class="radio-recap-head">
            <span>${tr('RADIO_RECAP_COL_SETTING')}</span>
            <span>${tr('RADIO_RECAP_CURRENT')}</span>
        </div>
        <div class="radio-recap-rows">
        ${montrees.map(l => `
            <div class="radio-recap-row${ecarte(l) ? ' changed' : ''}${enAttente(l) ? ' pending' : ''}">
                <div class="radio-recap-main">
                    <span class="radio-recap-label">${tr(l.cle)}</span>
                    <span class="radio-recap-ref">${tr('RADIO_RECAP_DEFAULT')
.replace('{v}', l.ref.toFixed(l.dec) + ' ' + l.u)}</span>
                </div>
                <span class="radio-recap-value">${isFinite(l.v) ? l.v.toFixed(l.dec) : '---'} ${l.u}</span>
                ${enAttente(l) ? `<div class="radio-recap-attente">
                    <svg><use href="#svg-warning"></use></svg>
                    <span>${tr('RADIO_RECAP_PENDING_ROW')
.replace('{v}', applique[l.champ].toFixed(l.dec) + ' ' + l.u)}</span>
                </div>` : ''}
            </div>`).join('')}
        </div>
        <button type="button" class="buttonUpdate radio-help-link" onclick="somfy.radioAideOverlay();">
            <svg><use href="#icon-question"></use></svg>
            <span>${tr('RADIO_HELP_LINK')}</span>
        </button>
        </div>`;
this.renderRadioTest();
}
radioAideOverlay() {
if (get('divRadioAideOverlay')) return;
const lignes = [
['RADIO_BASE_FREQUENCY', 'RADIO_HELP_BASE_FREQUENCY'],
['RADIO_RX_BANDWIDTH', 'RADIO_HELP_RX_BANDWIDTH'],
['RADIO_TX_POWER', 'RADIO_HELP_TX_POWER']
];
const div = document.createElement('div');
div.id = 'divRadioAideOverlay';
div.className = 'modal-overlay';
div.innerHTML = `
        <div class="message-content">
        ${modalHeader('RADIO_HELP_TITLE', 'svg-info')}
        <div class="overlay-scroll-content">
        ${lignes.map(([libelle, aide]) => `
            <div class="radio-aide-item">
                <span class="radio-aide-titre">${tr(libelle)}</span>
                <span class="radio-aide-texte">${tr(aide)}</span>
            </div>`).join('')}
        </div>
        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnRadioAideOk" type="button">${tr('BT_OK')}</button>
        </div>
        </div>
        </div>`;
get('divContainer').appendChild(div);
shOverlay(div);
div.querySelector('#btnRadioAideOk').onclick = () => closeOverlay(div);
}
get radioTestConst() { return { fenetreMs: 15000 }; }
radioTestDemarrer() {
if (!this.radioPrete()) return;
this.rtest = { etat: 'ecoute', depuis: Date.now(), frame: null };
if (this._rtestTick) clearInterval(this._rtestTick);
this._rtestTick = setInterval(() => {
if (!this.rtest || this.rtest.etat !== 'ecoute') return;
if (Date.now() - this.rtest.depuis >= this.radioTestConst.fenetreMs) {
this.rtest.etat = 'rien';
clearInterval(this._rtestTick); this._rtestTick = null;
this.renderRadioTest();
return;
}
this.majRadioTestProgress();
}, 250);
this.renderRadioTest();
}
majRadioTestProgress() {
const t = this.rtest;
if (!t || t.etat !== 'ecoute') return;
const box = get('divRadioTest');
if (!box) return;
const bar = box.querySelector('.progress-bar'), val = box.querySelector('.progress-bar-value');
if (!bar || !val) { this.renderRadioTest(); return; }
const reste = Math.max(0, this.radioTestConst.fenetreMs - (Date.now() - t.depuis));
bar.style.setProperty('--progress', (100 - reste / this.radioTestConst.fenetreMs * 100).toFixed(1) + '%');
val.textContent = Math.ceil(reste / 1000) + ' s';
}
radioTestAnnuler() {
if (this._rtestTick) { clearInterval(this._rtestTick); this._rtestTick = null; }
this.rtest = null;
this.renderRadioTest();
}
radioTestOnFrame(frame) {
if (!this.rtest || this.rtest.etat !== 'ecoute') return;
if (frame && frame.valid === false) return;
this.rtest.frame = frame;
this.rtest.etat = 'ok';
if (this._rtestTick) { clearInterval(this._rtestTick); this._rtestTick = null; }
this.renderRadioTest();
}
renderRadioTest() {
const box = get('divRadioTest');
if (!box) return;
const t = this.rtest || { etat: 'repos' };
const ico = (id) => `<div class="uniblocSvg-S"><svg><use href="#svg-${id}"></use></svg></div>`;
const txt = (titre, ...lignes) =>
`<div class="devButtonUpdate"><div class="radio-test-title">${titre}</div>`
+ lignes.filter(Boolean).map(l => `<div class="uniStatus">${l}</div>`).join('')
+ `</div>`;
const gauche = (corps) => `<div class="uniLeft">${corps}</div>`;
const fleche = `<div class="uniRight"><svg class="btnArrowRight"><use href="#svg-arrowRight"></use></svg></div>`;
const cliquable = (action, corps) =>
`<button class="buttonUpdate" type="button" onclick="somfy.${action}">${corps}${fleche}</button>`;
const raccourci = `<div class="uniLeft radio-test-lien-ligne">
            <div class="uniblocSvg-S" aria-hidden="true"></div>
            <button type="button" class="buttonUpdate radio-test-lien" onclick="somfy.radioWizard();">${
tr('RADIO_WIZ_DIRECT')}</button>
        </div>`;
const btn = (key, action, second) =>
`<button type="button" class="radio-test-btn"${second ? ' line' : ''} onclick="somfy.${action}">${tr(key)}</button>`;
let classe = 'radio-test uniRow', corps;
switch (t.etat) {
case 'ecoute': {
const reste = Math.max(0, this.radioTestConst.fenetreMs - (Date.now() - t.depuis));
const pc = 100 - (reste / this.radioTestConst.fenetreMs * 100);
classe += ' stacked';
corps = gauche(ico('signal') + txt(tr('RADIO_TEST_WAITING'), tr('RADIO_TEST_WAITING_DESC')))
+ `<div class="radio-test-progress">`
+ `<div class="progress-bar" style="--progress:${pc.toFixed(1)}%"><div class="progress-bar-fill"></div></div>`
+ `<span class="progress-bar-value">${Math.ceil(reste / 1000)} s</span>`
+ btn('BT_CANCEL', 'radioTestAnnuler();', true)
+ `</div>`;
break;
}
case 'ok': {
const f = t.frame || {};
classe += ' feedback-card ok stacked';
const niv = this.rssiLevel(typeof f.rssi === 'number' ? f.rssi : -128);
const rssi = `<span class="radio-test-rssi sig-${niv}">${
f.rssi === undefined ? '?' : f.rssi} ${tr('UNIT_DBM')}</span>`;
corps = cliquable('radioTestDemarrer();',
gauche(ico('succes') + txt(tr('RADIO_TEST_OK_TITLE'),
tr('RADIO_TEST_OK_DESC').replace('{command}', escHtml(f.command || '?'))
.replace('{rssi}', rssi),
tr('RADIO_TEST_OK_HINT')))) + raccourci;
break;
}
case 'rien':
classe += ' stacked none';
corps = gauche(ico('warning') + txt(tr('RADIO_TEST_NONE_TITLE'),
tr('RADIO_TEST_NONE_DESC'), tr('RADIO_TEST_WIZ_DESC')))
+ `<div class="radio-test-actions">`
+ btn('BT_RETRY', 'radioTestDemarrer();', true)
+ btn('BT_RADIO_TEST', 'radioWizard();', false)
+ `</div>`;
break;
default:
classe += ' feedback-card stacked';
corps = cliquable('radioTestDemarrer();',
gauche(ico('linkRemot') + txt(tr('RADIO_TEST_TITLE'), tr('RADIO_TEST_DESC')))) + raccourci;
}
box.className = classe;
box.innerHTML = corps;
}
updateRadioGraph() {
const g = (id) => document.getElementById(id);
const freqCentral = (parseFloat(g('slidFrequency')?.value) || 433000) / 1000;
const bandeKHz = (parseFloat(g('slidRxBandwidth')?.value) || 5803) / 100;
const demi = (bandeKHz / 2) / 1000;
const fMin = freqCentral - demi, fMax = freqCentral + demi;
const BAS = 433.000, HAUT = 434.399;
const X = (f) => 20 + Math.min(Math.max((f - BAS) / (HAUT - BAS), 0), 1) * 760;
const zone = g('tunerZone');
if (zone) {
const x0 = X(fMin), x1 = X(fMax);
zone.setAttribute('x', x0.toFixed(2));
zone.setAttribute('width', Math.max(x1 - x0, 2).toFixed(2));
}
const centre = g('tunerCenter');
if (centre) {
const xc = X(freqCentral).toFixed(2);
centre.setAttribute('x1', xc); centre.setAttribute('x2', xc);
}
const mhz = (v) => v.toFixed(3) + ' ' + tr('UNIT_MHZ');
if (g('graphFreqMin')) g('graphFreqMin').textContent = mhz(fMin);
if (g('graphFreqCentral')) g('graphFreqCentral').textContent = mhz(freqCentral);
if (g('graphFreqMax')) g('graphFreqMax').textContent = mhz(fMax);
if (g('tunerScaleMid')) g('tunerScaleMid').textContent =
'↔ ' + bandeKHz.toFixed(2) + ' ' + tr('UNIT_KHZ');
const title = g('radioGraphTitle');
if (title) {
title.textContent = tr('RADIO_TUNER_ALT')
.replace('{min}', fMin.toFixed(3))
.replace('{max}', fMax.toFixed(3))
.replace('{bande}', bandeKHz.toFixed(2));
}
this.updateRadioRecap();
}
rxBandwidthChanged(el) {
get('inputRxBandwidth').value = (el.value / 100).fmt('#,##0.00');
this.updateRadioGraph();
}
frequencyChanged(el) {
get('inputFrequency').value = (el.value / 1000).fmt('#,##0.000');
this.updateRadioGraph();
}
txPowerChanged(el) {
const lvls = this.txPowerLevels;
get('inputTxPower').value = lvls[el.value] !== undefined ? lvls[el.value] : '';
this.updateRadioGraph();
}
stepSizeChanged(el) {
const span = get('spanStepSize');
if (span) span.innerText = parseInt(el.value, 10).fmt('#,##0');
}
frequencyInputChanged(el) {
let val = parseFloat(el.value);
let minAllowed = parseFloat(el.getAttribute('min'));
let maxAllowed = parseFloat(el.getAttribute('max'));
if (!isNaN(val) && val >= minAllowed && val <= maxAllowed) {
get('slidFrequency').value = Math.round(val * 1000);
this.updateRadioGraph();
} else {
this.showInputError(el);
this.frequencyChanged(get('slidFrequency'));
}
}
rxBandwidthInputChanged(el) {
let val = parseFloat(el.value);
let minAllowed = parseFloat(el.getAttribute('min'));
let maxAllowed = parseFloat(el.getAttribute('max'));
if (!isNaN(val) && val >= minAllowed && val <= maxAllowed) {
get('slidRxBandwidth').value = Math.round(val * 100);
this.updateRadioGraph();
} else {
this.showInputError(el);
this.rxBandwidthChanged(get('slidRxBandwidth'));
}
}
txPowerInputChanged(el) {
const ndx = this.txPowerLevels.indexOf(parseFloat(el.value));
if (ndx !== -1) {
get('slidTxPower').value = ndx;
this.updateRadioGraph();
} else {
this.showInputError(el);
this.txPowerChanged(get('slidTxPower'));
}
}
showInputError(el) {
el.classList.add('input-error');
setTimeout(() => {
el.classList.remove('input-error');
}, 500);
}
procRoomAdded(room) {
let r = _rooms.find(x => x.roomId === room.roomId);
if (typeof r === 'undefined' || !r) {
_rooms.push(room);
_rooms.sort((a, b) => { return a.sortOrder - b.sortOrder });
this.setRoomsList(_rooms);
this.checkEmptyState();
}
}
procRoomRemoved(room) {
if (room.roomId === 0) return;
let r = _rooms.find(x => x.roomId === room.roomId);
if (typeof r !== 'undefined' && r.roomId === room.roomId) {
_rooms = _rooms.filter(x => x.roomId !== room.roomId);
_rooms.sort((a, b) => { return a.sortOrder - b.sortOrder });
this.setRoomsList(_rooms);
this.checkEmptyState();
let rs = get('divRoomSelector');
let ss = get('divShadeControls');
let gs = get('divGroupControls');
let ctls = ss.querySelectorAll('.somfyShadeCtl');
for (let i = 0; i < ctls.length; i++) {
let x = ctls[i];
if (parseInt(x.getAttribute('data-roomid'), 10) === room.roomId)
x.setAttribute('data-roomid', '0');
}
ctls = gs.querySelectorAll('.somfyGroupCtl');
for (let i = 0; i < ctls.length; i++) {
let x = ctls[i];
if (parseInt(x.getAttribute('data-roomid'), 10) === room.roomId)
x.setAttribute('data-roomid', '0');
}
if (parseInt(rs.getAttribute('data-roomid'), 10) === room.roomId) this.selectRoom(0);
}
}
selectRoom(roomId) {
document.querySelectorAll('.room-pill').forEach(pill => {
const pId = parseInt(pill.getAttribute('data-roomid'), 10);
pill.classList.toggle('active', pId === roomId);
});
document.querySelectorAll('.somfyShadeCtl').forEach(x => {
const rId = parseInt(x.getAttribute('data-roomid'), 10);
x.style.display = (roomId === 0 || rId === roomId) ? '' : 'none';
});
document.querySelectorAll('.somfyGroupCtl').forEach(x => {
const rId = parseInt(x.getAttribute('data-roomid'), 10);
x.style.display = (roomId === 0 || rId === roomId) ? '' : 'none';
});
const activePill = document.querySelector(`.room-pill[data-roomid="${roomId}"]`);
if (activePill) {
activePill.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
}
this.checkEmptyState();
}
updateRoomCounts() {
const shades = this.shades || [];
const groups = this.groups || [];
document.querySelectorAll('.room-pill').forEach(pill => {
const roomId = parseInt(pill.getAttribute('data-roomid'), 10);
const countEl = pill.querySelector('.room-count');
if (!countEl) return;
const count = (roomId === 0)
? shades.length + groups.length
: shades.filter(s => s.roomId === roomId).length + groups.filter(g => g.roomId === roomId).length;
countEl.innerText = count;
});
}
setRoomsList(rooms) {
let divCfg = '';
const homeName = tr('HOME');
const slider = get('divRoomSelector');
let divPills = `<div class="room-pill active" data-roomid="0" onclick="somfy.selectRoom(0)"><span>${homeName}</span><span class="room-count">0</span></div>`;
let divOpts = `<option value="0">${homeName}</option>`;
_rooms = [{ roomId: 0, name: homeName }];
rooms.sort((a, b) => a.sortOrder - b.sortOrder);
rooms.forEach(room => {
divPills += `<div class="room-pill animScale" data-roomid="${room.roomId}" onclick="somfy.selectRoom(${room.roomId})"><span>${escHtml(room.name)}</span><span class="room-count">0</span></div>`;
divCfg += `<div class="somfyRoom room-draggable" data-roomid="${room.roomId}" onclick="somfy.openEditRoom(${room.roomId});">
            <div class="drag-handle" onclick="event.stopPropagation();"><svg class="icon-svg"><use href=#svg-drag></use></svg></div>
            <div class="shade-icon-wrapper"><svg><use href="#svg-emptyRoom"></use></svg></div>
            <div class="room-name"><span class="name-text">${escHtml(room.name)}</span></div>
            <div class="divEditDelete-svg" onclick="event.stopPropagation(); somfy.deleteRoom(${room.roomId});"><svg class="icon-svg" style="color: var(--color-danger);"><use href=#svg-trash></use></svg></div>
            </div>`;
divOpts += `<option value="${room.roomId}">${escHtml(room.name)}</option>`;
_rooms.push(room);
});
slider.innerHTML = divPills;
slider.style.display = 'flex';
const navContainer = document.querySelector('.room-nav-container');
if(navContainer) navContainer.style.display = rooms.length === 0 ? 'none' : 'flex';
get('divRoomList').innerHTML = divCfg;
get('selShadeRoom').innerHTML = divOpts;
get('selGroupRoom').innerHTML = divOpts;
this.checkEmptyState();
this.updateRoomCounts();
this.setListDraggable(get('divRoomList'), '.room-draggable', (list) => {
let order = Array.from(list.querySelectorAll('.room-draggable')).map(item =>
parseInt(item.getAttribute('data-roomid'), 10)
);
putJSONSync('/roomSortOrder', order, (err) => {
if (err) ui.serviceError(err);
else this.updateRoomsList();
});
});
this.initRoomScroll(slider);
}
initRoomScroll(c) {
if (!c) return;
const parent = c.parentElement;
if (!c._scrollInit) {
c._scrollInit = true;
c._updateRoomMasks = () => {
if (!parent) return;
const maxScroll = c.scrollWidth - c.clientWidth;
if (maxScroll <= 5) {
parent.classList.remove('mask-right', 'mask-both', 'mask-left');
parent.classList.add('mask-none');
return;
}
const currentScroll = c.scrollLeft;
const isAtStart = currentScroll <= 5;
const isAtEnd = currentScroll >= maxScroll - 5;
parent.classList.remove('mask-none', 'mask-right', 'mask-both', 'mask-left');
parent.classList.add(isAtStart ? 'mask-right' : (isAtEnd ? 'mask-left' : 'mask-both'));
};
let scrollTicking = false;
c.addEventListener('scroll', () => {
if (scrollTicking) return;
scrollTicking = true;
requestAnimationFrame(() => { c._updateRoomMasks(); scrollTicking = false; });
}, { passive: true });
window.addEventListener('resize', () => c._updateRoomMasks());
document.addEventListener('visibilitychange', () => {
if (document.visibilityState === 'visible') c._updateRoomMasks();
});
c.addEventListener('wheel', (e) => {
if (!e.deltaY) return;
if (c.scrollWidth - c.clientWidth <= 5) return;
e.preventDefault();
c.scrollLeft += e.deltaY * 2.5;
}, { passive: false });
let isDown = false, startX, scrollLeft;
c.onmousedown = (e) => {
isDown = true;
c.style.cursor = 'grabbing';
startX = e.pageX - c.offsetLeft;
scrollLeft = c.scrollLeft;
};
const stop = () => {
isDown = false;
c.style.cursor = 'grab';
};
c.onmouseleave = c.onmouseup = stop;
c.onmousemove = (e) => {
if (!isDown) return;
e.preventDefault();
c.scrollLeft = scrollLeft - (e.pageX - c.offsetLeft - startX) * 1.5;
};
}
this._scheduleRoomMaskUpdate();
}
_scheduleRoomMaskUpdate() {
const c = get('divRoomSelector');
if (!c || !c._updateRoomMasks) return;
if (document.visibilityState === 'hidden') {
setTimeout(() => c._updateRoomMasks(), 100);
} else {
requestAnimationFrame(() => requestAnimationFrame(() => c._updateRoomMasks()));
}
}
showEditRoom(bShow) {
let el = get('divLinkRepeater');
if (el) el.remove();
el = get('divPairing');
if (el) el.remove();
el = get('divRollingCode');
if (el) el.remove();
el = get('divRemotesOverlay');
if (el) el.remove();
el = get('divRoomListContainer');
if (el) el.style.display = bShow ? 'none' : '';
if (bShow) {
this.showEditGroup(false);
this.showEditShade(false);
}
}
openEditRoom(roomId) {
this._roomInlineReturnContext = null;
confirmDiscardChanges(() => this._openEditRoom(roomId));
}
openAddRoomInline(context) {
this._roomInlineReturnContext = context;
this._openEditRoom(undefined);
}
_openEditRoom(roomId) {
if (typeof roomId === 'undefined') {
if (_rooms.length >= 15) {
ui.errorMessage(get('divSomfySettings'), tr('ERR_ROOM_LIMIT_REACHED'));
return;
}
getJSONSync('/getNextRoom', (err, room) => {
if (err) ui.serviceError(err);
else {
room.name = '';
this.RoomOverlay('*', room);
}
});
}
else {
getJSONSync(`/room?roomId=${roomId}`, (err, room) => {
if (err) ui.serviceError(err);
else {
this.RoomOverlay(roomId, room);
}
});
}
}
RoomOverlay(roomId, roomData) {
if (get('divEditRoomOverlay')) return;
const isEdit = roomId && roomId !== '*';
const titleKey = isEdit ? 'ROOM_TITLE_EDIT' : 'ROOM_TITLE_ADD';
const descKey = isEdit ? 'ROOM_TITLE_EDIT_DESC' : 'ROOM_TITLE_ADD_DESC';
const buttonText = isEdit ? tr('BT_SAVE') : tr('BT_CREATE');
const iconHref = isEdit ? '#svg-save' : '#svg-add';
let div = document.createElement('div');
div.id = 'divEditRoomOverlay';
div.className = 'modal-overlay';
div.setAttribute('data-roomid', roomId);
const presetsHTML = Array.from({ length: 8 }, (_, i) =>
`<span class="preset-badge">${tr(`ROOM_PRESET_${i}`)}</span>`
).join('');
div.innerHTML = `
        <div class="message-content room-content">
        ${modalHeader(titleKey, 'svg-emptyRoom', {
subtitle: descKey,
rightContent: `<div class="somfyMaxId"><span id="spanRoomId">${roomId}</span>/<span id="spanMaxRooms">${roomData.maxRooms || 14}</span></div>`
})}
        <div class="overlay-scroll-content">
        <div class="uniblocCol dirty-target">
        <label class="label" for="fldRoomName">${tr('NAME')}</label>
        <input id="fldRoomName" class="inputAndSelect" name="roomName" data-bind="name" type="text" length=20 placeholder="${tr('ROOM_NAME_PHL')}">
        </div>
        <div class="room-presets">
        ${presetsHTML}
        </div>
        </div>
        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnRoomGoBack" line type="button">${tr('BT_CLOSE')}</button>
        <button id="btnSaveRoom" type="button">
        <svg><use id="useSaveRoomIcon" href="${iconHref}"></use></svg>
        <span id="btnSaveRoomText">${buttonText}</span>
        </button>
        </div>
        </div>
        </div>`;
shOverlay(div);
ui.toElement(div, roomData);
watchDirty(div);
div.onclick = (e) => {
const target = e.target;
if (target.classList.contains('preset-badge')) {
const input = div.querySelector('#fldRoomName');
input.value = target.innerText;
input.dispatchEvent(new Event('input', { bubbles: true }));
return;
}
if (target.id === 'btnRoomGoBack' || target.closest('#btnRoomGoBack')) {
confirmDiscardChanges(() => {
this._roomInlineReturnContext = null;
closeOverlay(div);
});
return;
}
if (target.id === 'btnSaveRoom' || target.closest('#btnSaveRoom')) {
this.saveRoom(div);
return;
}
};
}
saveRoom(overlayEl) {
if (!overlayEl) overlayEl = get('divEditRoomOverlay');
if (!overlayEl) return;
let roomId = parseInt(overlayEl.querySelector('#spanRoomId').innerText, 10);
let obj = ui.fromElement(overlayEl);
let valid = true;
if (valid && (typeof obj.name !== 'string' || obj.name === '' || obj.name.length > 20)) {
ui.errorMessage(get('divSomfySettings'), tr('ERR_ROOM_NAME_INVALID'));
valid = false;
}
if (valid) {
if (isNaN(roomId) || roomId === 0) {
putJSONSync('/addRoom', obj, (err, room) => {
if (err) {
ui.serviceError(err);
logger.error('Failed to add room:', err);
}
else {
logger.debug('Room added:', room);
ui.successMessage(tr('MSG_ADD_SUCCESS'));
clearDirty(overlayEl);
const returnCtx = this._roomInlineReturnContext;
this._roomInlineReturnContext = null;
this.updateRoomsList(() => {
if (!returnCtx) return;
const sel = get(returnCtx === 'group' ? 'selGroupRoom' : 'selShadeRoom');
if (!sel) return;
sel.value = room.roomId;
sel.dispatchEvent(new Event('change', { bubbles: true }));
});
closeOverlay(overlayEl);
}
});
}
else {
obj.roomId = roomId;
putJSONSync('/saveRoom', obj, (err, room) => {
if (err) {
ui.serviceError(err);
logger.error('Failed to save room:', err);
} else {
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
logger.debug('Room saved:', room);
clearDirty(overlayEl);
this.updateRoomsList();
closeOverlay(overlayEl);
}
});
}
}
}
deleteRoom(roomId) {
let valid = true;
if (isNaN(roomId) || roomId >= 255 || roomId <= 0) {
ui.errorMessage(tr('ERR_ROOM_ID_REQUIRED'));
valid = false;
}
if (valid) {
getJSONSync(`/room?roomId=${roomId}`, (err, room) => {
if (err) ui.serviceError(err);
else {
let prompt = ui.promptMessage(tr('PROMPT_DELETE_ROOM'), () => {
ui.clearErrors();
putJSONSync('/deleteRoom', { roomId: roomId }, (err, room) => {
prompt.remove();
if (err) ui.serviceError(err);
else
this.updateRoomsList();
});
});
prompt.querySelector('.sub-message').innerHTML = `<p>${tr("PROMPT_DELETE_ROOM_WARNING")}</p>`;
}
});
}
}
updateRoomsList(cb) {
getJSONSync('/rooms', (err, shades) => {
if (err) {
logger.error('Failed to load rooms:', err);
ui.serviceError(err);
}
else {
this.setRoomsList(shades);
if (typeof cb === 'function') cb();
}
});
}
setShadesList(shades) {
this.shades = shades;
let divCfg = '';
let divCtl = '';
shades.sort((a, b) => { return a.sortOrder - b.sortOrder });
logger.debug('Shade list updated,', shades.length, 'shades');
let roomId = document.querySelector('.room-pill.active') ? parseInt(document.querySelector('.room-pill.active').getAttribute('data-roomid'), 10) : 0;
for (let i = 0; i < shades.length; i++) {
let shade = shades[i];
let room = _rooms.find(x => x.roomId === shade.roomId) || { roomId: 0, name: '' };
let isLightOn = (shade.flags & 0x08);
let isSunOn = (shade.flags & 0x01);
let st = this.shadeTypes.find(x => x.type === shade.shadeType) || { type: shade.shadeType, ico: 'svg-window-shade', indic: 'svg-indicRoller' };
const isSimpleShade = this.noMyShadeTypes.includes(shade.shadeType);
const shadeHasTilt = shade.tiltType > 0;
const buttonsPage = isSimpleShade ? `
            <div class="carousel-page">
            <div class="shadectl-buttons groupctl-buttons" data-shadeType="${shade.shadeType}">
            <div class="button-outline cmd-button btn-somfy-svg animScale" data-cmd="toggle" data-shadeid="${shade.shadeId}"><svg><use href="#svg-toggle"></use></svg></div>
            </div>
            </div>` : `
            <div class="carousel-page">
            <div class="shadectl-buttons groupctl-buttons" data-shadeType="${shade.shadeType}">
            <div class="button-outline cmd-button btn-somfy-svg animScale" data-cmd="up" data-shadeid="${shade.shadeId}"><svg><use href="#svg-up"></use></svg></div>
            <div class="button-outline cmd-button btn-somfy-svg animScale" data-cmd="my" data-shadeid="${shade.shadeId}"><svg><use href="#svg-my"></use></svg></div>
            <div class="button-outline cmd-button btn-somfy-svg animScale" data-cmd="down" data-shadeid="${shade.shadeId}"><svg><use href="#svg-down"></use></svg></div>
            </div>
            </div>`;
const positionPage = !isSimpleShade ? `
            <div class="carousel-page">
            <div class="slider-wrapper">
            <div class="slider-progress" style="width:${shade.position}%;"><div class="slider-thumb-line"></div></div>
            <input type="range" class="md3-range-input carousel-slider-pos" min="0" max="100" step="1" value="${shade.position}" data-realpos="${shade.position}" oninput="syncSliderProgress(this);" onpointerdown="sliderDragStart(this);" onkeydown="sliderDragStart(this);" onkeyup="sliderDragEnd(this);" onchange="somfy.commitSliderTarget(this, ${shade.shadeId}, false);">
            </div>
            <div class="button-outline cmd-button btn-somfy-svg animScale btn-page-my" data-cmd="my" data-shadeid="${shade.shadeId}"><svg><use href="#svg-my"></use></svg></div>
            </div>` : '';
const tiltPage = (!isSimpleShade && shadeHasTilt) ? `
            <div class="carousel-page">

            <div class="slider-wrapper tilt-slider">
            <div class="slider-progress" style="width:${shade.tiltPosition}%;">
            <div class="slider-thumb-line"></div>
            </div>
            <input type="range" class="md3-range-input carousel-slider-tilt" min="0" max="100" step="1" value="${shade.tiltPosition}" data-realpos="${shade.tiltPosition}" oninput="syncSliderProgress(this);" onpointerdown="sliderDragStart(this);" onkeydown="sliderDragStart(this);" onkeyup="sliderDragEnd(this);" onchange="somfy.commitSliderTarget(this, ${shade.shadeId}, true);">
            </div>

            <div class="button-outline cmd-button btn-somfy-svg animScale btn-page-my" data-cmd="my" data-shadeid="${shade.shadeId}"><svg><use href="#svg-my"></use></svg></div>


            </div>` : '';
const carouselPages = [buttonsPage, positionPage, tiltPage].filter(p => p !== '');
const totalPages = carouselPages.length;
divCfg += `<div class="somfyShade shade-draggable" draggable="true" data-roomid="${shade.roomId}" data-mypos="${shade.myPos}" data-shadeid="${shade.shadeId}" data-remoteaddress="${shade.remoteAddress}" data-tilt="${shade.tiltType}" data-shadetype="${shade.shadeType}" data-flipposition="${shade.flipPosition ? 'true' : 'false'}" onclick="somfy.openEditShade(${shade.shadeId});"><div class="drag-handle" onclick="event.stopPropagation();"><svg class="icon-svg"><use href=#svg-drag></use></svg></div><div class="shade-icon-wrapper"><svg><use href="#${st.indic}"></use></svg></div><div class="shade-name"><div class="name-text">${escHtml(shade.name)}</div><div class="cfg-room">${escHtml(room.name)}</div></div><div class="idRemoteAddress"><span class="AddrId-label">${tr("ID")}</span><span class="shade-address">${shade.remoteAddress}</span></div><div class="divEditDelete-svg btn-card-remote" title="${tr("SUBTAB_VIRTUAL_REMOTE_S")}" onclick="event.stopPropagation(); somfy.openVirtualRemote('shade', ${shade.shadeId});"><svg class="icon-svg"><use href="#svg-remote"></use></svg></div><div class="divEditDelete-svg" onclick="event.stopPropagation(); somfy.deleteShade(${shade.shadeId});"><svg class="icon-svg" style="color: var(--color-danger);"><use href=#svg-trash></use></svg></div></div>`;
divCtl += `<div class="somfyShadeCtl" style="${roomId === 0 || roomId === room.roomId ? '' : 'display:none'}" data-shadeid="${shade.shadeId}" data-roomid="${shade.roomId}" data-direction="${shade.direction}" data-remoteaddress="${shade.remoteAddress}" data-position="${shade.position}" data-target="${shade.target}" data-mypos="${shade.myPos}" data-mytiltpos="${shade.myTiltPos}" data-shadetype="${shade.shadeType}" data-tilt="${shade.tiltType}" data-tilttarget="${shade.tiltTarget}" data-flipposition="${shade.flipPosition ? 'true' : 'false'}"
            data-windy="${(shade.flags & 0x10) === 0x10 ? 'true' : 'false'}" data-sunny="${(shade.flags & 0x20) === 0x20 ? 'true' : 'false'}">


            <div class="dash-card-content">

            <!-- Ligne 1 : En-tête -->
            <div class="dash-card-header">
            <div class="shade-icon" data-shadeid="${shade.shadeId}">
            <svg class="somfy-shade-icon" data-shadeid="${shade.shadeId}" style="--shade-position:${shade.flipPosition ? 100 - shade.position : shade.position}; --fpos:${shade.flipPosition ? 100 - shade.position : shade.position}%">
            <use href="#${st.ico}"></use>
            </svg>
            </div>
            <div class="shade-name">
            <span class="shadectl-name">${escHtml(shade.name)}</span>
            <span class="shadectl-room">${escHtml(room.name)}</span>
            <div class="shadectl-mypos">
            <span class="val-pos-label">${tr('POS_SHORT')}</span> <span class="val-pos">${shade.position}%</span>`;
if (shade.tiltType !== 0) divCtl += ` <span class="val-tilt-label">${tr('TILT_SHORT')}</span> <span class="val-tilt-pos">${shade.tiltPosition}%</span>`;
divCtl += `</div>
            </div>
            <div class="header-actions">`;
if (shade.sunSensor) {
divCtl += `<div class="button-sunflag cmd-button" data-cmd="sunflag" data-shadeid="${shade.shadeId}" data-on="${isSunOn ? 'true' : 'false'}">
                <svg><use href="#svg-sun"></use></svg>
                </div>`;
}
divCtl += `<div class="button-my" onclick="event.stopPropagation(); somfy.openSetMyPosition(${shade.shadeId});">
            <svg><use href="#svg-favori"></use></svg>
            </div>
            <div class="button-remote" title="${tr("SUBTAB_VIRTUAL_REMOTE_S")}" onclick="event.stopPropagation(); somfy.openVirtualRemote('shade', ${shade.shadeId});">
            <svg><use href="#svg-remote-badge"></use></svg>
            </div>
            </div>
            </div>

            <!-- Ligne 2 : Carrousel (Boutons / Position / Inclinaison selon les capacités) -->
            <div class="shadectl-controls-wrapper">`;
if (totalPages > 1) divCtl += `
            <button class="btn-nav btn-nav-left" type="button" onclick="somfy.shadeCarouselNav(${shade.shadeId}, -1);">
            <svg><use href="#svg-arrowLeft"></use></svg>
            </button>`;
divCtl += `
            <div class="controls-carousel-wrapper">
            <div class="carousel-viewport">
            <div class="carousel-track" id="carouselTrack_${shade.shadeId}" data-page="0" data-pages="${totalPages}">
            ${carouselPages.join('')}
            </div>
            </div>
            </div>`;
if (totalPages > 1) divCtl += `
            <button class="btn-nav btn-nav-right" type="button" onclick="somfy.shadeCarouselNav(${shade.shadeId}, 1);">
            <svg><use href="#svg-arrowRight"></use></svg>
            </button>`;
divCtl += `
            </div>

            <!-- Ligne 3 : Pied de carte (Badges & Pagination) -->
            <div class="shadectl-status-bar">
            <div class="shadectl-status-left">
            <div class="indicator indicator-clock schedule-indicator no-schedule" data-schedule-target="shade" data-schedule-id="${shade.shadeId}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
            <div class="indicator indicator-wind"><svg><use href="#indic-wind"></use></svg></div>
            <div class="indicator indicator-sun"><svg><use href="#indic-sun"></use></svg></div>
            <div class="val-my myShade-badge">
            My: <strong>${shade.myPos === -1 ? '---' : shade.myPos + '%'}</strong>${shade.tiltType !== 0 ? ` · <strong>${shade.myTiltPos === -1 ? '---' : shade.myTiltPos + '%'}</strong>` : ''}
            </div>
            </div>
            <div class="shadectl-status-right">`;
if (totalPages > 1) {
divCtl += `
            <!-- Indicateurs de page (Pills) -->
            <div class="page-dots" id="carouselDots_${shade.shadeId}">`;
for (let p = 0; p < totalPages; p++) {
divCtl += `<span class="dot${p === 0 ? ' active' : ''}" onclick="somfy.shadeCarouselGoTo(${shade.shadeId}, ${p});"></span>`;
}
divCtl += `</div>`;
}
divCtl += `
            <div class="button-menu" title="${tr("OPTION")}" onclick="event.stopPropagation(); somfy.openShadeCardMenu(${shade.shadeId});">
            <svg width="18" height="18"><use href="#svg-menuVertical"></use></svg>
            </div>
            </div>
            </div>


            </div>
            </div>`;
}
this.syncVRLayout();
get('divShadeList').innerHTML = divCfg;
let shadeControls = get('divShadeControls');
shadeControls.innerHTML = divCtl;
this.checkEmptyState();
let btns = shadeControls.querySelectorAll('div.cmd-button');
const clearTiltTimer = () => {
if (this.btnTimer) { clearTimeout(this.btnTimer); this.btnTimer = null; }
};
const armTiltTimer = (btn, fn) => {
this.btnTimer = setTimeout(() => { this.btnTimer = null; fn(); }, 2000);
};
const onCmdButtonPress = (event) => {
if (!isPrimaryPress(event)) return;
const btnEl = event.currentTarget;
clearTiltTimer();
let elShade = btnEl.closest('div.somfyShadeCtl');
let cmd = btnEl.getAttribute('data-cmd');
let shadeId = parseInt(btnEl.getAttribute('data-shadeid'), 10);
this.btnDown = new Date().getTime();
if (cmd === 'light' || cmd === 'sunflag') return;
if (cmd !== 'my' && makeBool(elShade.getAttribute('data-tilt'))) {
armTiltTimer(btnEl, () => this.sendTiltCommand(shadeId, cmd));
}
};
const onCmdButtonRelease = (event) => {
if (!isPrimaryPress(event)) return;
const btnEl = event.currentTarget;
let cmd = btnEl.getAttribute('data-cmd');
let shadeId = parseInt(btnEl.getAttribute('data-shadeid'), 10);
if (this.btnTimer) {
clearTiltTimer();
if (new Date().getTime() - this.btnDown <= 2000) this.sendCommand(shadeId, cmd);
}
else if (cmd === 'light') {
btnEl.setAttribute('data-on', !makeBool(btnEl.getAttribute('data-on')));
}
else if (cmd === 'sunflag') {
if (makeBool(btnEl.getAttribute('data-on')))
this.sendCommand(shadeId, 'flag');
else
this.sendCommand(shadeId, 'sunflag');
}
else this.sendCommand(shadeId, cmd);
};
for (let i = 0; i < btns.length; i++) {
btns[i].addEventListener('mousedown', onCmdButtonPress, true);
btns[i].addEventListener('mouseup', onCmdButtonRelease, true);
btns[i].addEventListener('mouseleave', clearTiltTimer, true);
btns[i].addEventListener('touchstart', (event) => { this._cmdTouchScrolled = false; onCmdButtonPress(event); }, true);
btns[i].addEventListener('touchmove', (event) => { this._cmdTouchScrolled = true; clearTiltTimer(); }, true);
btns[i].addEventListener('touchend', (event) => {
event.preventDefault();
if (!this._cmdTouchScrolled) onCmdButtonRelease(event); else clearTiltTimer();
}, true);
btns[i].addEventListener('touchcancel', clearTiltTimer, true);
}
for (let i = 0; i < shades.length; i++) {
this.applyShadeUIPrefs(shades[i].shadeId);
}
this.updateRoomCounts();
this.setListDraggable(get('divShadeList'), '.shade-draggable', (list) => {
let items = list.querySelectorAll('.shade-draggable');
let order = [];
for (let i = 0; i < items.length; i++) {
order.push(parseInt(items[i].getAttribute('data-shadeid'), 10));
}
putJSONSync('/shadeSortOrder', order, (err) => {
for (let i = order.length - 1; i >= 0; i--) {
let el = shadeControls.querySelector(`.somfyShadeCtl[data-shadeid="${order[i]}"`);
if (el) {
shadeControls.prepend(el);
}
}
});
});
this._syncScheduleIndicators();
}
shadeCarouselGoTo(shadeId, pageIndex) {
const track = get(`carouselTrack_${shadeId}`);
if (!track) return;
const total = parseInt(track.getAttribute('data-pages'), 10) || 1;
const clamped = Math.max(0, Math.min(total - 1, pageIndex));
track.style.transform = `translateX(-${clamped * 100}%)`;
track.setAttribute('data-page', clamped);
const dots = get(`carouselDots_${shadeId}`);
if (dots) dots.querySelectorAll('.dot').forEach((d, i) => d.classList.toggle('active', i === clamped));
}
shadeCarouselNav(shadeId, dir) {
const track = get(`carouselTrack_${shadeId}`);
if (!track) return;
const current = parseInt(track.getAttribute('data-page'), 10) || 0;
this.shadeCarouselGoTo(shadeId, current + dir);
}
closeShadePositioners() {
let ctls = document.querySelectorAll('.shade-positioner');
for (let i = 0; i < ctls.length; i++) {
ctls[i].remove();
}
}
screenShade() {
if (document.querySelector('.rts-shade, .inst-overlay')) return;
if (document.body.classList.contains('onboarding-active')) return;
const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const downMs = reduced ? 300 : 2600;
const upMs = reduced ? 300 : 2200;
const el = document.createElement('div');
el.className = 'rts-shade';
el.innerHTML = `<div class="rts-msg">
            <p class="rts-t1">${tr('ERR_RTSSHADE_0')}</p>
            <p class="rts-t2">${tr('ERR_RTSSHADE_1')}</p>
            <button type="button" class="rts-btn">${tr('ERR_RTSSHADE_2')}</button>
            <p class="rts-t3">${tr('ERR_RTSSHADE_3')}</p></div>`;
let running = true, asked = false, done = false;
const raise = () => {
if (done) return;
if (running) { asked = true; return; }
done = true;
clearTimeout(safety);
document.removeEventListener('keydown', onKey, true);
el.classList.add('rts-open');
setTimeout(() => el.remove(), upMs);
};
const onKey = (e) => {
if (['Shift', 'Control', 'Alt', 'Meta'].includes(e.key)) return;
raise();
};
el.addEventListener('click', raise);
document.addEventListener('keydown', onKey, true);
const safety = setTimeout(raise, downMs + 30000);
setTimeout(() => { running = false; if (asked) raise(); }, downMs);
document.body.appendChild(el);
}
openSetMyPosition(shadeId) {
if (typeof shadeId === 'undefined') return;
const shade = document.querySelector(`div.somfyShadeCtl[data-shadeid="${shadeId}"]`);
if (!shade) return;
const arrowUse = shade.querySelector('.handle-icon use');
document.querySelectorAll('.shade-positioner').forEach(el => {
el.remove();
document.querySelectorAll('.handle-icon use').forEach(u => u.setAttribute('href', '#svg-arrowRight'));
});
const currPos = parseInt(shade.getAttribute('data-position'), 10) || 0;
const currTiltPos = parseInt(shade.getAttribute('data-tiltposition'), 10) || 0;
const myPos = parseInt(shade.getAttribute('data-mypos'), 10);
const myTiltPos = parseInt(shade.getAttribute('data-mytiltpos'), 10);
const tiltType = parseInt(shade.getAttribute('data-tilt'), 10) || 0;
const lbl = makeBool(shade.getAttribute('data-flipposition')) ? tr('SETMYPOS_OPEN') : tr('SETMYPOS_CLOSED');
const positionSlider = (tiltType !== 3) ? `
        <div class="positioner-row">
        <span class="positioner-axis" title="${tr('SETMYPOS_TARGET_POS')}">${tr('POS_SHORT')}</span>
        <div class="slider-wrapper">
        <div class="slider-progress" style="width:${currPos}%;"><div class="slider-thumb-line"></div></div>
        <input id="slidShadeTarget" class="md3-range-input" type="range" min="0" max="100" step="1" value="${currPos}">
        </div>
        <span class="positioner-val"><span class="positioner-pct"><span class="positioner-num" id="spanShadeTarget">${currPos}</span>&nbsp;%</span><span class="positioner-sens">${lbl}</span></span>
        </div>` : '';
const tiltSlider = (tiltType > 0) ? `
        <div class="positioner-row">
        <span class="positioner-axis" title="${tr('SETMYPOS_TARGET_TILT_POS')}">${tr('TILT_SHORT')}</span>
        <div class="slider-wrapper tilt-slider">
        <div class="slider-progress" style="width:${currTiltPos}%;"><div class="slider-thumb-line"></div></div>
        <input id="slidShadeTiltTarget" class="md3-range-input" type="range" min="0" max="100" step="1" value="${currTiltPos}">
        </div>
        <span class="positioner-val"><span class="positioner-pct"><span class="positioner-num" id="spanShadeTiltTarget">${currTiltPos}</span>&nbsp;%</span><span class="positioner-sens">${lbl}</span></span>
        </div>` : '';
const div = document.createElement('div');
div.className = 'shade-positioner shade-positioner-popup';
div.setAttribute('data-shadeid', shadeId);
div.onclick = (e) => e.stopPropagation();
div.innerHTML = `
        <div class="shade-positioner-inner">
        <div class="positioner-head">
        <span class="positioner-title"><svg><use href="#svg-favori"></use></svg>${tr('SETMYPOS_TITLE')}</span>
        </div>
        <div class="positioner-rows">${positionSlider}${tiltSlider}</div>
        <div class="popup-actions">
        <button id="btnSetMyPosition" pop type="button">${tr("BT_SET_MY_POSITION")}</button>
        <button id="btnCancelMy" pop line type="button">${tr("BT_CANCEL_1")}</button>
        </div>
        </div>`;
shade.appendChild(div);
if (arrowUse) arrowUse.setAttribute('href', '#svg-arrowLeft');
const animateClose = () => {
div.classList.add('popup-slide-out');
if (arrowUse) arrowUse.setAttribute('href', '#svg-arrowRight');
setTimeout(() => { div.remove(); }, 300);
};
const elTarget = div.querySelector('#slidShadeTarget');
const elTiltTarget = div.querySelector('#slidShadeTiltTarget');
const elBtnSave = div.querySelector('#btnSetMyPosition');
const elBtnCancel = div.querySelector('#btnCancelMy');
const fnUpdateUI = () => {
const pos = elTarget ? parseInt(elTarget.value, 10) : 0;
const tilt = elTiltTarget ? parseInt(elTiltTarget.value, 10) : 0;
const isSameAsMy = (tiltType === 3) ? (tilt === myTiltPos) : (pos === myPos && (tiltType === 0 || tilt === myTiltPos));
if (isSameAsMy) {
elBtnSave.innerHTML = tr('BT_CLEAR_MY_POSITION');
elBtnSave.style.background = 'var(--color-text-warning)';
} else {
elBtnSave.innerHTML = tr('BT_SET_MY_POSITION');
elBtnSave.style.background = '';
}
};
if (elTarget) elTarget.oninput = () => {
syncSliderProgress(elTarget);
get('spanShadeTarget').innerHTML = elTarget.value;
fnUpdateUI();
};
if (elTiltTarget) elTiltTarget.oninput = () => {
syncSliderProgress(elTiltTarget);
get('spanShadeTiltTarget').innerHTML = elTiltTarget.value;
fnUpdateUI();
};
elBtnCancel.onclick = (e) => { e.preventDefault(); animateClose(); };
elBtnSave.onclick = (e) => {
e.preventDefault();
const pos = elTarget ? parseInt(elTarget.value, 10) : 0;
const tilt = elTiltTarget ? parseInt(elTiltTarget.value, 10) : 0;
somfy.sendShadeMyPosition(shadeId, pos, tilt);
animateClose();
};
setTimeout(() => {
document.body.addEventListener('click', animateClose, { once: true });
}, 100);
fnUpdateUI();
}
sendShadeMyPosition(shadeId, pos, tilt) {
logger.debug(`Sending My Position for shade id ${shadeId} to ${pos} and ${tilt}`);
let overlay = ui.waitMessage(get('divContainer'));
putJSON('/setMyPosition', { shadeId: shadeId, pos: pos, tilt: tilt }, (err, response) => {
this.closeShadePositioners();
overlay.remove();
if (err) { logger.error('Failed to set My Position:', err); ui.serviceError(err); return; }
logger.debug('My Position command sent:', response);
const idx = (this.shades || []).findIndex(s => s.shadeId === shadeId);
if (idx >= 0) Object.assign(this.shades[idx], response);
if (response && typeof response.myPos !== 'undefined') {
document.querySelectorAll(`.somfyShadeCtl[data-shadeid="${shadeId}"]`).forEach(d => {
d.dataset.mypos = response.myPos;
d.dataset.mytiltpos = response.myTiltPos ?? -1;
const myBadge = d.querySelector('.myShade-badge');
if (myBadge) {
let html = `My: <strong>${response.myPos === -1 ? '---' : response.myPos + '%'}</strong>`;
if (response.tiltType !== 0) {
const myTilt = response.myTiltPos ?? -1;
html += ` · <strong>${myTilt === -1 ? '---' : myTilt + '%'}</strong>`;
}
myBadge.innerHTML = html;
}
});
}
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
});
}
getShadeUIPrefs(shadeId) {
let all = {};
try { all = JSON.parse(localStorage.getItem('somfyShadeUIPrefs') || '{}'); } catch (e) { all = {}; }
const p = all[shadeId] || {};
return {
defaultCarouselPage: typeof p.defaultCarouselPage === 'number' ? p.defaultCarouselPage : 0,
showMyBadge: typeof p.showMyBadge === 'boolean' ? p.showMyBadge : true
};
}
setShadeUIPrefs(shadeId, patch) {
let all = {};
try { all = JSON.parse(localStorage.getItem('somfyShadeUIPrefs') || '{}'); } catch (e) { all = {}; }
all[shadeId] = Object.assign(this.getShadeUIPrefs(shadeId), patch);
localStorage.setItem('somfyShadeUIPrefs', JSON.stringify(all));
}
applyShadeUIPrefs(shadeId) {
const prefs = this.getShadeUIPrefs(shadeId);
const card = document.querySelector(`.somfyShadeCtl[data-shadeid="${shadeId}"]`);
if (!card) return;
const badge = card.querySelector('.myShade-badge');
if (badge) badge.style.display = prefs.showMyBadge ? '' : 'none';
this.shadeCarouselGoTo(shadeId, prefs.defaultCarouselPage);
}
openShadeCardMenu(shadeId) {
if (typeof shadeId === 'undefined') return;
const shade = document.querySelector(`div.somfyShadeCtl[data-shadeid="${shadeId}"]`);
if (!shade) return;
document.querySelectorAll('.shade-positioner').forEach(el => el.remove());
const shadeType = parseInt(shade.getAttribute('data-shadetype'), 10);
const tiltType = parseInt(shade.getAttribute('data-tilt'), 10) || 0;
const isSimpleShade = this.noMyShadeTypes.includes(shadeType);
const shadeHasTilt = tiltType > 0;
const prefs = this.getShadeUIPrefs(shadeId);
const pageOptions = [{ value: 0, label: tr('OPT_PAGE_BUTTONS') }];
if (!isSimpleShade) pageOptions.push({ value: 1, label: tr('OPT_PAGE_POSITION') });
if (!isSimpleShade && shadeHasTilt) pageOptions.push({ value: 2, label: tr('OPT_PAGE_TILT') });
const segButtons = pageOptions.map(p => `<button type="button" data-page="${p.value}" aria-pressed="${prefs.defaultCarouselPage === p.value ? 'true' : 'false'}">${p.label}</button>`).join('');
const pageField = pageOptions.length > 1 ? `
        <div class="positioner-field">
        <span class="positioner-label">${tr('OPT_DEFAULT_CAROUSEL_PAGE')}</span>
        <div class="positioner-seg" id="segCardDefaultPage_${shadeId}">${segButtons}</div>
        </div>` : '';
const div = document.createElement('div');
div.className = 'shade-positioner shade-positioner-popup';
div.setAttribute('data-shadeid', shadeId);
div.onclick = (e) => e.stopPropagation();
div.innerHTML = `
        <div class="shade-positioner-inner">
        <div class="positioner-head">
        <span class="positioner-title"><svg><use href="#svg-menuVertical"></use></svg>${tr('OPTION')}</span>
        <button id="btnCloseCardMenu_${shadeId}" pop line type="button">${tr('BT_CLOSE')}</button>
        </div>
        <div class="positioner-rows">
        ${pageField}
        <label class="positioner-switch" for="chkCardShowMyBadge_${shadeId}">
        <span class="positioner-label">${tr('OPT_SHOW_MY_BADGE')}</span>
        <span class="switch">
        <input id="chkCardShowMyBadge_${shadeId}" type="checkbox" ${prefs.showMyBadge ? 'checked' : ''}>
        <div></div>
        </span>
        </label>
        </div>
        </div>`;
shade.appendChild(div);
const animateClose = () => {
div.classList.add('popup-slide-out');
setTimeout(() => { div.remove(); }, 300);
};
const segEl = div.querySelector(`#segCardDefaultPage_${shadeId}`);
const chkEl = div.querySelector(`#chkCardShowMyBadge_${shadeId}`);
if (segEl) segEl.querySelectorAll('button').forEach(btn => {
btn.onclick = (e) => {
e.preventDefault();
const page = parseInt(btn.getAttribute('data-page'), 10);
this.setShadeUIPrefs(shadeId, { defaultCarouselPage: page });
this.shadeCarouselGoTo(shadeId, page);
segEl.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'));
};
});
if (chkEl) chkEl.onchange = () => {
this.setShadeUIPrefs(shadeId, { showMyBadge: chkEl.checked });
this.applyShadeUIPrefs(shadeId);
};
div.querySelector(`#btnCloseCardMenu_${shadeId}`).onclick = (e) => { e.preventDefault(); animateClose(); };
setTimeout(() => {
document.body.addEventListener('click', animateClose, { once: true });
}, 100);
}
setLinkedRemotesList(shade) {
const badgeCount = get('badgeRemoteCount');
const remotes = shade.linkedRemotes || [];
if (badgeCount) {
badgeCount.innerText = remotes.length;
badgeCount.style.display = remotes.length > 0 ? 'inline-block' : 'none';
}
const currentOverlay = get('divRemotesOverlay');
if (currentOverlay) {
const scrollContent = get('divRemotesScrollContentInner');
if (scrollContent) scrollContent.innerHTML = this.modalRemotesListHtml(shade);
}
}
_remoteSignalCacheKey() { return 'somfyRemoteSignalCache'; }
_getStoredRemoteSignal(remoteAddress) {
try {
const cache = JSON.parse(localStorage.getItem(this._remoteSignalCacheKey()) || '{}');
const v = cache[remoteAddress];
return typeof v === 'number' ? v : null;
} catch (e) { return null; }
}
_storeRemoteSignal(remoteAddress, rssi) {
try {
const cache = JSON.parse(localStorage.getItem(this._remoteSignalCacheKey()) || '{}');
cache[remoteAddress] = rssi;
localStorage.setItem(this._remoteSignalCacheKey(), JSON.stringify(cache));
} catch (e) { }
}
remoteSignalHtml(rssi, remoteAddress) {
let hasSignal = typeof rssi === 'number' && rssi > -128;
if (hasSignal && remoteAddress) {
this._storeRemoteSignal(remoteAddress, rssi);
} else if (!hasSignal && remoteAddress) {
const stored = this._getStoredRemoteSignal(remoteAddress);
if (typeof stored === 'number') {
rssi = stored;
hasSignal = true;
}
}
const level = hasSignal ? this.rssiLevel(rssi) : 'unknown';
const valueText = hasSignal ? `${rssi} dBm` : '—';
return `
        <div class="linkedRemote-signal">
        <svg class="linkedRemote-signal-icon sig-${level}"><use href="#svg-tabRadio"></use></svg>
        <span class="linkedRemote-signal-label">${tr('M_SIGNAL')}</span>
        <span class="linkedRemote-sep">|</span>
        <span class="linkedRemote-signal-value sig-${level}">${valueText}</span>
        </div>`;
}
modalRemotesListHtml(shade) {
const remotes = shade.linkedRemotes || [];
if (remotes.length === 0) {
return `
            <div class="empty-state">
            <svg class="empty-icon"><use href="#svg-linkRemot"></use></svg>
            <div class="label">${tr('REMOTESLIST_EMPTY')}</div>
            <div class="empty-subtext">${tr('REMOTESLIST_EMPTY_DESC')}</div>
            </div>`;
}
return remotes.map((remote, i) => `
        <div class="somfyLinkedRemote linkedRemoteCard" data-shadeid="${shade.shadeId}" data-remoteaddress="${remote.remoteAddress}">
        <div class="remote-card-top">
        <div class="linkedWrap">
        <svg class="icon-svg"><use href="#svg-linkRemot"></use></svg>
        </div>
        <div class="linkedContent">
        <div class="linkedRemote-title">${tr("REMOTESLIST_LINKED")} ${i + 1}</div>
        <div class="linkedRemote-meta">
        <span>${tr("ADDR")} ${remote.remoteAddress}</span>
        <span class="linkedRemote-sep">|</span>
        <span>${tr("CODE")} ${remote.lastRollingCode}</span>
        </div>
        </div>
        <div class="linkedRemote-btn-delete" onclick="somfy.unlinkRemote(${shade.shadeId}, '${remote.remoteAddress}');">
        <svg><use href="#svg-trash"></use></svg>
        </div>
        </div>
        <div class="remote-card-bottom">
        ${this.remoteSignalHtml(remote.lastRssi, remote.remoteAddress)}
        </div>
        </div>
        `).join('');
}
buildRemotesOverlay(shadeOrId) {
if (get('divRemotesOverlay')) return;
if (shadeOrId === null || typeof shadeOrId !== 'object') {
getJSONSync(`/shade?shadeId=${shadeOrId}`, (err, shade) => {
if (err) return ui.serviceError(err);
this._buildRemotesOverlay(shade);
});
return;
}
this._buildRemotesOverlay(shadeOrId);
}
_buildRemotesOverlay(shade) {
if (get('divRemotesOverlay')) return;
let div = document.createElement('div');
div.id = 'divRemotesOverlay';
div.className = 'modal-overlay';
div.setAttribute('data-shadeid', shade.shadeId);
div.setAttribute('data-searching', 'false');
div.innerHTML = `
        <div class="message-content remotes-content" id="divRemotesPopupContent">

        ${modalHeader('REMOTESLIST_TITLE', 'svg-remote', {
subtitle: 'REMOTESLIST_TITLE_DESC',
})}

        <div id="divRemotesScrollContent">

        <div class="overlay-scroll-content" id="divRemotesScrollContentInner">
        ${this.modalRemotesListHtml(shade)}
        </div>
        </div>

        <div id="divRemoteSearchStatus" class="information remote-search-status" style="display:none;">
        <div class="information-header">
        <span class="remote-search-spinner"></span>
        <b id="spanRemoteSearchStatusText">${tr('REMOTESLIST_SEARCH')}</b>
        </div>
        </div>

        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">
        <button id="btnRemotesGoBack" line type="button">${tr('BT_CLOSE')}</button>


        <button id="btnRemoteSearchToggle" type="button">
        <svg><use id="useRemoteSearchIcon" href="#svg-search"></use></svg>
        <span id="spanRemoteSearchBtnLabel">${tr('BT_SEARCH')}</span>
        </button>
        </div>
        </div>
        </div>`;
shOverlay(div);
div.querySelector('#btnRemotesGoBack').onclick = () => {
this.stopRemoteSearch(div);
closeOverlay(div);
};
div.querySelector('#btnRemoteSearchToggle').onclick = () => this.toggleRemoteSearch(div);
}
toggleRemoteSearch(div) {
if (!div) return;
this.setRemoteSearchState(div, div.dataset.searching !== 'true');
}
stopRemoteSearch(div) {
this.setRemoteSearchState(div || get('divRemotesOverlay'), false);
}
setRemoteSearchState(div, on) {
if (!div) return;
div.dataset.searching = on ? 'true' : 'false';
delete div.dataset.searchbusy;
if (on) {
setOverlayLock(div, 'confirm', {
onConfirm: () => this.stopRemoteSearch(div),
titleKey: 'PROMPT_REMOTE_SEARCH_TITLE',
msgKey: 'PROMPT_REMOTE_SEARCH_MSG',
});
} else {
clearOverlayLock(div);
}
const btn = div.querySelector('#btnRemoteSearchToggle');
const closeBtn = div.querySelector('#btnRemotesGoBack');
const label = div.querySelector('#spanRemoteSearchBtnLabel');
const icon = div.querySelector('#useRemoteSearchIcon');
const status = div.querySelector('#divRemoteSearchStatus');
if (btn) btn.toggleAttribute('red', on);
if (closeBtn) closeBtn.style.display = on ? 'none' : '';
if (label) label.innerText = tr(on ? 'BT_CANCEL' : 'BT_SEARCH');
if (icon) {
const href = on ? '#svg-close' : '#svg-linkRemot';
icon.setAttribute('href', href);
icon.setAttribute('xlink:href', href);
}
if (status) status.style.display = on ? 'flex' : 'none';
}
procShadeState(state) {
const g = get, sId = state.shadeId;
const cached = (this.shades || []).find(s => s.shadeId === sId);
if (cached) {
Object.assign(cached, state);
if (typeof state.type !== 'undefined') cached.shadeType = state.type;
}
if (this._vrTarget && this._vrTarget.type === 'shade' && this._vrTarget.id === sId) {
this.updateVRPosition(state);
this.setVRCenterButton(this.vrIsImpulse(this.vrTarget()), this.vrIsMoving(state));
this.setVRSunFlag(state.flags);
this.setVRSunSensor(!!state.sunSensor);
this.setVRTiltMy(state);
}
document.querySelectorAll(`.somfy-shade-icon[data-shadeid="${sId}"]`).forEach(ico => {
const p = state.flipPosition ? 100 - state.position : state.position;
ico.style.setProperty('--shade-position', p);
ico.style.setProperty('--fpos', state.position + '%');
});
if (g('spanShadeId')?.innerText == sId) {
if (g('valPos')) g('valPos').innerText = state.position;
const lTC = g('labelTiltContainer'), sVT = g('valTilt');
if (state.tiltType !== 0) {
if (lTC) lTC.style.display = 'flex';
if (sVT) sVT.innerText = state.tiltPosition;
} else if (lTC) {
lTC.style.display = 'none';
}
}
document.querySelectorAll(`.button-sunflag[data-shadeid="${sId}"]`).forEach(btn => {
btn.style.display = state.sunSensor ? '' : 'none';
btn.dataset.on = (state.flags & 0x01) === 0x01;
});
document.querySelectorAll(`.somfyShadeCtl[data-shadeid="${sId}"]`).forEach(d => {
Object.assign(d.dataset, {
direction: state.direction,
position: state.position,
target: state.target,
mypos: state.myPos,
windy: (state.flags & 0x10) === 0x10,
sunny: (state.flags & 0x20) === 0x20,
mytiltpos: state.myTiltPos ?? -1
});
if (state.tiltType !== 0) {
Object.assign(d.dataset, {
tiltdirection: state.tiltDirection,
tiltposition: state.tiltPosition,
tilttarget: state.tiltTarget
});
}
const posEl = d.querySelector('.val-pos');
if (posEl) posEl.innerText = `${state.position}%`;
if (state.tiltType !== 0) {
const tiltEl = d.querySelector('.val-tilt-pos');
if (tiltEl) tiltEl.innerText = `${state.tiltPosition}%`;
}
const myBadge = d.querySelector('.myShade-badge');
if (myBadge) {
let html = `My: <strong>${state.myPos === -1 ? '---' : state.myPos + '%'}</strong>`;
if (state.tiltType !== 0) {
const myTilt = state.myTiltPos ?? -1;
html += ` · <strong>${myTilt === -1 ? '---' : myTilt + '%'}</strong>`;
}
myBadge.innerHTML = html;
}
const posSlider = d.querySelector('.carousel-slider-pos');
if (posSlider) {
posSlider.dataset.realpos = state.position;
if (posSlider.dataset.dragging !== 'true') {
posSlider.value = state.position;
syncSliderProgress(posSlider);
}
}
if (state.tiltType !== 0) {
const tiltSlider = d.querySelector('.carousel-slider-tilt');
if (tiltSlider) {
tiltSlider.dataset.realpos = state.tiltPosition;
if (tiltSlider.dataset.dragging !== 'true') {
tiltSlider.value = state.tiltPosition;
syncSliderProgress(tiltSlider);
}
}
}
});
}
onShadeTypeChanged(el) {
const g = get,
type = parseInt(g('selShadeType').value, 10),
tilt = parseInt(g('selTiltType').value, 10),
bitL = g('selShadeBitLength')?.value,
ico = g('icoShade'),
isNew = g('spanShadeId').innerText === '*',
st = this.shadeTypes.find(x => x.type === type) || { type };
['somfyShade', 'divSomfyButtons'].forEach(id => g(id)?.setAttribute('data-shadetype', type));
if (ico) {
this.shadeTypes.forEach(t => t.ico !== st.ico && ico.classList.remove(t.ico));
const use = ico.querySelector('use');
if (use && st.ico) {
const href = '#' + st.ico;
use.setAttribute('href', href);
use.setAttribute('xlink:href', href);
}
}
const hasLift = !!st.lift;
const curTilt = st.tilt ? tilt : 0;
const showLiftSettings = hasLift && tilt !== 3;
const disp = (id, cond, d = 'flex') => {
const e = g(id);
if (e) e.style.display = cond ? d : 'none';
};
disp('divTiltSettings', st.tilt, 'flex');
disp('divShadeTimings', hasLift, 'flex');
disp('divLiftSettings', showLiftSettings, 'flex');
disp('divSunSensor', st.sun);
disp('divLightSwitch', st.light);
disp('divFlipPosition', st.fpos);
disp('divFlipCommands', st.fcmd);
disp('divFldTiltTimeContainer', curTilt, 'flex');
disp('divTiltOrderContainer', tilt === 2, 'flex');
this.updateCalibrationSummary();
const showStepHR = [7, 8, 2, 4, 0].includes(type) || (type === 1 && [2, 3, 4].includes(tilt));
disp('labelPosContainer', hasLift && !isNew);
disp('labelTiltContainer', curTilt && !isNew);
if (!st.light && g('cbHasLight')) g('cbHasLight').checked = false;
if (!st.sun && g('cbHasSunsensor')) g('cbHasSunsensor').checked = false;
this.relayoutOptionGrids();
}
relayoutOptionGrids() {
document.querySelectorAll('.options-grid').forEach(grid => {
const items = [...grid.children];
items.forEach(e => e.classList.remove('opt-span2'));
const vis = items.filter(e => getComputedStyle(e).display !== 'none');
if (vis.length % 2) vis[vis.length - 1].classList.add('opt-span2');
});
}
setCalibrationMode(mode) {
const g = get,
isWizard = mode !== 'manual';
if (g('divCalModeWizard')) g('divCalModeWizard').style.display = isWizard ? '' : 'none';
if (g('divCalModeManual')) g('divCalModeManual').style.display = isWizard ? 'none' : 'flex';
if (g('calModeWizardRadio')) g('calModeWizardRadio').checked = !isWizard;
if (isWizard) this.updateCalibrationSummary();
}
updateCalibrationSummary() {
const g = get,
badge = g('calSummaryBadge');
if (!badge) return;
const secVal = (id) => { const el = g(id); const v = el ? parseFloat(el.value) : NaN; return isNaN(v) ? 0 : v; };
const tiltType = g('selTiltType') ? parseInt(g('selTiltType').value, 10) : 0;
const parts = [
`${tr('SHADE_LABEL_UP')} ${secVal('fldShadeUpTime').toFixed(1)}s`,
`${tr('SHADE_LABEL_DOWN')} ${secVal('fldShadeDownTime').toFixed(1)}s`
];
if (tiltType > 0) parts.push(`${tr('SHADE_LABEL_TILT')} ${secVal('fldTiltTimeUp').toFixed(1)}s / ${secVal('fldTiltTimeDown').toFixed(1)}s`);
badge.textContent = parts.join(' · ');
}
onShadeBitLengthChanged(el) {
get('somfyShade').setAttribute('data-bitlength', el.value);
this.onShadeTypeChanged(el);
}
onShadeProtoChanged(el) {
get('somfyShade').setAttribute('data-proto', el.value);
this.relayoutOptionGrids();
}
showEditShade(bShow) {
let el = get('divLinkRepeater');
if (el) el.remove();
el = get('divPairing');
if (el) el.remove();
el = get('divRollingCode');
if (el) el.remove();
el = get('divRemotesOverlay');
if (el) el.remove();
el = get('somfyShade');
if (el) el.style.display = bShow ? '' : 'none';
el = get('divShadeListContainer');
if (el) el.style.display = bShow ? 'none' : '';
if (!bShow) {
clearDirty();
routeSetEditor('divSomfyMotors', null);
}
if (bShow) {
this.showEditGroup(false);
this.showEditRoom(false);
}
}
applyLedFeedbackVisibility() {
const has = typeof window.__ledPin === 'number' && window.__ledPin >= 0;
document.querySelectorAll('.ledFeedbackRow').forEach(el => { el.style.display = has ? '' : 'none'; });
}
openEditShade(shadeId, opts) { confirmDiscardChanges(() => this._openEditShade(shadeId, opts)); }
_openEditShade(shadeId, opts) {
const g = get,
isNew = shadeId === undefined,
ico = g('icoShade'),
btns = ['btnPairShade', 'btnUnpairShade', 'btnLinkRemote', 'btnSetRollingCode'];
if (isNew && this.shades?.length >= 30) {
routeSetEditor('divSomfyMotors', null, { replace: true });
return ui.errorMessage(g('divSomfySettings'), tr('ERR_DEVICE_LIMIT_REACHED'));
}
const s = (id, d) => { const e = g(id); if(e) e.style.display = d; };
this.applyLedFeedbackVisibility();
s('divControlContent', isNew ? 'none' : 'flex');
s('divScheduleSectionShade', isNew ? 'none' : 'flex');
s('divshowSomfyButtons', 'flex');
btns.forEach(id => s(id, 'none'));
['blocPairDevice', 'divLinkedRemoteList', 'labelPosContainer'].forEach(id => s(id, 'none'));
getJSONSync(isNew ? '/getNextShade' : `/shade?shadeId=${shadeId}`, (err, shade) => {
if (err) {
routeSetEditor('divSomfyMotors', null, { replace: true });
return (opts && opts.silentError) ? undefined : ui.serviceError(err);
}
if (isNew) {
Object.assign(shade, {
name: '', shadeType: 4, roomId: 0, downTime: 10000, upTime: 10000,
tiltTimeUp: 7000, tiltTimeDown: 7000, tiltFirstOnOpen: true, tiltFirstOnClose: true,
tiltType: 0, flipCommands: 0, flipPosition: 0, paired: 0
});
}
if (!isNew) {
s('labelPosContainer', 'flex');
s('blocPairDevice', 'flex');
['btnLinkRemote', 'btnSetRollingCode'].forEach(id => s(id, 'flex'));
s(shade.paired ? 'btnUnpairShade' : 'btnPairShade', 'flex');
if (g('valPos')) g('valPos').innerText = shade.position;
this.setLinkedRemotesList(shade);
this.updateScheduleList(() => this.renderScheduleBadges('divShadeScheduleBadges', 'shade', shadeId));
}
const hTitle = g('somfyHeaderTitle'), hDesc = g('somfyHeaderDesc');
if (hTitle && hDesc) {
if (isNew) {
hTitle.innerText = tr('SHADE_CREATE_TITLE');
hDesc.innerText = tr('SHADE_CREATE_DESC');
} else {
hTitle.innerText = tr('SHADE_EDIT_TITLE');
const currentCount = this.shades ? this.shades.length : 0;
const formattedCapacity = `<span class="desc-highlight">${currentCount}/30</span>`;
hDesc.innerHTML = tr('SHADE_EDIT_DESC').replace('%s', formattedCapacity);
}
}
if (g('valTilt')) g('valTilt').innerText = shade.tiltPosition || 0;
ui.setFocus('btnPairShade', !isNew && !shade.paired);
const rev = shade.flipPosition,
p = rev ? 100 - shade.position : shade.position,
tp = rev ? 100 - shade.tiltPosition : shade.tiltPosition;
if (ico) {
const st = ico.style;
st.setProperty('--shade-position', p);
st.setProperty('--fpos', p + '%');
st.setProperty('--tilt-position', tp + '%');
ico.setAttribute('data-shadeid', isNew ? '*' : shadeId);
}
g('btnSaveShadeText').innerText = tr(isNew ? 'BT_CREATE' : 'BT_SAVE');
g('useSaveShadeIcon').setAttribute('href', isNew ? '#svg-add' : '#svg-save');
g('spanShadeId').innerText = isNew ? '*' : shadeId;
shade.upTimeSec = Math.round(shade.upTime / 100) / 10;
shade.downTimeSec = Math.round(shade.downTime / 100) / 10;
shade.tiltTimeUpSec = Math.round((shade.tiltTimeUp || 0) / 100) / 10;
shade.tiltTimeDownSec = Math.round((shade.tiltTimeDown || 0) / 100) / 10;
ui.toElement(g('somfyShade'), shade);
if (g('selShadeBitLength')) g('somfyShade').setAttribute('data-bitlength', g('selShadeBitLength').value);
this.onShadeTypeChanged(g('selShadeType'));
this.setCalibrationMode(isNew ? 'manual' : 'wizard');
this.showEditShade(true);
routeSetEditor('divSomfyMotors', isNew ? 'new' : shadeId, { label: isNew ? tr('SHADE_CREATE_TITLE') : shade.name });
watchDirty(g('somfyShade'));
});
}
saveShade() {
const g = get,
sId = parseInt(g('spanShadeId').innerText, 10),
obj = ui.fromElement(g('somfyShade')),
settings = g('divSomfySettings');
['upTime', 'downTime', 'tiltTimeUp', 'tiltTimeDown'].forEach((f) => {
const sec = obj[`${f}Sec`];
if (typeof sec !== 'undefined' && !isNaN(sec)) obj[f] = Math.round(sec * 1000);
delete obj[`${f}Sec`];
});
const checks = [
[isNaN(obj.remoteAddress) || obj.remoteAddress < 1 || obj.remoteAddress > 16777215, 'ERR_REMOTE_ADDRESS_INVALID'],
[!obj.name || obj.name.length > 20, 'ERR_DEVIVE_NAME_INVALID'],
[isNaN(obj.upTime) || obj.upTime < 1 || obj.upTime > 180000, 'ERR_UP_TIME_INVALID'],
[isNaN(obj.downTime) || obj.downTime < 1 || obj.downTime > 180000, 'ERR_DOWN_TIME_INVALID'],
[isNaN(obj.tiltTimeUp) || obj.tiltTimeUp < 1 || obj.tiltTimeUp > 180000, 'ERR_TILT_TIME_UP_INVALID'],
[isNaN(obj.tiltTimeDown) || obj.tiltTimeDown < 1 || obj.tiltTimeDown > 180000, 'ERR_TILT_TIME_DOWN_INVALID']
];
const basicError = checks.find(c => c[0]);
if (basicError) return ui.errorMessage(settings, tr(basicError[1]));
if (obj.proto === 8 || obj.proto === 9) {
const isSp = [5, 14, 15, 16, 10].includes(obj.shadeType);
if (obj.gpioUp === obj.gpioDown && !(isSp && obj.proto === 9)) {
return ui.errorMessage(settings, tr('ERR_GPIO_UP_DOWN_NOT_UNIQUE'));
}
if (!isSp && obj.proto === 9 && (obj.gpioMy === obj.gpioUp || obj.gpioMy === obj.gpioDown)) {
return ui.errorMessage(settings, tr('ERR_GPIO_UP_DOWN_MY_NOT_UNIQUE'));
}
}
const isNew = isNaN(sId) || sId >= 255;
if (!isNew) obj.shadeId = sId;
putJSONSync(isNew ? '/addShade' : '/saveShade', obj, (err, shade) => {
if (err) return ui.serviceError(err);
logger.debug("Shade saved/added:", shade);
const msg = isNew ? tr('MSG_ADD_SUCCESS') : tr('MSG_SAVE_SUCCESS');
ui.successMessage(msg);
clearDirty();
this.updateShadeList()
this.openEditShade(shade.shadeId);
});
}
deleteShade(shadeId) {
let valid = true;
if (isNaN(shadeId) || shadeId >= 255 || shadeId <= 0) {
ui.errorMessage(tr('ERR_DEVICE_ID_REQUIRED'));
valid = false;
}
if (valid) {
getJSONSync(`/shade?shadeId=${shadeId}`, (err, shade) => {
if (err) ui.serviceError(err);
else if (shade.inGroup) ui.errorMessage(tr('ERR_DEVICE_IN_GROUP'));
else this.updateScheduleList(() => {
const scheduleCount = (this.schedules || []).filter(sc => sc.targetType === 'shade' && sc.targetId === shadeId).length;
let prompt = ui.promptMessage(tr('PROMPT_DELETE_SHADE'), () => {
ui.clearErrors();
putJSONSync('/deleteShade', { shadeId: shadeId }, (err, shade) => {
this.updateShadeList();
if (scheduleCount > 0) this.updateScheduleList();
prompt.remove();
});
});
const scheduleWarning = scheduleCount > 0 ? `<p>${tr('PROMPT_DELETE_TARGET_SCHEDULES').replace('{n}', scheduleCount)}</p>` : '';
prompt.querySelector('.sub-message').innerHTML = `<p>${tr("PROMPT_DELETE_SHADE_WARNING")}</p>${scheduleWarning}<p>${tr("PROMPT_DELETE_SHADE_CONFIRM").replace("{SHADE_NAME}", escHtml(shade.name))}</p>`;
});
});
}
}
updateShadeList(cb) {
getJSONSync('/shades', (err, shades) => {
if (err) {
logger.error('Failed to load shades:', err);
ui.serviceError(err);
}
else {
this.setShadesList(shades);
if (typeof cb === 'function') cb();
}
});
}
setRollingCode(shadeId, rollingCode) {
putJSONSync('/setRollingCode', { shadeId: shadeId, rollingCode: rollingCode }, (err, shade) => {
if (err) ui.serviceError(get('divSomfySettings'), err);
else {
let dlg = get('divRollingCode');
if (dlg) { clearDirty(dlg); dlg.remove(); }
}
});
}
openSetRollingCode(shadeId) {
let overlay = ui.waitMessage(get('divContainer'));
getJSON(`/shade?shadeId=${shadeId}`, (err, shade) => {
overlay.remove();
if (err) return ui.serviceError(err);
let div = document.createElement('div');
div.id = 'divRollingCode';
div.className = 'modal-overlay';
div.innerHTML = `
            <div class="message-content">
            ${modalHeader('ROLLING_CODE_TITLE', 'svg-warning', {
subtitle: 'ROLLING_CODE_DESC',
})}
            <div class="overlay-scroll-content">

            <div class="error">
            <div class="error-header">
            <svg><use href="#svg-warning"></use></svg>
            <b>${tr("MSG_DANGER")}</b>
            </div>

            <div class="information-text">
            <span>${tr("ROLLING_CODE_WARNING_DESC_1")}</span>
            </div>
            </div>

            <div class="uniblocStep">${tr("ROLLING_CODE_WARNING_DESC_2")}</div>
            <div class="uniblocCol uniblocRollingCode dirty-target">
            <label class="label" for="fldNewRollingCode">${tr("BT_ROLLING_CODE")}</label>
            <input id="fldNewRollingCode" class="inputAndSelect" min="0" max="65535" name="newRollingCode" type="number" value="${shade.lastRollingCode}">
            </div>


            </div>

            <div class="hrModal margin0"></div>
            <div class="button-container-modal">
            <div class="button-content-modal">

            <button id="btnChangeRollingCode" class="bouton-Danger" type="button" onclick="somfy.setRollingCode(${shadeId}, parseInt(get('fldNewRollingCode').value, 10));">${tr("BT_SET_ROLLING_CODE")}</button>
            <button id="btnCancel" line type="button">${tr("BT_CANCEL_1")} </button>
            </div>
            </div>
            </div>`;
shOverlay(div);
watchDirty(div);
div.querySelector('#btnCancel').onclick = () => requestCloseOverlay(div);
ui.setFocus(btnCancel, true, 'var(--color-success)');
});
}
setPaired(shadeId, paired) {
let obj = { shadeId: shadeId, paired: paired || false };
let div = get('divPairing');
let overlay = typeof div === 'undefined' ? undefined : ui.waitMessage(div);
putJSONSync('/setPaired', obj, (err, shade) => {
if (overlay) overlay.remove();
if (err) {
logger.error('Failed to set pairing state:', err);
ui.errorMessage(err.message);
}
else if (div) {
logger.debug('Pairing state updated:', shade);
this.showEditShade(true);
get('btnSaveShade').style.display = 'flex';
get('btnLinkRemote').style.display = '';
if (shade.paired) {
get('btnUnpairShade').style.display = 'flex';
get('btnPairShade').style.display = 'none';
}
else {
get('btnPairShade').style.display = 'flex';
get('btnUnpairShade').style.display = 'none';
}
this.setLinkedRemotesList(shade);
closeOverlay(div);
}
});
}
_shWiz(shadeId, isUnpair) {
const sType = parseInt(get('somfyShade').getAttribute('data-shadetype'), 10);
const isG = (sType === 5 || sType === 6);
const pre = isUnpair ? 'UNPAIR' : 'PAIR';
const dev = isG ? 'GARAGE' : 'SHADE';
const progId = isUnpair ? 'btnSendUnpairing' : 'btnSendPairing';
const stopId = isUnpair ? 'btnStopUnpairing' : 'btnStopPairing';
const sucBtnId = isUnpair ? 'btnUnpairShade' : 'btnPairShade';
const sucVal = isUnpair ? 0 : 1;
const focusVal = isUnpair ? 1 : 0;
const sucAction = `somfy.setPaired(${shadeId},${sucVal});ui.setFocus('${sucBtnId}',${focusVal});closeOverlay(get('divPairing'));`;
const descKey = `${pre}_${dev}_DESC`;
const stepTitles = ["WIZ_TITLE_STEP1", `${pre}_TITLE_STEP2`, "WIZ_TITLE_STEP3"];
const t = (s, l) => {
const sk = `${pre}_${dev}_STEP_${s}_${l}`, fk = `WIZ_${dev}_STEP_${s}_${l}`, r = tr(sk);
return (r === sk) ? tr(fk) : r;
};
const it = (n, s, l) => `<div class="step-item"><div class="step-number">${n}</div><div class="step-text">${t(s, l)}</div></div>`;
const txt = (s, l) => `<div class="step-text">${t(s, l)}</div>`;
const inf = (s, l) => `
        <div class="information wizard-step" data-stepid="${s}"><div class="information-header"><svg><use href="#svg-info"></use></svg><b>${tr("MSG_NOTE")}</b></div><div class="information-text"><span>${t(s, l)}</span></div></div>`;
let div = document.createElement('div');
div.className = `inst-overlay wizard${ui.isExpertMode ? ' is-expert' : ''}`;
div.id = 'divPairing';
div.setAttribute('data-stepid', '1');
div.setAttribute('data-type', 'link-remote');
div.setAttribute('data-shadeid', shadeId);
div.innerHTML = `
        <div class="instructions-content">

        ${overlayHeader(isUnpair ? "UNPAIR_TITLE" : "PAIR_TITLE", descKey, isG ? "svg-simpleGarage" : "svg-simpleShutter", {
subtitle: false,
showInfo: true,
showExpert: true
})}

        <div class="overlay-scroll-content">

        ${wizardStepper(stepTitles)}
        <div class="blocsteps">
        <div class="uniblocStep wizard-step" data-stepid="1">
        ${it('a', 1, 1)} ${it('b', 1, 2)} ${isG ? it('c', 1, 3) : ''}
        </div>
        ${!isG ? inf(1, 3) : ''}
        <div class="button-container-col wizard-step marginB25" data-expert data-stepid="2">
        <button id="${progId}" type="button">${tr("BT_PROG")}</button>
        </div>
        <div class="uniblocStep wizard-step" data-stepid="2">
        ${it('a', 2, 1)} ${it('b', 2, 2)} ${!isG ? it('c', 2, 3) : ''}
        </div>
        ${!isG ? inf(2, 4) : ''}
        <div class="button-container-col wizard-step marginB25" data-expert data-stepid="0">
        <button id="btnWizMarkSuc" type="button" class="btn-success" onclick="${sucAction}">${tr("BT_SAVE")}</button>
        </div>
        <div class="empty-state wizard-step" data-stepid="3"><svg class="empty-icon"><use href=#svg-succes></use></svg></div>
        <div class="uniblocStep wizard-step" data-stepid="3">${txt(3, 1)}</div>
        </div>
        </div>
        <div class="hrDivFooter-Instruc"></div>
        <div class="expert-only-buttons" data-expert>
        <button type="button" line onclick="const o=this.closest('.inst-overlay'); requestCloseOverlay(o);">${tr("BT_CANCEL_1")}</button>
        </div>
        <div class="button-container-overlay">
        <button id="${stopId}" class="wizard-step" data-stepid="1" line type="button">${tr("BT_CLOSE")}</button>
        <button id="btnWizPrev" class="wizard-step" data-mstepid="2,3" line type="button" onclick="ui.wizSetPrevStep(this.closest('.wizard'));">${tr("BT_GO_BACK")}</button>
        <button id="btnWizNext" class="wizard-step" data-mstepid="1,2" type="button" onclick="ui.wizSetNextStep(this.closest('.wizard'));">${tr("BT_NEXT")}</button>
        <button id="btnWizMarkSuc" class="wizard-step btn-success" data-stepid="3" type="button" onclick="${sucAction}">${tr("BT_SAVE")}</button>
        </div>
        </div>`;
const clearT = () => { if (this.btnTimer) { clearInterval(this.btnTimer); this.btnTimer = null; } };
const fnRep = (err, shade) => {
clearT();
if (!err && mouseDown) somfy.sendCommandRepeat(shadeId, 'prog', null, fnRep);
};
let btnProg = div.querySelector(`#${progId}`);
if (btnProg) {
const onP = (evt) => { if (!isPrimaryPress(evt)) return; somfy.sendCommand(shadeId, 'prog', null, fnRep); };
btnProg.addEventListener('mousedown', onP, true);
btnProg.addEventListener('touchstart', (e) => { e.preventDefault(); onP(); }, true);
}
div.querySelectorAll(`#${stopId}`).forEach(btn => {
btn.onclick = () => requestCloseOverlay(div, clearT);
});
markCriticalStepReached(div, 2);
ui.wizSetStep(div, 1);
shOverlay(div, clearT);
return div;
}
pairShade(shadeId) {
return this._shWiz(shadeId, false);
}
unpairShade(shadeId) {
return this._shWiz(shadeId, true);
}
openCalibrationWizard() {
const g = get;
const shadeId = parseInt(g('spanShadeId').innerText, 10);
if (isNaN(shadeId)) return;
const shadeType = parseInt(g('somfyShade').getAttribute('data-shadetype'), 10);
const st = this.shadeTypes.find(x => x.type === shadeType) || {};
if (!st.lift && !st.tilt) return;
const showTiltQuestion = !!st.tilt;
let tiltType = g('selTiltType') ? parseInt(g('selTiltType').value, 10) : 0;
let steps = [];
let totalSteps = 0;
const measured = {};
const CAL_MIN_DURATION_MS = 500;
const CAL_MAX_DURATION_MS = 180000;
const CAL_ADJUST_STEP_MS = 100;
const buildSteps = (tt) => {
const hasLift = !!st.lift && tt !== 3;
const hasTilt = tt > 0;
const isIntegrated = tt === 2;
const arr = [{ key: 'intro', titleKey: 'CAL_STEP_INTRO' }];
if (hasLift) arr.push({ key: 'up', titleKey: 'CAL_STEP_UP', field: 'upTime', tilt: false, dir: 'Up', instrKey: 'CAL_UP_INSTRUCTION', prepKey: 'CAL_UP_PREP', prepCmd: 'Down' });
if (hasLift) arr.push({ key: 'down', titleKey: 'CAL_STEP_DOWN', field: 'downTime', tilt: false, dir: 'Down', instrKey: 'CAL_DOWN_INSTRUCTION', prepKey: 'CAL_DOWN_PREP', prepCmd: 'Up' });
if (hasTilt) arr.push({ key: 'tiltUp', titleKey: 'CAL_STEP_TILT_UP', field: 'tiltTimeUp', tilt: true, dir: 'Up', instrKey: isIntegrated ? 'CAL_TILT_UP_INSTRUCTION_INTEGRATED' : 'CAL_TILT_UP_INSTRUCTION', prepKey: 'CAL_TILT_UP_PREP', prepCmd: 'Down' });
if (hasTilt) arr.push({ key: 'tiltDown', titleKey: 'CAL_STEP_TILT_DOWN', field: 'tiltTimeDown', tilt: true, dir: 'Down', instrKey: isIntegrated ? 'CAL_TILT_DOWN_INSTRUCTION_INTEGRATED' : 'CAL_TILT_DOWN_INSTRUCTION', prepKey: 'CAL_TILT_DOWN_PREP', prepCmd: 'Up' });
if (isIntegrated) arr.push({ key: 'order', titleKey: 'CAL_STEP_ORDER' });
arr.push({ key: 'summary', titleKey: 'CAL_STEP_SUMMARY' });
return arr;
};
const blindOptions = [
{ v: 0, key: 'NONE' },
{ v: 1, key: 'TILTMOTOR' },
{ v: 2, key: 'INTEGRATED' },
{ v: 3, key: 'TILTONLY' },
{ v: 4, key: 'EUROMODE' }
];
const introStepHtml = (n) => `
        <div class="uniblocStep wizard-step" data-stepid="${n}">
            <div class="information"><div class="information-text"><span>${tr('CAL_INTRO_TEXT')}</span></div></div>
            ${showTiltQuestion ? `
            <h3 class="unibloc-title" style="margin-top:16px;">${tr('CAL_BLIND_Q_TITLE')}</h3>
            ${blindOptions.map(o => `
            <label class="uniRow dirty-target" for="calBlindType${o.v}">
                <div class="uniLeft">
                    <div class="uniText">
                        <div class="uniLabel">${tr('CAL_BLIND_OPT_' + o.key)}</div>
                        <div class="uniStatus">${tr('CAL_BLIND_OPT_' + o.key + '_DESC')}</div>
                    </div>
                </div>
                <div class="uniRight"><input type="radio" name="calBlindType" id="calBlindType${o.v}" value="${o.v}" ${o.v === tiltType ? 'checked' : ''}></div>
            </label>`).join('')}` : ''}
        </div>`;
const measureStepHtml = (n, s) => `
        <div class="uniblocStep wizard-step" data-stepid="${n}">
            <div class="information">
                <div class="information-header"><svg><use href="#svg-info"></use></svg><b>${tr('MSG_NOTE')}</b></div>
                <div class="information-text"><span>${tr(s.instrKey)}</span></div>
            </div>
            <div class="button-container-col marginB25">
                <button type="button" line data-cal-prep="${s.key}">${tr(s.prepKey)}</button>
            </div>
            <div class="cal-timer" data-cal-timer="${s.key}" style="font-size:2.2em;font-variant-numeric:tabular-nums;text-align:center;margin:10px 0;">0.0 s</div>
            <div class="button-container-col">
                <button type="button" class="btn-success" data-cal-start="${s.key}">${tr('BT_START')}</button>
                <button type="button" class="btn-success" data-cal-stop="${s.key}" style="display:none;">${tr('BT_STOP')}</button>
                <button type="button" line data-cal-cancel="${s.key}" style="display:none;">${tr('BT_CANCEL')}</button>
            </div>
            <div class="step-text" data-cal-result="${s.key}" style="display:none;text-align:center;margin-top:8px;"></div>
            <div data-cal-adjust="${s.key}" style="display:none;text-align:center;margin-top:6px;">
                <div class="uniStatus" style="margin-bottom:6px;">${tr('CAL_ADJUST_INTRO')}</div>
                <div class="button-container-row" style="justify-content:center;gap:8px;">
                    <button type="button" line data-cal-adjust-dir="early" title="${tr('CAL_ADJUST_TOO_EARLY_DESC')}">${tr('CAL_ADJUST_TOO_EARLY')}</button>
                    <button type="button" line data-cal-adjust-dir="late" title="${tr('CAL_ADJUST_TOO_LATE_DESC')}">${tr('CAL_ADJUST_TOO_LATE')}</button>
                </div>
            </div>
        </div>`;
const orderStepHtml = (n) => `
        <div class="uniblocStep wizard-step" data-stepid="${n}">
            <div class="information">
                <div class="information-header"><svg><use href="#svg-info"></use></svg><b>${tr('MSG_NOTE')}</b></div>
                <div class="information-text"><span>${tr('CAL_ORDER_INTRO')}</span></div>
            </div>
            <div class="button-container-col marginB25"><button type="button" line data-cal-test="open">${tr('CAL_ORDER_TEST_OPEN')}</button></div>
            <label class="uniRow dirty-target" for="calTiltFirstOnOpen">
                <div class="uniLeft">
                    <div class="uniblocSvg-S"><svg><use href="#svg-upTime"></use></svg></div>
                    <div class="uniText">
                        <div class="uniLabel">${tr('CAL_ORDER_QUESTION_OPEN')}</div>
                        <div class="uniStatus">${tr('CAL_ORDER_QUESTION_OPEN_DESC')}</div>
                    </div>
                </div>
                <div class="uniRight"><span class="switch"><input id="calTiltFirstOnOpen" type="checkbox"/><div></div></span></div>
            </label>
            <div class="button-container-col marginB25"><button type="button" line data-cal-test="close">${tr('CAL_ORDER_TEST_CLOSE')}</button></div>
            <label class="uniRow dirty-target" for="calTiltFirstOnClose">
                <div class="uniLeft">
                    <div class="uniblocSvg-S"><svg><use href="#svg-downTime"></use></svg></div>
                    <div class="uniText">
                        <div class="uniLabel">${tr('CAL_ORDER_QUESTION_CLOSE')}</div>
                        <div class="uniStatus">${tr('CAL_ORDER_QUESTION_CLOSE_DESC')}</div>
                    </div>
                </div>
                <div class="uniRight"><span class="switch"><input id="calTiltFirstOnClose" type="checkbox"/><div></div></span></div>
            </label>
        </div>`;
const summaryStepHtml = (n) => `
        <div class="uniblocStep wizard-step" data-stepid="${n}">
            <div class="empty-state"><svg class="empty-icon"><use href="#svg-succes"></use></svg></div>
            <div class="step-text">${tr('CAL_SUMMARY_TEXT')}</div>
            <div id="calSummaryTable" style="margin:10px 0;"></div>
        </div>`;
const bodyHtml = () => {
let idx = 0;
return steps.map((s) => {
idx++;
if (s.key === 'intro') return introStepHtml(idx);
if (s.key === 'order') return orderStepHtml(idx);
if (s.key === 'summary') return summaryStepHtml(idx);
return measureStepHtml(idx, s);
}).join('');
};
let div = document.createElement('div');
div.className = 'inst-overlay wizard';
div.id = 'divCalibration';
div.setAttribute('data-stepid', '1');
div.setAttribute('data-type', 'calibration');
div.setAttribute('data-shadeid', shadeId);
div.innerHTML = `
        <div class="instructions-content">
        ${overlayHeader('CAL_TITLE', 'CAL_DESC', 'svg-simpleShutter', { showInfo: true })}
        <div class="overlay-scroll-content"></div>
        <div class="hrDivFooter-Instruc"></div>
        <div class="button-container-overlay">
        <button id="btnCalClose" class="wizard-step" data-stepid="1" line type="button">${tr('BT_CLOSE')}</button>
        <button id="btnCalPrev" class="wizard-step" line type="button" onclick="ui.wizSetPrevStep(this.closest('.wizard'));">${tr('BT_GO_BACK')}</button>
        <button id="btnCalNext" class="wizard-step" type="button">${tr('BT_NEXT')}</button>
        <button id="btnCalSave" class="wizard-step btn-success" type="button">${tr('BT_SAVE')}</button>
        </div>
        </div>`;
const scrollContent = div.querySelector('.overlay-scroll-content');
const btnPrev = div.querySelector('#btnCalPrev');
const btnNext = div.querySelector('#btnCalNext');
const btnSave = div.querySelector('#btnCalSave');
const btnClose = div.querySelector('#btnCalClose');
const setNavLocked = (locked) => {
[btnPrev, btnNext, btnClose, btnSave].forEach(btn => { if (btn) btn.disabled = locked; });
};
const fieldLabelKeys = { upTime: 'SHADE_UP_TIME', downTime: 'SHADE_DOWN_TIME', tiltTimeUp: 'SHADE_TILT_TIME_UP', tiltTimeDown: 'SHADE_TILT_TIME_DOWN' };
const buildSummary = () => {
const tbl = div.querySelector('#calSummaryTable');
if (!tbl) return;
const cbOpen = div.querySelector('#calTiltFirstOnOpen');
const cbClose = div.querySelector('#calTiltFirstOnClose');
let html = '';
Object.keys(measured).forEach(field => {
html += `<div class="uniRow"><div class="uniLabel">${tr(fieldLabelKeys[field])}</div><div>${(measured[field] / 1000).toFixed(1)} s</div></div>`;
});
if (steps.some(s => s.key === 'order')) {
html += `<div class="uniRow"><div class="uniLabel">${tr('CAL_ORDER_QUESTION_OPEN')}</div><div>${(cbOpen && cbOpen.checked) ? tr('BT_YES') : tr('BT_NO')}</div></div>`;
html += `<div class="uniRow"><div class="uniLabel">${tr('CAL_ORDER_QUESTION_CLOSE')}</div><div>${(cbClose && cbClose.checked) ? tr('BT_YES') : tr('BT_NO')}</div></div>`;
}
tbl.innerHTML = html || `<div class="step-text">${tr('CAL_SUMMARY_EMPTY')}</div>`;
};
div.addEventListener('stepchanged', (e) => { if (e.detail.newStep === totalSteps) buildSummary(); });
const renderSteps = () => {
steps = buildSteps(tiltType);
totalSteps = steps.length;
scrollContent.innerHTML = `${wizardStepper(steps.map(s => s.titleKey))}<div class="blocsteps">${bodyHtml()}</div>`;
const prevSteps = [], nextSteps = [];
for (let i = 2; i <= totalSteps; i++) prevSteps.push(i);
for (let i = 1; i < totalSteps; i++) nextSteps.push(i);
btnPrev.setAttribute('data-mstepid', prevSteps.join(','));
btnNext.setAttribute('data-mstepid', nextSteps.join(','));
btnSave.setAttribute('data-stepid', String(totalSteps));
const stepperWrap = scrollContent.querySelector('.stepper-wrapper');
if (stepperWrap) {
if (showTiltQuestion) stepperWrap.setAttribute('data-mstepid', prevSteps.join(','));
else stepperWrap.removeAttribute('data-mstepid');
}
div.querySelectorAll('[data-cal-prep]').forEach(btn => {
const s = steps.find(x => x.key === btn.getAttribute('data-cal-prep'));
btn.onclick = () => { if (s.tilt) somfy.sendTiltCommand(shadeId, s.prepCmd); else somfy.sendCommand(shadeId, s.prepCmd); };
});
div.querySelectorAll('[data-cal-start]').forEach(startBtn => {
const key = startBtn.getAttribute('data-cal-start');
const s = steps.find(x => x.key === key);
const stopBtn = div.querySelector(`[data-cal-stop="${key}"]`);
const cancelBtn = div.querySelector(`[data-cal-cancel="${key}"]`);
const timerEl = div.querySelector(`[data-cal-timer="${key}"]`);
const resultEl = div.querySelector(`[data-cal-result="${key}"]`);
const adjustRow = div.querySelector(`[data-cal-adjust="${key}"]`);
const applyAdjust = (deltaMs) => {
const cur = measured[s.field];
if (typeof cur === 'undefined') return;
const next = Math.max(CAL_MIN_DURATION_MS, Math.min(CAL_MAX_DURATION_MS, cur + deltaMs));
measured[s.field] = next;
timerEl.textContent = (next / 1000).toFixed(1) + ' s';
resultEl.textContent = `${tr('CAL_RESULT_LABEL')} ${(next / 1000).toFixed(1)} s`;
};
if (adjustRow) {
const btnEarly = adjustRow.querySelector('[data-cal-adjust-dir="early"]');
const btnLate = adjustRow.querySelector('[data-cal-adjust-dir="late"]');
if (btnEarly) btnEarly.onclick = () => applyAdjust(CAL_ADJUST_STEP_MS);
if (btnLate) btnLate.onclick = () => applyAdjust(-CAL_ADJUST_STEP_MS);
}
let iv = null;
const endMeasurement = () => {
clearInterval(iv);
stopBtn.style.display = 'none';
if (cancelBtn) cancelBtn.style.display = 'none';
startBtn.style.display = '';
setNavLocked(false);
};
startBtn.onclick = () => {
const t0 = Date.now();
resultEl.style.display = 'none';
if (adjustRow) adjustRow.style.display = 'none';
startBtn.style.display = 'none';
stopBtn.style.display = '';
if (cancelBtn) cancelBtn.style.display = '';
setNavLocked(true);
iv = setInterval(() => { timerEl.textContent = ((Date.now() - t0) / 1000).toFixed(1) + ' s'; }, 100);
if (s.tilt) somfy.sendTiltCommand(shadeId, s.dir); else somfy.sendCommand(shadeId, s.dir);
if (cancelBtn) cancelBtn.onclick = () => {
if (s.tilt) somfy.sendTiltCommand(shadeId, 'My'); else somfy.sendCommand(shadeId, 'My');
endMeasurement();
timerEl.textContent = '0.0 s';
resultEl.style.display = '';
resultEl.style.color = '';
resultEl.textContent = tr('CAL_MEASURE_CANCELLED');
if (adjustRow) adjustRow.style.display = 'none';
startBtn.textContent = tr(typeof measured[s.field] !== 'undefined' ? 'CAL_BTN_REDO' : 'BT_START');
};
stopBtn.onclick = () => {
const elapsedMs = Date.now() - t0;
if (s.tilt) somfy.sendTiltCommand(shadeId, 'My'); else somfy.sendCommand(shadeId, 'My');
endMeasurement();
timerEl.textContent = (elapsedMs / 1000).toFixed(1) + ' s';
resultEl.style.display = '';
if (elapsedMs < CAL_MIN_DURATION_MS || elapsedMs > CAL_MAX_DURATION_MS) {
resultEl.style.color = 'var(--color-danger)';
resultEl.textContent = elapsedMs < CAL_MIN_DURATION_MS ? tr('CAL_ERR_DURATION_TOO_SHORT') : tr('CAL_ERR_DURATION_TOO_LONG');
if (adjustRow) adjustRow.style.display = 'none';
startBtn.textContent = tr(typeof measured[s.field] !== 'undefined' ? 'CAL_BTN_REDO' : 'BT_START');
return;
}
measured[s.field] = elapsedMs;
resultEl.style.color = '';
resultEl.textContent = `${tr('CAL_RESULT_LABEL')} ${(elapsedMs / 1000).toFixed(1)} s`;
if (adjustRow) adjustRow.style.display = '';
startBtn.textContent = tr('CAL_BTN_REDO');
};
};
});
const cbOpen = div.querySelector('#calTiltFirstOnOpen');
const cbClose = div.querySelector('#calTiltFirstOnClose');
if (cbOpen) cbOpen.checked = g('cbTiltFirstOnOpen') ? g('cbTiltFirstOnOpen').checked : true;
if (cbClose) cbClose.checked = g('cbTiltFirstOnClose') ? g('cbTiltFirstOnClose').checked : true;
div.querySelectorAll('[data-cal-test]').forEach(btn => {
const which = btn.getAttribute('data-cal-test');
btn.onclick = () => {
somfy.sendCommand(shadeId, which === 'open' ? 'Up' : 'Down');
setTimeout(() => somfy.sendCommand(shadeId, 'My'), 1000);
};
});
};
renderSteps();
let lastTiltType = tiltType;
btnNext.onclick = () => {
if (showTiltQuestion && ui.wizCurrentStep(div) === 1) {
const picked = div.querySelector('input[name="calBlindType"]:checked');
tiltType = picked ? parseInt(picked.value, 10) : tiltType;
if (tiltType !== lastTiltType) {
Object.keys(measured).forEach(k => delete measured[k]);
lastTiltType = tiltType;
}
renderSteps();
}
ui.wizSetNextStep(div);
};
btnSave.onclick = () => {
const obj = { shadeId: shadeId };
Object.assign(obj, measured);
if (showTiltQuestion) obj.tiltType = tiltType;
const cbOpen = div.querySelector('#calTiltFirstOnOpen');
const cbClose = div.querySelector('#calTiltFirstOnClose');
if (cbOpen) obj.tiltFirstOnOpen = cbOpen.checked;
if (cbClose) obj.tiltFirstOnClose = cbClose.checked;
putJSON('/saveShade', obj, (err, shade) => {
if (err) return ui.errorMessage(div, tr('CAL_ERR_SAVE'));
['upTime', 'downTime', 'tiltTimeUp', 'tiltTimeDown'].forEach((f) => {
const el = g({ upTime: 'fldShadeUpTime', downTime: 'fldShadeDownTime', tiltTimeUp: 'fldTiltTimeUp', tiltTimeDown: 'fldTiltTimeDown' }[f]);
if (el && typeof shade[f] !== 'undefined') el.value = Math.round(shade[f] / 100) / 10;
});
if (g('cbTiltFirstOnOpen') && typeof shade.tiltFirstOnOpen !== 'undefined') g('cbTiltFirstOnOpen').checked = shade.tiltFirstOnOpen;
if (g('cbTiltFirstOnClose') && typeof shade.tiltFirstOnClose !== 'undefined') g('cbTiltFirstOnClose').checked = shade.tiltFirstOnClose;
if (showTiltQuestion && g('selTiltType') && typeof shade.tiltType !== 'undefined') {
g('selTiltType').value = shade.tiltType;
somfy.onShadeTypeChanged(g('selTiltType'));
}
somfy.updateCalibrationSummary();
div.removeAttribute('data-radio-committed');
closeOverlay(div);
});
};
btnClose.onclick = () => requestCloseOverlay(div);
markCriticalStepReached(div, 2);
ui.wizSetStep(div, 1);
shOverlay(div);
return div;
}
commitSliderTarget(el, shadeId, isTilt) {
sliderDragEnd(el);
const target = parseInt(el.value, 10);
if (isTilt) this.sendTiltCommand(shadeId, target);
else this.sendCommand(shadeId, target);
const real = parseInt(el.dataset.realpos, 10);
if (!isNaN(real)) {
el.value = real;
syncSliderProgress(el);
}
}
sendCommand(shadeId, command, repeat, cb) {
let obj = {};
if (typeof shadeId.shadeId !== 'undefined') {
obj = shadeId;
cb = command;
shadeId = obj.shadeId;
repeat = obj.repeat;
command = obj.command;
}
else {
obj = { shadeId: shadeId };
if (isNaN(parseInt(command, 10))) obj.command = command;
else obj.target = parseInt(command, 10);
if (typeof repeat === 'number') obj.repeat = parseInt(repeat);
}
logger.debug('Sending shade command:', obj);
putJSON('/shadeCommand', obj, (err, shade) => {
if (typeof cb === 'function') cb(err, shade);
});
}
sendCommandRepeat(shadeId, command, repeat, cb) {
let obj = {};
if (typeof shadeId.shadeId !== 'undefined') {
obj = shadeId;
cb = command;
shadeId = obj.shadeId;
repeat = obj.repeat;
command = obj.command;
}
else {
obj = { shadeId: shadeId, command: command };
if (typeof repeat === 'number') obj.repeat = parseInt(repeat);
}
putJSON('/repeatCommand', obj, (err, shade) => {
if (typeof cb === 'function') cb(err, shade);
});
}
sendTiltCommand(shadeId, command, cb) {
logger.debug(`Sending Tilt command ${shadeId}-${command}`);
if (isNaN(parseInt(command, 10)))
putJSON('/tiltCommand', { shadeId: shadeId, command: command }, (err, shade) => {
if (typeof cb === 'function') cb(err, shade);
});
else
putJSON('/tiltCommand', { shadeId: shadeId, target: parseInt(command, 10) }, (err, shade) => {
if (typeof cb === 'function') cb(err, shade);
});
}
unlinkRemote(shadeId, remoteAddress) {
let prompt = ui.promptMessage(tr('PROMPT_UNLINK_REMOTE'), () => {
let obj = {
shadeId: shadeId,
remoteAddress: remoteAddress
};
putJSONSync('/unlinkRemote', obj, (err, shade) => {
logger.debug('Remote unlinked:', shade);
prompt.remove();
this.setLinkedRemotesList(shade);
});
});
}
setGroupsList(groups) {
this.groups = groups;
let divCfg = '';
let divCtl = '';
let roomId = document.querySelector('.room-pill.active') ? parseInt(document.querySelector('.room-pill.active').getAttribute('data-roomid'), 10) : 0;
if (typeof groups !== 'undefined') {
groups.sort((a, b) => a.sortOrder - b.sortOrder);
for (let i = 0; i < groups.length; i++) {
let group = groups[i];
let room = _rooms.find(x => x.roomId === group.roomId) || { roomId: 0, name: '' };
let memberCount = typeof group.linkedShades !== 'undefined' ? group.linkedShades.length : 0;
let isSunActive = (group.flags & 0x01) ? 'true' : 'false';
let equipmentText = memberCount > 1 ? `${memberCount} équipements associés` : `${memberCount} équipement associé`;
divCfg += `<div class="somfyGroup group-draggable" draggable="true" data-roomid="${group.roomId}" data-groupid="${group.groupId}" data-remoteaddress="${group.remoteAddress}" onclick="somfy.openEditGroup(${group.groupId});"><div class="drag-handle" onclick="event.stopPropagation();"><svg class="icon-svg"><use href=#svg-drag></use></svg></div><div class="shade-icon-wrapper"><svg><use href="#svg-group"></use></svg></div><div class="group-name"><div class="name-text">${escHtml(group.name)}</div><div class="cfg-room">${escHtml(room.name)}</div></div><div class="idRemoteAddress"><span class="AddrId-label">${tr("ID")}</span><span class="group-address">${group.remoteAddress}</span></div><div class="divEditDelete-svg btn-card-remote" title="${tr("SUBTAB_VIRTUAL_REMOTE_S")}" onclick="event.stopPropagation(); somfy.openVirtualRemote('group', ${group.groupId});"><svg class="icon-svg"><use href="#svg-remote"></use></svg></div><div class="divEditDelete-svg" onclick="event.stopPropagation(); somfy.deleteGroup(${group.groupId});"><svg class="icon-svg" style="color: var(--color-danger);"><use href=#svg-trash></use></svg></div></div>`;
divCtl += `<div class="somfyGroupCtl" style="${roomId === 0 || roomId === room.roomId ? '' : 'display:none'}" data-groupid="${group.groupId}" data-roomid="${group.roomId}" data-remoteaddress="${group.remoteAddress}">


                <div class="dash-card-content">

                <!-- Ligne 1 : En-tête -->
                <div class="dash-card-header">

                <div class="group-icon">
                <div class="group-icon-wrapper">
                    <svg width="22" height="22"><use href="#svg-group"></use></svg>
                </div>
                </div>
                <div class="group-name">

                <span class="groupctl-name">${escHtml(group.name)}</span>
                <span class="groupctl-room">${escHtml(room.name)}</span>
                <div class="groupctl-shades">
                <span>${equipmentText}</span>
                </div>
                </div>

                <div class="header-actions">
                <div class="button-remote" title="${tr("SUBTAB_VIRTUAL_REMOTE_S")}" onclick="event.stopPropagation(); somfy.openVirtualRemote('group', ${group.groupId});">
                <svg><use href="#svg-remote-badge"></use></svg>
                </div>
                </div>
                </div>

                <!-- BOUTONS DE COMMANDE GLOBALE -->
                <div class="groupctl-buttons">
                <div class="button-outline cmd-button btn-somfy-svg animScale" data-cmd="up" data-groupid="${group.groupId}" title="${tr("BT_OPEN")}">
                <svg><use href="#svg-up"></use></svg>
                </div>
                <div class="button-outline cmd-button btn-somfy-svg animScale" data-cmd="my" data-groupid="${group.groupId}" title="${tr("BT_MY")}">
                <svg><use href="#svg-my"></use></svg>
                </div>
                <div class="button-outline cmd-button btn-somfy-svg animScale" data-cmd="down" data-groupid="${group.groupId}" title="${tr("BT_CLOSE")}">
                <svg><use href="#svg-down"></use></svg>
                </div>
                <div class="button-sunflag cmd-button btn-somfy-svg animScale" data-cmd="sunflag" data-groupid="${group.groupId}" data-on="${isSunActive}" style="${!group.sunSensor ? 'display:none' : ''}" title="${tr("VR_SUN_FLAG")}">
                <svg width="18" height="18"><use href="#vr-sunflag-o"></use></svg>
                </div>
                </div>

                <!-- FOOTER : CAPTEURS ET INDICATEURS -->
                <!-- Le menu descend ici, comme sur la carte équipement : l'en-tête ne garde que la
                     télécommande, en badge du même gabarit que le soleil et le favori. -->
                <div class="group-footer">
                <div class="sensor-indicators">
                <div class="group-sensor-item schedule-indicator no-schedule" data-schedule-target="group" data-schedule-id="${group.groupId}">
                <svg width="16" height="16"><use href="#svg-horloge"></use></svg>
                </div>
                </div>
                <div class="groupctl-status-right">
                <div class="button-menu" title="${tr("OPTION")}" onclick="event.stopPropagation(); somfy.openEditGroup(${group.groupId});">
                <svg width="18" height="18"><use href="#svg-menuVertical"></use></svg>
                </div>
                </div>
                </div>

                </div>
                </div>`;
}
}
this.syncVRLayout();
get('divGroupList').innerHTML = divCfg;
let groupControls = get('divGroupControls');
groupControls.innerHTML = divCtl;
this.checkEmptyState();
let btns = groupControls.querySelectorAll('div.cmd-button');
for (let i = 0; i < btns.length; i++) {
btns[i].addEventListener('click', (event) => {
let groupId = parseInt(event.currentTarget.getAttribute('data-groupid'), 10);
let cmd = event.currentTarget.getAttribute('data-cmd');
if (cmd === 'sunflag') {
if (makeBool(event.currentTarget.getAttribute('data-on')))
this.sendGroupCommand(groupId, 'flag');
else
this.sendGroupCommand(groupId, 'sunflag');
}
else
this.sendGroupCommand(groupId, cmd);
}, true);
}
this.updateRoomCounts();
this.setListDraggable(get('divGroupList'), '.group-draggable', (list) => {
let items = list.querySelectorAll('.group-draggable');
let order = [];
for (let i = 0; i < items.length; i++) {
order.push(parseInt(items[i].getAttribute('data-groupid'), 10));
}
putJSONSync('/groupSortOrder', order, (err) => {
for (let i = order.length - 1; i >= 0; i--) {
let el = groupControls.querySelector(`.somfyGroupCtl[data-groupid="${order[i]}"`);
if (el) {
groupControls.prepend(el);
}
}
});
});
this._syncScheduleIndicators();
}
setLinkedShadesList(group) {
const container = get('divLinkedShadeList');
const btnContainer = get('divSomfyGroupButtons');
const btnLink = get('btnLinkShade');
const shades = group.linkedShades || [];
if (shades.length === 0) {
container.innerHTML = '';
container.style.display = 'none';
} else {
container.style.display = 'block';
}
const hasShades = shades.length > 0;
if (btnContainer) {
if (!hasShades) {
btnContainer.classList.add('disabled');
} else {
btnContainer.classList.remove('disabled');
}
}
ui.setFocus(btnLink, !hasShades);
if (!hasShades) return;
let html = `<div class="linkedRheader">${tr("GROUP_LINKED_S")}</div>`;
html += `<div class="linkedScrollArea">`;
html += shades.map((shade, i) => {
const st = this.shadeTypes.find(x => x.type === shade.shadeType) || { type: shade.shadeType, ico: 'svg-window-shade', indic: 'svg-indicRoller' };
return `
        <div class="somfyLinkedRemote linkedShadeCard" data-shadeid="${shade.shadeId}" data-remoteaddress="${shade.remoteAddress}">
        <div class="shade-icon-wrapper"><svg><use href="#${st.indic}"></use></svg></div><div class="shade-name"><div class="name-text">${escHtml(shade.name)}</div></div><div class="idRemoteAddress"><span class="AddrId-label">id:</span><span class="shade-address">${shade.remoteAddress}</span></div><div class="divEditDelete-svg" onclick="somfy.unlinkGroupShade(${group.groupId}, ${shade.shadeId});"><svg class="icon-svg" style="color: var(--color-danger);"><use href=#svg-unlink></use></svg></div></div>
        `;
}).join('');
html += `</div>`;
container.innerHTML = html;
}
procGroupState(state) {
logger.debug('Group state update:', state);
if (this._vrTarget && this._vrTarget.type === 'group' && this._vrTarget.id === state.groupId) {
this.setVRSunFlag(state.flags);
this.setVRSunSensor(!!state.sunSensor);
}
let flags = document.querySelectorAll(`.button-sunflag[data-groupid="${state.groupId}"]`);
for (let i = 0; i < flags.length; i++) {
flags[i].style.display = state.sunSensor ? '' : 'none';
flags[i].setAttribute('data-on', (state.flags & 0x01) === 0x01 ? 'true' : 'false');
}
}
showEditGroup(bShow) {
let el = get('divLinkRepeater');
if (el) el.remove();
el = get('divPairing');
if (el) el.remove();
el = get('divRollingCode');
if (el) el.remove();
el = get('divRemotesOverlay');
if (el) el.remove();
el = get('somfyGroup');
if (el) el.style.display = bShow ? '' : 'none';
el = get('divGroupListContainer');
if (el) el.style.display = bShow ? 'none' : '';
if (!bShow) {
clearDirty();
routeSetEditor('divSomfyGroups', null);
}
if (bShow) {
this.showEditRoom(false);
this.showEditShade(false);
}
}
openEditGroup(groupId, opts) { confirmDiscardChanges(() => this._openEditGroup(groupId, opts)); }
_openEditGroup(groupId, opts) {
const g = get,
isNew = groupId === undefined,
elGroup = g('somfyGroup'),
btnLink = g('btnLinkShade'),
btnSave = g('btnSaveGroup'),
btnContainer = g('divSomfyGroupButtons'),
divLinkedShades = g('divLinkedShadeList'),
blocPairParent = g('blocPairGroup');
if (isNew && this.groups?.length >= 14) {
routeSetEditor('divSomfyGroups', null, { replace: true });
return ui.errorMessage(g('divSomfySettings'), tr('ERR_GROUP_LIMIT_REACHED'));
}
const s = (idOrElem, d) => { const e = (typeof idOrElem === 'string') ? g(idOrElem) : idOrElem; if(e) e.style.display = d; };
this.applyLedFeedbackVisibility();
this.relayoutOptionGrids();
divLinkedShades.innerHTML = '';
s(btnContainer, 'flex');
btnContainer?.classList.toggle('disabled', isNew);
s(btnLink, 'none');
s(btnSave, 'none');
s(blocPairParent, 'none');
s(divLinkedShades, 'none');
s('divScheduleSectionGroup', isNew ? 'none' : 'flex');
getJSONSync(isNew ? '/getNextGroup' : `/group?groupId=${groupId}`, (err, group) => {
if (err) {
routeSetEditor('divSomfyGroups', null, { replace: true });
return (opts && opts.silentError) ? undefined : ui.serviceError(err);
}
if (isNew) {
Object.assign(group, {
name: '', flipCommands: false, shades: []
});
}
if (!isNew) {
s(btnLink, 'flex');
s(blocPairParent, 'flex');
s(divLinkedShades, 'block');
const hasShades = (group.shades && group.shades.length > 0);
btnContainer?.classList.toggle('disabled', !hasShades);
ui.setFocus(btnLink, !isNew && !hasShades);
this.setLinkedShadesList(group);
this.updateScheduleList(() => this.renderScheduleBadges('divGroupScheduleBadges', 'group', groupId));
}
const hTitle = g('somfyGroupHeaderTitle'), hDesc = g('somfyGroupHeaderDesc');
if (hTitle && hDesc) {
if (isNew) {
hTitle.innerText = tr('GROUP_CREATE_TITLE');
hDesc.innerText = tr('GROUP_CREATE_DESC');
} else {
hTitle.innerText = tr('GROUP_EDIT_TITLE');
const currentCount = this.groups ? this.groups.length : 0;
const formattedCapacity = `<span class="desc-highlight">${currentCount}/14</span>`;
hDesc.innerHTML = tr('GROUP_EDIT_DESC').replace('%s', formattedCapacity);
}
}
g('btnSaveGroupText').innerText = tr(isNew ? 'BT_CREATE' : 'BT_SAVE');
g('useSaveGroupIcon').setAttribute('href', isNew ? '#svg-add' : '#svg-save');
s(btnSave, 'flex');
g('spanGroupId').innerText = isNew ? '*' : groupId;
ui.toElement(elGroup, group);
this.showEditGroup(true);
routeSetEditor('divSomfyGroups', isNew ? 'new' : groupId, { label: isNew ? tr('GROUP_CREATE_TITLE') : group.name });
watchDirty(elGroup);
});
}
saveGroup() {
const g = get,
sId = g('spanGroupId').innerText,
groupId = parseInt(sId, 10),
obj = ui.fromElement(g('somfyGroup')),
isNew = isNaN(groupId) || groupId >= 255;
const checks = [
[isNaN(obj.remoteAddress) || obj.remoteAddress < 1 || obj.remoteAddress > 16777215, 'ERR_REMOTE_ADDRESS_INVALID'],
[!obj.name || obj.name.length > 20, 'ERR_DEVIVE_NAME_INVALID']
];
const error = checks.find(c => c[0]);
if (error) return ui.errorMessage(tr(error[1]));
if (!isNew) obj.groupId = groupId;
putJSONSync(isNew ? '/addGroup' : '/saveGroup', obj, (err, group) => {
if (err) return ui.serviceError(err);
logger.debug("Group saved:", group);
const msg = isNew ? tr('MSG_ADD_SUCCESS') : tr('MSG_SAVE_SUCCESS');
ui.successMessage(msg);
clearDirty();
if (isNew) {
if (!this.groups) this.groups = [];
if (!this.groups.some(g => g.groupId === group.groupId)) {
this.groups.push(group);
}
}
this.openEditGroup(group.groupId);
this.updateGroupList(() => {
this.openEditGroup(group.groupId);
});
});
}
deleteGroup(groupId) {
let valid = true;
if (isNaN(groupId) || groupId >= 255 || groupId <= 0) {
ui.errorMessage(tr('ERR_INVALID_GROUP_ID'));
valid = false;
}
if (valid) {
getJSONSync(`/group?groupId=${groupId}`, (err, group) => {
if (err) ui.serviceError(err);
else {
if (group.linkedShades.length > 0) {
ui.errorMessage(tr('ERR_GROUP_NOT_EMPTY'));
}
else this.updateScheduleList(() => {
const scheduleCount = (this.schedules || []).filter(sc => sc.targetType === 'group' && sc.targetId === groupId).length;
let prompt = ui.promptMessage(tr('PROMPT_DELETE_GROUP'), () => {
putJSONSync('/deleteGroup', { groupId: groupId }, (err, g) => {
if (err) ui.serviceError(err);
this.updateGroupList();
if (scheduleCount > 0) this.updateScheduleList();
prompt.remove();
});
});
const scheduleWarning = scheduleCount > 0 ? `<p>${tr('PROMPT_DELETE_TARGET_SCHEDULES').replace('{n}', scheduleCount)}</p>` : '';
prompt.querySelector('.sub-message').innerHTML = `${scheduleWarning}<p>${tr("PROMPT_DELETE_GROUP_CONFIRM").replace("{GROUP_NAME}", escHtml(group.name))}</p>`;
});
}
});
}
}
updateGroupList(cb) {
getJSONSync('/groups', (err, groups) => {
if (err) {
logger.error('Failed to load groups:', err);
ui.serviceError(err);
}
else {
logger.debug('Group list updated,', groups.length, 'groups');
this.setGroupsList(groups);
if (typeof cb === 'function') cb();
}
});
}
sendGroupRepeat(groupId, command, repeat, cb, stepSize) {
let obj = { groupId: groupId, command: command };
if (typeof repeat === 'number') obj.repeat = parseInt(repeat);
if (typeof stepSize === 'number') obj.stepSize = parseInt(stepSize);
putJSON('/repeatCommand', obj, (err, group) => {
if (typeof cb === 'function') cb(err, group);
});
}
sendGroupCommand(groupId, command, repeat, cb, stepSize) {
logger.debug(`Sending Group command ${groupId}-${command}`);
let obj = { groupId: groupId };
if (isNaN(parseInt(command, 10))) obj.command = command;
if (typeof repeat === 'number') obj.repeat = parseInt(repeat);
if (typeof stepSize === 'number') obj.stepSize = parseInt(stepSize);
putJSON('/groupCommand', obj, (err, group) => {
if (typeof cb === 'function') cb(err, group);
});
}
_gpWiz(groupId, isUnlink, shadeId = null) {
const pre = isUnlink ? 'UNLINK' : 'LINK';
const stepsCount = isUnlink ? 3 : 4;
const btnActionId = isUnlink ? 'btnUnpairFromGroup' : 'btnPairToGroup';
const btnActionLabel = tr(isUnlink ? 'SHADE_UNPAIR' : 'SHADE_PAIR');
const titleKey = `${pre}_GROUP_TITLE`;
const descKey = `${pre}_GROUP_DESC`;
const t = (s, l) => {
const sk = `${pre}_GROUP_STEP_${s}_${l}`;
const fk = `WIZ_LINK_GROUP_STEP_${s}_${l}`;
const r = tr(sk);
return (r === sk) ? tr(fk) : r;
};
const it = (n, s, l) => `<div class="step-item"><div class="step-number">${n}</div><div class="step-text">${t(s, l)}</div></div>`;
const inf = (s, l) => `
        <div class="information wizard-step" data-stepid="${s}">
        <div class="information-header">
        <svg><use href="#svg-info"></use></svg>
        <b>${tr("MSG_NOTE")}</b>
        </div>
        <div class="information-text">
        <span>${t(s, l)}</span>
        </div>
        </div>`;
let div = document.createElement('div');
div.className = `inst-overlay wizard${ui.isExpertMode ? ' is-expert' : ''}`;
div.id = isUnlink ? 'divUnlinkGroup' : 'divLinkGroup';
div.setAttribute('data-groupid', groupId);
div.setAttribute('data-stepid', '1');
const stepTitles = [];
for (let i = 1; i <= stepsCount; i++) {
let titleIndex = i;
if (isUnlink && i === 2) titleIndex = 3;
if (isUnlink && i === 3) titleIndex = 3;
let tk = `WIZ_LINK_GROUP_TITLE_STEP${titleIndex}`;
if (tr(tk) === tk || (isUnlink && i === 3) || (!isUnlink && i === 2) || (!isUnlink && i === 4)) {
tk = `${pre}_GROUP_TITLE_STEP${isUnlink && i === 3 ? '_3' : titleIndex}`;
}
stepTitles.push(tk);
}
div.innerHTML = `
        <div class="instructions-content">

        ${overlayHeader(titleKey, descKey, "svg-simpleShutter" , {
subtitle: true,
showInfo: false,
showExpert: true
})}

        <div class="overlay-scroll-content">

        ${wizardStepper(stepTitles)}
        <div class="blocGroupsteps">
        ${inf(1, 1)}
        <div class="uniblocStep wizard-step" data-stepid="1">
        ${it('a', 1, 2)} ${it('c', 1, 3)}
        </div>
        ${!isUnlink ? `
        <div class="uniblocCol LinkGroupSelect wizard-step" data-expert data-stepid="2">
        <label class="label" for="selAvailShades">${tr("LINK_GROUP_SELECT_SHADE")}</label>
        <select id="selAvailShades" class="inputAndSelect" data-bind="shadeId" onchange="document.querySelectorAll('.divWizShadeName').forEach(el => el.textContent = this.options[this.selectedIndex].text);"></select>
        </div>
        <div class="uniblocStep wizard-step" data-stepid="2">
        ${it('a', 2, 1)} ${it('b', 2, 2)}
        </div>
        ${inf(2, 3)}
        ` : ''}
        <div class="blocsteps-row wizard-step" data-expert data-stepid="${isUnlink ? 2 : 3}">
        <div class="divWizShadeName"></div>
        <button type="button" id="btnOpenMemory">${tr("BT_OPEN_MEMORY")}</button>
        </div>
        <div class="uniblocStep wizard-step" data-stepid="${isUnlink ? 2 : 3}">
        ${it('a', isUnlink ? 2 : 3, 1)}
        ${it('b', isUnlink ? 2 : 3, 2)}
        </div>
        ${isUnlink ? inf(2, 3) : inf(3, 3)}
        <div class="button-container-col wizard-step marginB25" data-expert data-stepid="0">
        <button id="${btnActionId}" type="button">${btnActionLabel}</button>
        </div>
        <div class="uniblocStep wizard-step" data-stepid="${isUnlink ? 3 : 4}">
        ${it('a', isUnlink ? 3 : 4, 1)}
        ${it('b', isUnlink ? 3 : 4, 2)}
        <div class="empty-state"><svg class="empty-icon"><use href=#svg-succes></use></svg></div>
        </div>
        </div>
        </div>
        <div class="hrDivFooter-Instruc"></div>
        <div class="expert-only-buttons" data-expert>
        <button type="button" line onclick="const o=this.closest('.inst-overlay'); requestCloseOverlay(o);">${tr("BT_CANCEL_1")}</button>
        </div>
        <div class="button-container-overlay">
        <button id="btnWizStop" class="wizard-step" data-stepid="1" line type="button">${tr("BT_CANCEL_1")}</button>
        <button id="btnWizPrev" class="wizard-step" data-mstepid="${isUnlink ? '2,3' : '2,3,4'}" line type="button" onclick="ui.wizSetPrevStep(this.closest('.wizard'));">${tr("BT_GO_BACK")}</button>
        <button id="btnWizNext" class="wizard-step" data-mstepid="${isUnlink ? '1,2' : '1,2,3'}" type="button" onclick="ui.wizSetNextStep(this.closest('.wizard'));">${tr("BT_NEXT")}</button>
        <button id="${btnActionId}" class="wizard-step" data-stepid="${stepsCount}" type="button">${btnActionLabel}</button>
        </div>
        </div>`;
const clearT = () => { if (this.btnTimer) { clearTimeout(this.btnTimer); this.btnTimer = null; } };
div.querySelectorAll('#btnWizStop').forEach(btn => btn.onclick = () => requestCloseOverlay(div, clearT));
const hP = div.querySelector('.instructions-header p');
if (hP) hP.innerHTML += ' <span id="spanGroupName" class="groupNameSpan"></span>';
div.querySelector('#btnOpenMemory').onclick = () => {
const sId = isUnlink ? shadeId : ui.fromElement(div).shadeId;
putJSONSync('/shadeCommand', { shadeId: sId, command: 'prog', repeat: 40 }, (err) => {
if (err) ui.serviceError(err);
else {
let prompt = ui.promptMessage(tr('PROMPT_CONFIRM_MOTOR_RESPONSE'), () => {
ui.wizSetNextStep(div);
closeOverlay(prompt);
});
prompt.querySelector('.sub-message').innerHTML = isUnlink ?
`<hr><p>${tr("PROMPT_SHADE_MOVE_CONFIRM")}</p><p>${tr("UNLINK_GROUP_METHOD_1")}</p><p>${tr("UNLINK_GROUP_METHOD_2")}</p>` :
`<p>${tr("PROMPT_SHADE_MOVE_CONFIRM")}</p><p>${tr("LINK_GROUP_MEMORY_READY_FOR_GROUP")}</p>`;
}
});
};
const btnActions = div.querySelectorAll(`#${btnActionId}`);
let fnRepeat = (err, o) => {
clearT();
if (!err && mouseDown) {
if (o.cmd === 'Sensor') somfy.sendSetSensor(o);
else if (o.groupId !== undefined) somfy.sendGroupRepeat(o.groupId, 'prog', null, fnRepeat);
else somfy.sendCommandRepeat(o.shadeId, 'prog', null, fnRepeat);
}
};
if (isUnlink) {
const onUnlinkPress = () => {
putJSONSync('/groupCommand', { groupId: groupId, command: 'prog', repeat: 1 }, (err) => {
if (err) ui.serviceError(err);
else {
let prompt = ui.promptMessage(tr('PROMPT_CONFIRM_MOTOR_RESPONSE'), () => {
putJSONSync('/unlinkFromGroup', { groupId: groupId, shadeId: shadeId }, (err, group) => {
somfy.setLinkedShadesList(group);
this.updateGroupList();
});
closeOverlay(prompt);
closeOverlay(div, clearT);
});
prompt.querySelector('.sub-message').innerHTML = `<hr><p>${tr("PROMPT_SHADE_MOVE_CONFIRM")}</p><p>${tr("PROMPT_SHADE_MOVE_DONE")}</p>`;
}
});
};
btnActions.forEach(btn => btn.onclick = onUnlinkPress);
} else {
const onActionPress = (evt) => {
if (!isPrimaryPress(evt)) return;
somfy.sendGroupCommand(groupId, 'prog', null, fnRepeat);
};
btnActions.forEach(btn => btn.addEventListener('mousedown', onActionPress));
btnActions.forEach(btn => btn.addEventListener('touchstart', (e) => { e.preventDefault(); onActionPress(); }));
const onActionRelease = (evt) => {
if (!isPrimaryPress(evt)) return;
let obj = ui.fromElement(div);
let prompt = ui.promptMessage(tr('PROMPT_CONFIRM_MOTOR_RESPONSE'), () => {
putJSONSync('/linkToGroup', { groupId: groupId, shadeId: obj.shadeId }, (err, group) => {
somfy.setLinkedShadesList(group);
this.updateGroupList();
});
closeOverlay(prompt);
closeOverlay(div, clearT);
});
prompt.querySelector('.sub-message').innerHTML = `<p>${tr("PROMPT_SHADE_GROUP_LINK_CONFIRM")}</p><p>${tr("LINK_GROUP_LINK_DONE")}</p>`;
};
btnActions.forEach(btn => {
btn.addEventListener('mouseup', onActionRelease);
btn.addEventListener('touchend', onActionRelease);
});
}
const urlInit = isUnlink ? `/group?groupId=${groupId}` : `/groupOptions?groupId=${groupId}`;
getJSONSync(urlInit, (err, data) => {
if (err) {
ui.serviceError(err);
return;
}
let canShow = false;
const spanName = div.querySelector('#spanGroupName');
if (isUnlink) {
const shade = data.linkedShades.find(x => x.shadeId === shadeId);
if (shade) {
if (spanName) spanName.textContent = data.name;
div.querySelectorAll('.divWizShadeName').forEach(el => el.textContent = shade.name);
canShow = true;
} else {
ui.errorMessage(tr('ERR_DEVICE_NOT_FOUND_GROUP'));
}
} else {
if (data.availShades && data.availShades.length > 0) {
if (spanName) spanName.textContent = data.name;
let selAvail = div.querySelector('#selAvailShades');
data.availShades.forEach(s => selAvail.options.add(new Option(s.name, s.shadeId)));
div.querySelectorAll('.divWizShadeName').forEach(el => el.textContent = data.availShades[0].name);
canShow = true;
} else {
ui.errorMessage(tr('ERR_NO_DEVICE_AVAILABLE_GROUP'));
}
}
if (canShow) {
markCriticalStepReached(div, isUnlink ? 2 : 3);
ui.wizSetStep(div, 1);
shOverlay(div, clearT);
}
});
return div;
}
linkGroupShade(groupId) { return this._gpWiz(groupId, false); }
unlinkGroupShade(groupId, shadeId) { return this._gpWiz(groupId, true, shadeId); }
updateScheduleList(cb) {
getJSONSync('/schedules', (err, schedules) => {
if (err) {
logger.error('Failed to load schedules:', err);
ui.serviceError(err);
}
else this.setScheduleList(schedules);
if (typeof cb === 'function') cb();
});
}
_sortSchedulesByEffectiveTime(list) {
const geo = (typeof general !== 'undefined' && general._geoSettings) || {};
const hasGeo = typeof geo.geoLat === 'number' && geo.geoLat >= -90 && geo.geoLat <= 90;
const sunTimes = hasGeo ? computeSunUtcMinutes(geo.geoLat, geo.geoLon, new Date()) : null;
const withEffective = list.map(sc => {
let effectiveMinutes;
if (sc.timeRef === 'sunrise' || sc.timeRef === 'sunset') {
const baseUtc = sunTimes ? (sc.timeRef === 'sunrise' ? sunTimes.sunriseUtcMinutes : sunTimes.sunsetUtcMinutes) : null;
const baseLocal = baseUtc !== null ? sunUtcMinutesToLocal(baseUtc) : null;
effectiveMinutes = baseLocal !== null ? baseLocal + (sc.sunOffset || 0) : null;
} else {
effectiveMinutes = sc.hour * 60 + sc.minute;
}
return { sc, effectiveMinutes };
});
withEffective.sort((a, b) => (a.effectiveMinutes ?? 9999) - (b.effectiveMinutes ?? 9999));
return withEffective;
}
_buildScheduleCardHtml(sc, effectiveMinutes, { showTarget, editFn }) {
const { main: timeMain, ampm } = formatMinutesOfDay(effectiveMinutes);
const actionText = this._scheduleActionText(sc);
let triggerInfo;
if (sc.timeRef === 'sunrise' || sc.timeRef === 'sunset') {
const isRise = sc.timeRef === 'sunrise';
const phaseLabel = tr(isRise ? 'SCHEDULE_TIME_REF_SUNRISE' : 'SCHEDULE_TIME_REF_SUNSET');
const offset = sc.sunOffset || 0;
const offsetSuffix = offset !== 0 ? ` (${offset > 0 ? '+' : ''}${offset}m)` : '';
const iconHref = isRise ? '#indic-sun' : '#svg-night';
triggerInfo = `<svg class="schedule-trigger-icon"><use href="${iconHref}"></use></svg>${phaseLabel}${offsetSuffix}`;
} else {
triggerInfo = tr('SCHEDULE_TIME_REF_CLOCK');
}
const daysHtml = SCHEDULE_DAY_DEFS.map(d => {
const active = (sc.dayMask & d.bit) !== 0;
return `<span${active ? ' class="active"' : ''}>${tr(d.key).charAt(0)}</span>`;
}).join('');
const rowBottomHtml = `<div class="schedule-row-bottom">
        <div class="col-days-label"><span class="schedule-badge-action">${actionText}</span></div>
        <div class="col-days-list">${daysHtml}</div>
        </div>`;
const title = (sc.name && sc.name.length > 0) ? sc.name : timeMain;
const targetBadgeHtml = showTarget
? `<span class="schedule-badge-target">${this.scheduleTargetName(sc)}</span>`
: '';
return `<div class="schedule-card${sc.enabled ? '' : ' is-off'}" data-scheduleid="${sc.id}" onclick="somfy.${editFn}(${sc.id});">
        <div class="schedule-content-left">
        <div class="schedule-row-top">
        <div class="col-time">
        <span class="schedule-time">${timeMain}${ampm ? `<span class="ampm">${ampm}</span>` : ''}</span>
        </div>
        <div class="col-info">
        <div class="schedule-title-row">
        <div class="schedule-title">${title}</div>
        ${targetBadgeHtml}
        ${sc.enabled ? '' : `<span class="schedule-badge-off">${tr('IS_DISABLED')}</span>`}
        </div>
        <span class="schedule-trigger-info">${triggerInfo}</span>
        </div>
        </div>
        ${rowBottomHtml}
        </div>
        <div class="divEditDelete-svg" onclick="event.stopPropagation(); somfy.deleteSchedule(${sc.id});">
        <svg class="icon-svg" style="color: var(--color-danger);"><use href="#svg-trash"></use></svg>
        </div>
        </div>`;
}
_scheduleActionText(sc) {
if (sc.positionMode === 'my') return 'MY';
if (sc.positionMode === 'tiltonly') return `${sc.targetTilt}%`;
if (sc.targetPos === 0) return tr('SCHEDULE_POS_OPEN');
if (sc.targetPos === 100) return tr('SCHEDULE_POS_CLOSE');
return `${sc.targetPos}%`;
}
_buildScheduleTooltipHtml(targetType, targetId) {
const titleHtml = `<div class="schedule-popover-title">${tr('SUBTAB_SCHEDULES')}</div>`;
const list = (this.schedules || []).filter(sc => sc.targetType === targetType && sc.targetId === targetId);
if (list.length === 0) {
return `${titleHtml}<div class="schedule-popover-empty">${tr('EMPTY_SCHEDULE_TITLE')}</div>`;
}
const rowsHtml = this._sortSchedulesByEffectiveTime(list).map(({ sc, effectiveMinutes }) => {
const { main: timeMain, ampm } = formatMinutesOfDay(effectiveMinutes);
const daysHtml = SCHEDULE_DAY_DEFS.map(d => {
const active = (sc.dayMask & d.bit) !== 0;
return `<span${active ? ' class="active"' : ''}>${tr(d.key).charAt(0)}</span>`;
}).join('');
return `<div class="schedule-popover-row${sc.enabled ? '' : ' is-off'}">
            <span class="schedule-popover-time">${timeMain}${ampm ? `<span class="ampm">${ampm}</span>` : ''}${this._scheduleTriggerBadgeHtml(sc)}</span>
            <span class="schedule-popover-days">${daysHtml}</span>
            <span class="schedule-popover-pos">${this._scheduleActionText(sc)}</span>
            </div>`;
}).join('');
return `${titleHtml}${rowsHtml}`;
}
_scheduleTriggerBadgeHtml(sc) {
if (sc.timeRef !== 'sunrise' && sc.timeRef !== 'sunset') return '';
const iconHref = sc.timeRef === 'sunrise' ? '#indic-sun' : '#svg-night';
return `<svg class="schedule-popover-trigger-icon"><use href="${iconHref}"></use></svg>`;
}
_hasSchedulesFor(targetType, targetId) {
return (this.schedules || []).some(sc => sc.targetType === targetType && sc.targetId === targetId);
}
_syncScheduleIndicators() {
document.querySelectorAll('.schedule-indicator').forEach(el => {
const targetType = el.getAttribute('data-schedule-target');
const targetId = parseInt(el.getAttribute('data-schedule-id'), 10);
el.classList.toggle('no-schedule', !this._hasSchedulesFor(targetType, targetId));
});
}
renderScheduleBadges(containerId, targetType, targetId) {
const container = get(containerId);
if (!container) return;
const quotaSpan = get(containerId === 'divShadeScheduleBadges' ? 'spanScheduleSlotsShade' : 'spanScheduleSlotsGroup');
if (quotaSpan) {
const max = this.maxSchedules || 32;
const remaining = Math.max(0, max - (this.schedules || []).length);
quotaSpan.textContent = tr('SCHEDULE_SLOTS_REMAINING').replace('{n}', remaining);
}
const list = (this.schedules || []).filter(sc => sc.targetType === targetType && sc.targetId === targetId);
if (list.length === 0) {
container.innerHTML = `<span class="schedule-badge-empty">${tr('EMPTY_SCHEDULE_TITLE')}</span>`;
return;
}
const withEffective = this._sortSchedulesByEffectiveTime(list);
container.innerHTML = withEffective.map(({ sc, effectiveMinutes }) =>
this._buildScheduleCardHtml(sc, effectiveMinutes, { showTarget: false, editFn: 'openEditScheduleInline' })
).join('');
}
refreshOpenTargetScheduleBadges() {
const shadeForm = get('somfyShade');
if (shadeForm && shadeForm.style.display !== 'none') {
const shadeId = parseInt(get('spanShadeId').innerText, 10);
if (!isNaN(shadeId)) this.renderScheduleBadges('divShadeScheduleBadges', 'shade', shadeId);
}
const groupForm = get('somfyGroup');
if (groupForm && groupForm.style.display !== 'none') {
const groupId = parseInt(get('spanGroupId').innerText, 10);
if (!isNaN(groupId)) this.renderScheduleBadges('divGroupScheduleBadges', 'group', groupId);
}
}
scheduleLabel(sc) {
if (!sc) return '';
if (sc.name) return sc.name;
const hh = (sc.hour || 0).toString().padStart(2, '0');
const mm = (sc.minute || 0).toString().padStart(2, '0');
return `${hh}:${mm} - ${this.scheduleTargetName(sc)}`;
}
scheduleTargetName(sc) {
if (!sc) return '';
if (sc.targetType === 'group') {
const grp = (this.groups || []).find(x => x.groupId === sc.targetId);
return grp ? grp.name : `${tr('SUBTAB_GROUPS')} #${sc.targetId}`;
}
const shd = (this.shades || []).find(x => x.shadeId === sc.targetId);
return shd ? shd.name : `${tr('SUBTAB_DEVICES')} #${sc.targetId}`;
}
setScheduleList(schedules) {
this.schedules = schedules || [];
const max = this.maxSchedules || 32;
const used = this.schedules.length;
const quotaText = get('divScheduleQuotaText');
if (quotaText) quotaText.textContent = tr('SCHEDULE_QUOTA_GLOBAL').replace('{n}', used).replace('{max}', max);
const btnAdd = get('btnAddSchedule');
if (btnAdd) btnAdd.disabled = used >= max;
const withEffective = this._sortSchedulesByEffectiveTime(this.schedules);
get('divScheduleList').innerHTML = withEffective.map(({ sc, effectiveMinutes }) =>
this._buildScheduleCardHtml(sc, effectiveMinutes, { showTarget: true, editFn: 'openEditSchedule' })
).join('');
const hasSchedules = this.schedules.length > 0;
const empty = get('divScheduleEmptyState'), content = get('divScheduleListContent');
if (empty) empty.style.display = hasSchedules ? 'none' : 'block';
if (content) content.style.display = hasSchedules ? '' : 'none';
this._syncScheduleIndicators();
}
populateScheduleTargetSelect(selectedType, selectedId) {
const sel = get('selScheduleTarget');
if (!sel) return;
sel.innerHTML = '';
const shadeGrp = document.createElement('optgroup');
shadeGrp.setAttribute('label', tr('SUBTAB_DEVICES'));
(this.shades || []).forEach(s => {
const opt = document.createElement('option');
opt.value = `shade:${s.shadeId}`;
opt.text = s.name;
shadeGrp.appendChild(opt);
});
if (shadeGrp.children.length > 0) sel.appendChild(shadeGrp);
const groupGrp = document.createElement('optgroup');
groupGrp.setAttribute('label', tr('SUBTAB_GROUPS'));
(this.groups || []).forEach(grp => {
const opt = document.createElement('option');
opt.value = `group:${grp.groupId}`;
opt.text = grp.name;
groupGrp.appendChild(opt);
});
if (groupGrp.children.length > 0) sel.appendChild(groupGrp);
if (selectedType && typeof selectedId !== 'undefined') sel.value = `${selectedType}:${selectedId}`;
}
hasScheduleTarget() {
return (this.shades || []).length > 0 || (this.groups || []).length > 0;
}
openEditSchedule(scheduleId) {
confirmDiscardChanges(() => this._openEditSchedule(scheduleId, undefined, false));
}
openAddScheduleInline(targetType, targetId) {
if (isNaN(targetId)) return;
this._openEditSchedule(undefined, { targetType, targetId }, true);
}
openEditScheduleInline(scheduleId) {
this._openEditSchedule(scheduleId, undefined, true);
}
_openEditSchedule(scheduleId, presetTarget, lockedTarget, opts) {
const isNew = typeof scheduleId === 'undefined';
if (isNew && !presetTarget && !this.hasScheduleTarget()) {
routeSetEditor('divSomfySchedules', null, { replace: true });
return ui.infoMessage('SCHEDULE_NO_TARGET_TITLE', 'SCHEDULE_NO_TARGET_MSG');
}
if (isNew && this.schedules && this.schedules.length >= (this.maxSchedules || 32)) {
routeSetEditor('divSomfySchedules', null, { replace: true });
return ui.errorMessage(get('divSomfySettings'), tr('ERR_SCHEDULE_LIMIT_REACHED'));
}
if (isNew) {
const targetType = (presetTarget && presetTarget.targetType) || 'shade';
let targetId = presetTarget ? presetTarget.targetId : undefined;
if (typeof targetId === 'undefined') {
const firstShade = (this.shades && this.shades.length > 0) ? this.shades[0] : undefined;
targetId = firstShade ? firstShade.shadeId : undefined;
}
this.ScheduleOverlay(undefined, {
name: '', dayMask: 0, hour: 9, minute: 0,
targetType, targetId, targetPos: 0, enabled: true, retries: 0
}, lockedTarget);
} else {
getJSONSync(`/schedule?scheduleId=${scheduleId}`, (err, sc) => {
if (err) {
routeSetEditor('divSomfySchedules', null, { replace: true });
return (opts && opts.silentError) ? undefined : ui.serviceError(err);
}
this.ScheduleOverlay(scheduleId, sc, lockedTarget);
});
}
}
shadeTypeSupportsMy(shadeType) {
return !this.noMyShadeTypes.includes(shadeType);
}
ScheduleOverlay(scheduleId, scheduleData, lockedTarget) {
if (get('divEditScheduleOverlay')) return;
const isEdit = typeof scheduleId !== 'undefined';
const titleKey = isEdit ? 'SCHEDULE_EDIT_TITLE' : 'SCHEDULE_CREATE_TITLE';
const descKey = isEdit ? 'SCHEDULE_EDIT_DESC' : 'SCHEDULE_CREATE_DESC';
const buttonText = isEdit ? tr('BT_SAVE') : tr('BT_CREATE');
const iconHref = isEdit ? '#svg-save' : '#svg-add';
let div = document.createElement('div');
div.id = 'divEditScheduleOverlay';
div.className = 'inst-overlay';
div.setAttribute('data-scheduleid', isEdit ? scheduleId : '');
div.setAttribute('data-targettype', scheduleData.targetType || 'shade');
div.setAttribute('data-targetid', scheduleData.targetId);
const dayBtn = (bit, key) => `<button type="button" class="schedule-day-btn" data-bit="${bit}" onclick="this.classList.toggle('active'); this.dispatchEvent(new Event('change', {bubbles:true}));">${tr(key)}</button>`;
const effectiveTimeRef = (scheduleData.timeRef === 'sunrise' || scheduleData.timeRef === 'sunset') ? scheduleData.timeRef : 'clock';
const geo = (typeof general !== 'undefined' && general._geoSettings) || {};
const hasGeo = typeof geo.geoLat === 'number' && geo.geoLat >= -90 && geo.geoLat <= 90;
const sunTimes = hasGeo ? computeSunUtcMinutes(geo.geoLat, geo.geoLon, new Date()) : null;
const sunRefSuffix = hasGeo ? '' : ` ${tr('SCHEDULE_SUN_NOT_CONFIGURED_SHORT')}`;
const targetBlock = lockedTarget ? `
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-indicShutter"></use></svg></div>
        <div class="unifield-content">
        <label class="label">${tr('SCHEDULE_TARGET')}</label>
        <div class="inputAndSelect schedule-target-locked">${this.scheduleTargetName(scheduleData)}</div>
        </div>
        </div>` : `
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-indicShutter"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="selScheduleTarget">${tr('SCHEDULE_TARGET')}</label>
        <select id="selScheduleTarget" class="inputAndSelect"></select>
        </div>
        </div>`;
div.innerHTML = `
        <div class="instructions-content">
        ${overlayHeader(titleKey, descKey, 'svg-schedule', { subtitle: descKey, showInfo: false, stateBadge: 'IS_DISABLED' })}
        <div class="overlay-scroll-content">
        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('GENERAL_INFO')}</h3>
        <div class="uniblocRow">
        <div class="uniRow dirty-target">
        <div class="unifield-content">
        <label class="label" for="fldScheduleName">${tr('NAME')}</label>
        <input id="fldScheduleName" class="inputAndSelect" name="scheduleName" type="text" length="20" placeholder="${tr('SCHEDULE_NAME_PHL')}">
        </div>
        </div>
        ${targetBlock}
        </div>
        </div>
        <div class="unibloc-container dirty-target">
        <div class="schedule-days-header">
        <h3 class="unibloc-title">${tr('SCHEDULE_DAYS')}</h3>
        <button type="button" id="btnScheduleAllDays" class="schedule-alldays-btn">${tr('BT_SELECT_ALL_DAYS')}</button>
        </div>
        <div id="divScheduleDayPicker" class="schedule-day-picker">
        ${dayBtn(2, 'SCHEDULE_MON')}${dayBtn(4, 'SCHEDULE_TUE')}${dayBtn(8, 'SCHEDULE_WED')}${dayBtn(16, 'SCHEDULE_THU')}${dayBtn(32, 'SCHEDULE_FRI')}${dayBtn(64, 'SCHEDULE_SAT')}${dayBtn(1, 'SCHEDULE_SUN')}
        </div>
        </div>
        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('SCHEDULE_TIME')}</h3>

        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-schedule"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="selScheduleTimeRef">${tr('SCHEDULE_TIME_REF')}</label>
        <select id="selScheduleTimeRef" class="inputAndSelect">
        <option value="clock" ${effectiveTimeRef === 'clock' ? 'selected' : ''}>${tr('SCHEDULE_TIME_REF_CLOCK')}</option>
        <option value="sunrise" ${effectiveTimeRef === 'sunrise' ? 'selected' : ''}>${tr('SCHEDULE_TIME_REF_OPT_SUNRISE')}${sunRefSuffix}</option>
        <option value="sunset" ${effectiveTimeRef === 'sunset' ? 'selected' : ''}>${tr('SCHEDULE_TIME_REF_OPT_SUNSET')}${sunRefSuffix}</option>
        </select>
        </div>
        </div>

        <div id="divScheduleSunGeoHint" class="uniStatus" style="display:none;">${tr('SCHEDULE_SUN_NOT_CONFIGURED')}</div>

        <div id="divScheduleClockTime" class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-schedule"></use></svg></div>
        <div class="unifield-content">
        <input id="fldScheduleTime" class="inputAndSelect" type="time">
        </div>
        </div>

        <div id="divScheduleSunBlock" style="display:none;">

        <div id="divScheduleSunTimeInfo" class="schedule-sun-time-info"></div>

        <label class="uniRow dirty-target" for="cbScheduleSunOffsetEnabled">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg class="svg-mirror-x"><use href="#svg-schedule"></use></svg></div>
        <div class="uniText"><div class="uniLabel">${tr('SCHEDULE_SUN_OFFSET_ENABLE')}</div></div>
        </div>
        <div class="uniRight">
        <span class="switch">
        <input id="cbScheduleSunOffsetEnabled" type="checkbox">
        <div></div>
        </span>
        </div>
        </label>

        <div id="divScheduleSunOffsetBlock" style="display:none;">
        <div class="schedule-sun-offset-row">
        <div class="slider-wrapper schedule-sun-offset-slider dirty-target">
        <div class="slider-progress"><div class="slider-thumb-line"></div></div>
        <input id="slidScheduleSunOffset" class="md3-range-input" type="range" min="-720" max="720" step="1" value="0">
        </div>
        <div class="schedule-sun-offset-field dirty-target">
        <input id="inputScheduleSunOffset" class="schedule-sun-offset-number" type="number" min="-720" max="720" step="1" value="0">
        <span class="schedule-sun-offset-unit">${tr('SCHEDULE_SUN_OFFSET_UNIT')}</span>
        </div>
        </div>
        <div id="divScheduleSunOffsetSummary" class="uniStatus"></div>
        </div>

        </div>
        </div>
        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('SHADE_POSITION')}</h3>
        <div class="schedule-position-quick">
        <button type="button" id="btnSchedulePosOpen" class="schedule-quickpos-btn"><svg><use href="#svg-up"></use></svg><span>${tr('SCHEDULE_POS_OPEN')}</span></button>
        <button type="button" id="btnSchedulePosClose" class="schedule-quickpos-btn"><svg><use href="#svg-down"></use></svg><span>${tr('SCHEDULE_POS_CLOSE')}</span></button>
        <button type="button" id="btnSchedulePosCustom" class="schedule-quickpos-btn"><svg><use href="#svg-target"></use></svg><span>${tr('SCHEDULE_POS_CUSTOM')}</span></button>
        <button type="button" id="btnSchedulePosTiltOnly" class="schedule-quickpos-btn" style="display:none;"><svg><use href="#svg-indicblind"></use></svg><span>${tr('SCHEDULE_POS_TILT_ONLY')}</span></button>
        <button type="button" id="btnSchedulePosMy" class="schedule-quickpos-btn"><svg><use href="#svg-my"></use></svg><span>${tr('SCHEDULE_POS_MY')}</span></button>
        </div>
        <div id="divScheduleMyGroupNote" class="uniStatus schedule-my-note" style="display:none;"></div>
        <input type="hidden" id="fldSchedulePositionMode" value="position">
        <div id="divScheduleSliderGroup" class="slider-group">
        <div class="slider-header"><span class="title">${tr('SETMYPOS_TARGET_POS')}</span><span class="val"><span id="spanScheduleTargetPos">0</span> %</span></div>
        <div class="slider-wrapper">
        <div class="slider-progress"><div class="slider-thumb-line"></div></div>
        <input id="slidScheduleTargetPos" class="md3-range-input" type="range" min="0" max="100" step="1" value="0" oninput="syncSliderProgress(this); get('spanScheduleTargetPos').innerText = this.value;">
        </div>
        </div>
        <div id="divScheduleTiltSliderGroup" class="slider-group" style="display:none;">
        <div class="slider-header"><span class="title">${tr('SETMYPOS_TARGET_TILT_POS')}</span><span class="val"><span id="spanScheduleTargetTilt">0</span> %</span></div>
        <div class="slider-wrapper">
        <div class="slider-progress"><div class="slider-thumb-line"></div></div>
        <input id="slidScheduleTargetTilt" class="md3-range-input" type="range" min="0" max="100" step="1" value="0" oninput="syncSliderProgress(this); get('spanScheduleTargetTilt').innerText = this.value;">
        </div>
        </div>
        </div>
        <div class="unibloc-container">
        <h3 class="unibloc-title">${tr('OPTION')}</h3>
        <div class="uniRow dirty-target">
        <div class="uniblocSvg-S"><svg><use href="#svg-repeat"></use></svg></div>
        <div class="unifield-content">
        <label class="label" for="selScheduleRetries">${tr('REPEAT_COMMANDS')}</label>
        <select id="selScheduleRetries" class="inputAndSelect">
        <option value="0">${tr('OPT_NO_REPEAT')}</option>
        <option value="1">${tr('OPT_1TIME')}</option>
        <option value="2">${tr('OPT_2TIME')}</option>
        <option value="3">${tr('OPT_3TIME')}</option>
        <option value="4">${tr('OPT_4TIME')}</option>
        <option value="5">${tr('OPT_5TIME')}</option>
        <option value="6">${tr('OPT_6TIME')}</option>
        <option value="7">${tr('OPT_7TIME')}</option>
        <option value="8">${tr('OPT_8TIME')}</option>
        <option value="9">${tr('OPT_9TIME')}</option>
        <option value="10">${tr('OPT_10TIME')}</option>
        </select>
        </div>
        </div>

        <label class="uniRow dirty-target" for="cbScheduleEnabled">
        <div class="uniLeft">
        <div class="uniblocSvg-S"><svg><use href="#svg-schedule"></use></svg></div>
        <div class="uniText">
        <div class="uniLabel">${tr('SCHEDULE_ENABLED')}</div>
        <div class="uniStatus">${tr('SCHEDULE_ENABLED_DESC')}</div>
        </div>
        </div>
        <div class="uniRight">
        <span class="switch">
        <input id="cbScheduleEnabled" type="checkbox" checked/>
        <div></div>
        </span>
        </div>
        </label>
        </div>
        </div>
        <div class="hrDivFooter-Instruc"></div>
        <div class="button-container-overlay">
        <button id="btnScheduleGoBack" line type="button">${tr('BT_CLOSE')}</button>
        <button id="btnSaveSchedule" type="button">
        <svg><use id="useSaveScheduleIcon" href="${iconHref}"></use></svg>
        <span id="btnSaveScheduleText">${buttonText}</span>
        </button>
        </div>
        </div>`;
shOverlay(div);
if (!lockedTarget) {
div._onClosed = () => routeSetEditor('divSomfySchedules', null);
routeSetEditor('divSomfySchedules', isEdit ? scheduleId : 'new', { label: isEdit ? this.scheduleLabel(scheduleData) : tr('SCHEDULE_CREATE_TITLE') });
this.populateScheduleTargetSelect(scheduleData.targetType, scheduleData.targetId);
}
div.querySelector('#fldScheduleName').value = scheduleData.name || '';
div.querySelectorAll('.schedule-day-btn').forEach(btn => {
const bit = parseInt(btn.getAttribute('data-bit'), 10);
btn.classList.toggle('active', ((scheduleData.dayMask || 0) & bit) !== 0);
});
const hh = (scheduleData.hour || 0).toString().padStart(2, '0');
const mm = (scheduleData.minute || 0).toString().padStart(2, '0');
div.querySelector('#fldScheduleTime').value = `${hh}:${mm}`;
const clockRow = div.querySelector('#divScheduleClockTime');
const sunBlock = div.querySelector('#divScheduleSunBlock');
const sunTimeInfo = div.querySelector('#divScheduleSunTimeInfo');
const sunGeoHint = div.querySelector('#divScheduleSunGeoHint');
const offsetToggle = div.querySelector('#cbScheduleSunOffsetEnabled');
const offsetBlock = div.querySelector('#divScheduleSunOffsetBlock');
const offsetSlider = div.querySelector('#slidScheduleSunOffset');
const offsetNumber = div.querySelector('#inputScheduleSunOffset');
const offsetSummary = div.querySelector('#divScheduleSunOffsetSummary');
const initialOffset = (typeof scheduleData.sunOffset === 'number') ? scheduleData.sunOffset : 0;
offsetSlider.value = initialOffset;
offsetNumber.value = initialOffset;
offsetToggle.checked = initialOffset !== 0;
syncSliderProgress(offsetSlider);
const timeRefSelect = div.querySelector('#selScheduleTimeRef');
const currentPhase = () => timeRefSelect.value === 'sunset' ? 'sunset' : 'sunrise';
const updateSunTimeInfo = () => {
if (!sunTimes) {
sunTimeInfo.textContent = tr('SCHEDULE_SUN_NO_EVENT_TODAY');
} else {
const isRise = currentPhase() === 'sunrise';
const utcMinutes = isRise ? sunTimes.sunriseUtcMinutes : sunTimes.sunsetUtcMinutes;
const key = isRise ? 'SCHEDULE_SUN_TIME_SUNRISE_TODAY' : 'SCHEDULE_SUN_TIME_SUNSET_TODAY';
sunTimeInfo.textContent = tr(key).replace('{time}', formatSunTime(utcMinutes));
}
};
const updateOffsetSummary = () => {
if (!sunTimes) { offsetSummary.textContent = ''; return; }
const isRise = currentPhase() === 'sunrise';
const phaseNoun = tr(isRise ? 'SCHEDULE_SUN_PHASE_SUNRISE_NOUN' : 'SCHEDULE_SUN_PHASE_SUNSET_NOUN');
const baseUtc = isRise ? sunTimes.sunriseUtcMinutes : sunTimes.sunsetUtcMinutes;
const minutes = parseInt(offsetNumber.value, 10) || 0;
const resultTime = formatSunTime(baseUtc + minutes);
let key = 'SCHEDULE_SUN_OFFSET_SUMMARY_NONE';
if (minutes > 0) key = 'SCHEDULE_SUN_OFFSET_SUMMARY_AFTER';
else if (minutes < 0) key = 'SCHEDULE_SUN_OFFSET_SUMMARY_BEFORE';
offsetSummary.textContent = tr(key)
.replace('{minutes}', Math.abs(minutes))
.replace('{phase}', phaseNoun)
.replace('{time}', resultTime);
};
const syncModeUI = () => {
const isClock = timeRefSelect.value === 'clock';
clockRow.style.display = isClock ? '' : 'none';
sunBlock.style.display = (isClock || !hasGeo) ? 'none' : '';
sunGeoHint.style.display = (isClock || hasGeo) ? 'none' : '';
if (!isClock && hasGeo) { updateSunTimeInfo(); updateOffsetSummary(); }
};
const syncOffsetUI = () => {
offsetBlock.style.display = offsetToggle.checked ? '' : 'none';
if (!offsetToggle.checked) {
offsetNumber.value = 0;
offsetSlider.value = 0;
syncSliderProgress(offsetSlider);
}
updateOffsetSummary();
};
syncModeUI();
syncOffsetUI();
timeRefSelect.addEventListener('change', syncModeUI);
offsetToggle.addEventListener('change', syncOffsetUI);
offsetSlider.addEventListener('input', () => {
offsetNumber.value = offsetSlider.value;
offsetNumber.dispatchEvent(new Event('change', { bubbles: true }));
syncSliderProgress(offsetSlider);
updateOffsetSummary();
});
offsetNumber.addEventListener('input', () => {
let v = parseInt(offsetNumber.value, 10);
if (isNaN(v)) return;
v = Math.min(720, Math.max(-720, v));
offsetSlider.value = v;
offsetSlider.dispatchEvent(new Event('change', { bubbles: true }));
syncSliderProgress(offsetSlider);
updateOffsetSummary();
});
div.querySelector('#slidScheduleTargetPos').value = scheduleData.targetPos || 0;
div.querySelector('#spanScheduleTargetPos').innerText = scheduleData.targetPos || 0;
syncSliderProgress(div.querySelector('#slidScheduleTargetPos'));
const initialTilt = (typeof scheduleData.targetTilt !== 'undefined' && scheduleData.targetTilt >= 0) ? scheduleData.targetTilt : 0;
div.querySelector('#slidScheduleTargetTilt').value = initialTilt;
div.querySelector('#spanScheduleTargetTilt').innerText = initialTilt;
syncSliderProgress(div.querySelector('#slidScheduleTargetTilt'));
const enabledToggle = div.querySelector('#cbScheduleEnabled');
enabledToggle.checked = (typeof scheduleData.enabled === 'undefined') ? true : makeBool(scheduleData.enabled);
const headerState = div.querySelector('.overlayHeader-state');
const syncEnabledBadge = () => { headerState.style.display = enabledToggle.checked ? 'none' : ''; };
syncEnabledBadge();
enabledToggle.addEventListener('change', syncEnabledBadge);
div.querySelector('#selScheduleRetries').value = scheduleData.retries || 0;
let targetSupportsTilt = false;
let posChoice = 'open';
const isPositionChoice = c => c === 'open' || c === 'close' || c === 'custom';
const posChoiceButtons = {
open: '#btnSchedulePosOpen', close: '#btnSchedulePosClose', custom: '#btnSchedulePosCustom',
tiltonly: '#btnSchedulePosTiltOnly', my: '#btnSchedulePosMy'
};
const updateSliderVisibility = () => {
div.querySelector('#divScheduleSliderGroup').style.display = (posChoice === 'custom') ? '' : 'none';
div.querySelector('#divScheduleTiltSliderGroup').style.display =
(posChoice === 'tiltonly' || (isPositionChoice(posChoice) && targetSupportsTilt)) ? '' : 'none';
};
const setPosChoice = (choice, markDirty) => {
posChoice = choice;
const hidden = div.querySelector('#fldSchedulePositionMode');
hidden.value = isPositionChoice(choice) ? 'position' : choice;
Object.entries(posChoiceButtons).forEach(([key, sel]) => {
div.querySelector(sel).classList.toggle('active', key === choice);
});
if (choice === 'open' || choice === 'close') {
const slider = div.querySelector('#slidScheduleTargetPos');
slider.value = (choice === 'open') ? 0 : 100;
div.querySelector('#spanScheduleTargetPos').innerText = slider.value;
syncSliderProgress(slider);
}
updateSliderVisibility();
updateIncompatibilityNote();
if (markDirty) hidden.dispatchEvent(new Event('change', { bubbles: true }));
};
let groupMyIncompatible = false, groupTiltIncompatible = false;
const updateIncompatibilityNote = () => {
const mode = div.querySelector('#fldSchedulePositionMode').value;
const note = div.querySelector('#divScheduleMyGroupNote');
if (mode === 'my' && groupMyIncompatible) {
note.innerText = tr('SCHEDULE_MY_GROUP_NOTE');
note.style.display = '';
} else if (mode === 'tiltonly' && groupTiltIncompatible) {
note.innerText = tr('SCHEDULE_TILT_GROUP_NOTE');
note.style.display = '';
} else {
note.style.display = 'none';
}
};
setPosChoice(
scheduleData.positionMode === 'my' ? 'my'
: scheduleData.positionMode === 'tiltonly' ? 'tiltonly'
: scheduleData.targetPos === 100 ? 'close'
: (scheduleData.targetPos ? 'custom' : 'open'),
false);
const TILT_TYPE_TILTONLY = 3;
const positionBtns = ['open', 'close', 'custom'].map(k => div.querySelector(posChoiceButtons[k]));
const updateModeAvailability = (targetType, targetId) => {
const myBtn = div.querySelector('#btnSchedulePosMy');
const tiltOnlyBtn = div.querySelector('#btnSchedulePosTiltOnly');
let supportsMy = true;
let targetIsTiltOnly = false;
groupMyIncompatible = false;
groupTiltIncompatible = false;
if (targetType === 'group') {
const group = (this.groups || []).find(g => g.groupId === targetId);
const linked = (group && group.linkedShades) || [];
groupMyIncompatible = linked.some(s => this.noMyShadeTypes.includes(s.shadeType));
targetSupportsTilt = linked.some(ls => {
const full = (this.shades || []).find(s => s.shadeId === ls.shadeId);
return full && full.tiltType > 0;
});
groupTiltIncompatible = targetSupportsTilt && linked.some(ls => {
const full = (this.shades || []).find(s => s.shadeId === ls.shadeId);
return !full || !(full.tiltType > 0);
});
targetIsTiltOnly = linked.length > 0 && linked.every(ls => {
const full = (this.shades || []).find(s => s.shadeId === ls.shadeId);
return full && full.tiltType === TILT_TYPE_TILTONLY;
});
} else {
let shadeType, tiltType;
if (lockedTarget) {
const typeEl = get('selShadeType');
if (typeEl) {
shadeType = parseInt(typeEl.value, 10);
const st = this.shadeTypes.find(x => x.type === shadeType);
const tiltEl = get('selTiltType');
tiltType = (st && st.tilt && tiltEl) ? parseInt(tiltEl.value, 10) : 0;
}
}
if (typeof shadeType === 'undefined') {
const shade = (this.shades || []).find(s => s.shadeId === targetId);
shadeType = shade ? shade.shadeType : undefined;
tiltType = shade ? shade.tiltType : 0;
}
supportsMy = (typeof shadeType === 'undefined') ? true : this.shadeTypeSupportsMy(shadeType);
targetSupportsTilt = !!(tiltType > 0);
targetIsTiltOnly = (tiltType === TILT_TYPE_TILTONLY);
}
myBtn.style.display = supportsMy ? '' : 'none';
myBtn.disabled = !supportsMy;
tiltOnlyBtn.style.display = targetSupportsTilt ? '' : 'none';
tiltOnlyBtn.disabled = !targetSupportsTilt;
positionBtns.forEach(btn => {
btn.style.display = targetIsTiltOnly ? 'none' : '';
btn.disabled = targetIsTiltOnly;
});
const choiceUnavailable = (!supportsMy && posChoice === 'my')
|| (!targetSupportsTilt && posChoice === 'tiltonly')
|| (targetIsTiltOnly && isPositionChoice(posChoice));
if (choiceUnavailable) {
setPosChoice(targetIsTiltOnly ? 'tiltonly' : 'open', true);
} else {
updateSliderVisibility();
updateIncompatibilityNote();
}
};
updateModeAvailability(scheduleData.targetType, scheduleData.targetId);
if (!lockedTarget) {
div.querySelector('#selScheduleTarget').addEventListener('change', (e) => {
const [tType, tIdStr] = (e.target.value || '').split(':');
updateModeAvailability(tType, parseInt(tIdStr, 10));
});
}
watchDirty(div);
div.querySelector('#btnScheduleAllDays').onclick = () => {
const dayBtns = div.querySelectorAll('.schedule-day-btn');
const allActive = Array.from(dayBtns).every(b => b.classList.contains('active'));
dayBtns.forEach(b => {
b.classList.toggle('active', !allActive);
b.dispatchEvent(new Event('change', { bubbles: true }));
});
};
Object.entries(posChoiceButtons).forEach(([choice, sel]) => {
div.querySelector(sel).onclick = () => setPosChoice(choice, true);
});
div.querySelector('#btnScheduleGoBack').onclick = () => requestCloseOverlay(div);
div.querySelector('#btnSaveSchedule').onclick = () => this.saveSchedule(div);
}
saveSchedule(overlayEl) {
if (!overlayEl) overlayEl = get('divEditScheduleOverlay');
if (!overlayEl) return;
const scheduleIdAttr = overlayEl.getAttribute('data-scheduleid');
const isNew = !scheduleIdAttr;
let dayMask = 0;
overlayEl.querySelectorAll('.schedule-day-btn.active').forEach(btn => {
dayMask |= parseInt(btn.getAttribute('data-bit'), 10);
});
const targetSel = overlayEl.querySelector('#selScheduleTarget');
let targetType, targetId;
if (targetSel) {
const targetVal = targetSel.value || '';
[targetType, targetId] = targetVal.split(':');
targetId = parseInt(targetId, 10);
} else {
targetType = overlayEl.getAttribute('data-targettype');
targetId = parseInt(overlayEl.getAttribute('data-targetid'), 10);
}
const timeVal = overlayEl.querySelector('#fldScheduleTime').value || '00:00';
const [hourStr, minuteStr] = timeVal.split(':');
const tiltGroup = overlayEl.querySelector('#divScheduleTiltSliderGroup');
const targetTilt = (tiltGroup && tiltGroup.style.display !== 'none')
? parseInt(overlayEl.querySelector('#slidScheduleTargetTilt').value, 10)
: -1;
const obj = {
name: overlayEl.querySelector('#fldScheduleName').value || '',
dayMask: dayMask,
hour: parseInt(hourStr, 10),
minute: parseInt(minuteStr, 10),
targetType: targetType,
targetId: targetId,
targetPos: parseInt(overlayEl.querySelector('#slidScheduleTargetPos').value, 10),
targetTilt: targetTilt,
positionMode: overlayEl.querySelector('#fldSchedulePositionMode').value || 'position',
enabled: overlayEl.querySelector('#cbScheduleEnabled').checked,
retries: parseInt(overlayEl.querySelector('#selScheduleRetries').value, 10),
timeRef: overlayEl.querySelector('#selScheduleTimeRef')?.value || 'clock',
sunOffset: overlayEl.querySelector('#cbScheduleSunOffsetEnabled').checked
? (parseInt(overlayEl.querySelector('#inputScheduleSunOffset').value, 10) || 0)
: 0
};
const checks = [
[dayMask === 0, 'ERR_SCHEDULE_NO_DAYS'],
[!targetType || isNaN(targetId), 'ERR_SCHEDULE_NO_TARGET']
];
const error = checks.find(c => c[0]);
if (error) return ui.errorMessage(tr(error[1]));
if (!isNew) obj.id = parseInt(scheduleIdAttr, 10);
putJSONSync(isNew ? '/addSchedule' : '/saveSchedule', obj, (err, sc) => {
if (err) return ui.serviceError(err);
logger.debug('Schedule saved:', sc);
ui.successMessage(tr(isNew ? 'MSG_ADD_SUCCESS' : 'MSG_SAVE_SUCCESS'));
clearDirty(overlayEl);
this.updateScheduleList(() => this.refreshOpenTargetScheduleBadges());
closeOverlay(overlayEl);
});
}
deleteSchedule(scheduleId) {
const sc = (this.schedules || []).find(x => x.id === scheduleId);
const desc = sc ? `${sc.hour.toString().padStart(2, '0')}:${sc.minute.toString().padStart(2, '0')} - ${this.scheduleTargetName(sc)}` : '';
let prompt = ui.promptMessage(tr('PROMPT_DELETE_SCHEDULE'), () => {
putJSONSync('/deleteSchedule', { id: scheduleId }, (err) => {
if (err) ui.serviceError(err);
this.updateScheduleList(() => this.refreshOpenTargetScheduleBadges());
prompt.remove();
});
});
const subMsg = prompt.querySelector('.sub-message');
if (subMsg) subMsg.innerHTML = `<p>${tr('PROMPT_DELETE_SCHEDULE_CONFIRM').replace('{SCHEDULE_DESC}', desc)}</p>`;
}
setRepeaterList(addresses) {
let divCfg = '';
if (typeof addresses !== 'undefined') {
for (let i = 0; i < addresses.length; i++) {
divCfg += `<div class="somfyRepeater" data-address="${addresses[i]}"><div class="shade-icon-wrapper"><svg><use href="#svg-emptyRepeater"></use></svg></div><div class="repeater-name-block"><div class="name-text">${tr("REPEATER_ADDRESS")}</div><div class="cfg-room">${addresses[i]}</div></div><div class="divEditDelete-svg" onclick="event.stopPropagation(); somfy.unlinkRepeater('${addresses[i]}');"><svg class="icon-svg" style="color: var(--color-danger);"><use href=#svg-trash></use></svg></div></div>`;
}
}
get('divRepeatList').innerHTML = divCfg;
this.checkEmptyState();
}
updateRepeatList() {
getJSONSync('/repeaters', (err, repeaters) => {
if (err) {
logger.error('Failed to load repeaters:', err);
ui.serviceError(err);
}
else this.setRepeaterList(repeaters);
});
}
linkRepeatRemote() {
let div = document.createElement('div');
div.className = 'inst-overlay';
div.id = 'divLinkRepeater';
div.setAttribute('data-type', 'link-repeatremote');
div.innerHTML = `
        <div class="instructions-content">
        ${overlayHeader("REPEAT_REMOTE_TITLE", "REPEAT_REMOTE_DESC", "svg-repeater")}
        <div class="overlay-scroll-content">

        <div class="uniblocStep">
        <div class="step-item"><div class="step-number">a</div><div class="step-text">${tr("REPEAT_REMOTE_DESC_1")}</div></div>
        <div class="step-item"><div class="step-number">b</div><div class="step-text">${tr("REPEAT_REMOTE_DESC_2")}</div></div>
        <div class="step-item"><div class="step-number">c</div><div class="step-text">${tr("REPEAT_REMOTE_DESC_5")}</div></div>
        </div>

        <div class="warning">
        <div class="warning-header">
        <svg><use href="#svg-warning"></use></svg>
        <b>${tr("MSG_ALERT")}</b>
        </div>

        <div class="information-text">
        <span>${tr("REPEAT_REMOTE_DESC_4")}<br><br>${tr("REPEAT_REMOTE_DESC_3")}</span>
        </div>
        </div>

        </div>
        <div class="hrDivFooter-Instruc"></div>
        <div class="button-container-overlay">
        <button id="btnStopLinking" type="button" line>${tr("BT_CANCEL_1")}</button>
        </div>
        </div>`;
div.querySelector('#btnStopLinking').onclick = () => requestCloseOverlay(div);
shOverlay(div);
setOverlayLock(div, 'confirm', {
titleKey: 'PROMPT_LINK_REPEATER_TITLE',
msgKey: 'PROMPT_LINK_REPEATER_MSG',
});
return div;
}
unlinkRepeater(address) {
let prompt = ui.promptMessage(tr('PROMPT_UNLINK_REPEATER'), () => {
putJSONSync('/unlinkRepeater', { address: address }, (err, repeaters) => {
if (err) ui.serviceError(err);
else this.setRepeaterList(repeaters);
prompt.remove();
});
});
}
}
var somfy = new Somfy();
class MQTT {
initialized = false;
storedRootTopic = '';
init() { this.initialized = true; }
async loadMQTT() {
getJSONSync('/mqttsettings', (err, settings) => {
if (err) {
ui.serviceError(err);
} else {
this.storedRootTopic = settings.rootTopic || '';
ui.toElement(get('divMQTT'), { mqtt: settings });
initSecretField(get('fldMqttPassword'), settings.hasPassword);
get('divDiscoveryTopic').style.display = settings.pubDisco ? '' : 'none';
watchDirty(get('divMQTT'));
}
});
}
connectMQTT() {
const d = get('divMQTT');
let obj = ui.fromElement(d);
obj.mqtt.password = secretValue(get('fldMqttPassword'));
if (obj.mqtt.enabled && (typeof obj.mqtt.hostname !== 'string' || obj.mqtt.hostname.length === 0)) {
ui.errorMessage(tr('ERR_HOSTNAME'), tr('ERR_MQTT_HOSTNAME_REQUIRED'));
return;
}
if (typeof obj.mqtt.hostname === 'string' && obj.mqtt.hostname.length > 64) {
ui.errorMessage(tr('ERR_HOSTNAME'), tr('ERR_HOSTNAME_MAX_LENGTH_64'));
return;
}
if (isNaN(obj.mqtt.port) || obj.mqtt.port < 1 || obj.mqtt.port > 65535) {
ui.errorMessage(tr('ERR_PORT_INVALID'), tr('ERR_MQTT_PORT_HINT'));
return;
}
if (typeof obj.mqtt.username === 'string' && obj.mqtt.username.length > 32) {
ui.errorMessage(tr('ERR_USERNAME_INVALID'), tr('ERR_USERNAME_MAX_LENGTH_32'));
return;
}
if (typeof obj.mqtt.password === 'string' && obj.mqtt.password.length > 32) {
ui.errorMessage(tr('ERR_PASSWORD_INVALID'), tr('ERR_PASSWORD_MAX_LENGTH_32'));
return;
}
if (typeof obj.mqtt.rootTopic === 'string' && obj.mqtt.rootTopic.length > 64) {
ui.errorMessage(tr('ERR_ROOT_TOPIC_INVALID'), tr('ERR_ROOT_TOPIC_MAX_LENGTH_64'));
return;
}
if (typeof obj.mqtt.rootTopic !== 'string' || obj.mqtt.rootTopic.trim().length === 0
|| /[+#]/.test(obj.mqtt.rootTopic) || /^[\/$]/.test(obj.mqtt.rootTopic)) {
ui.errorMessage(tr('ERR_ROOT_TOPIC_INVALID'), tr('ERR_ROOT_TOPIC_HINT'));
const fld = get('fldMqttTopic');
fld.value = this.storedRootTopic;
fld.focus();
fld.select();
return;
}
putJSONSync('/connectmqtt', obj.mqtt, (err, response) => {
if (err) {
ui.serviceError(err);
logger.error('Failed to save MQTT settings:', err);
} else {
ui.successMessage(tr('MSG_SAVE_SUCCESS'));
logger.debug('MQTT settings saved:', response);
if (response && typeof response.rootTopic === 'string') this.storedRootTopic = response.rootTopic;
clearDirty();
}
});
}
}
var mqtt = new MQTT();
const DEBUG_FAKE_OTA = false;
const DEBUG_FAKE_OTA_PCT = 60;
class Firmware {
initialized = false;
init() { this.initialized = true; }
isMobile() {
return /Android|iPhone|iPad|iPod|BlackBerry|BB|PlayBook|IEMobile|Windows Phone|Kindle|Silk|Opera Mini/i.test(navigator.userAgent);
}
async backup() {
let overlay = ui.waitMessage(get('divContainer'));
return await new Promise((resolve, reject) => {
let xhr = new XMLHttpRequest();
xhr.responseType = 'blob';
xhr.onreadystatechange = (evt) => {
if (xhr.readyState === 4 && xhr.status === 200) {
let obj = window.URL.createObjectURL(xhr.response);
var link = document.createElement('a');
document.body.appendChild(link);
let header = xhr.getResponseHeader('content-disposition');
let fname = 'backup';
if (typeof header !== 'undefined') {
let start = header.indexOf('filename="');
if (start >= 0) {
let length = header.length;
fname = header.substring(start + 10, length - 1);
}
}
logger.debug('Backup file downloaded:', fname);
link.setAttribute('download', fname);
link.setAttribute('href', obj);
link.click();
link.remove();
setTimeout(() => { window.URL.revokeObjectURL(obj); }, 0);
}
};
xhr.onload = (evt) => {
if (typeof overlay !== 'undefined') overlay.remove();
let status = xhr.status;
if (status !== 200) {
let err = xhr.response || {};
err.htmlError = status;
err.service = `GET /backup`;
if (typeof err.desc === 'undefined') err.desc = xhr.statusText || httpStatusText[xhr.status || 500];
logger.error('Backup download failed:', err);
reject(err);
}
else {
resolve();
}
};
xhr.onerror = (evt) => {
if (typeof overlay !== 'undefined') overlay.remove();
let err = {
htmlError: xhr.status || 500,
service: `GET /backup`
};
if (typeof err.desc === 'undefined') err.desc = xhr.statusText || httpStatusText[xhr.status || 500];
logger.error('Backup request failed:', err);
reject(err);
};
xhr.onabort = (evt) => {
if (typeof overlay !== 'undefined') overlay.remove();
reject({ htmlError: xhr.status || 500, service: 'GET /backup' });
};
xhr.open('GET', baseUrl.length > 0 ? `${baseUrl}/backup` : '/backup', true);
xhr.setRequestHeader('apikey', (typeof security !== 'undefined' ? security.apiKey : '') || '');
xhr.send();
});
}
restore() {
let div = this.createFileUploader('/restore');
let instContent = div.querySelector('.instructions-content');
const opts = [
['cbRestoreShades', 'shades', 'RESTORE_SHADES_GROUPS', 1],
['cbRestoreRepeaters', 'repeaters', 'RESTORE_REPEATERS', 0],
['cbRestoreSystem', 'settings', 'RESTORE_SYSTEM_SETTINGS', 0],
['cbRestoreNetwork', 'network', 'RESTORE_NETWORK_SETTINGS', 0],
['cbRestoreMQTT', 'mqtt', 'RESTORE_MQTT_SETTINGS', 0],
['cbRestoreTransceiver', 'transceiver', 'RESTORE_RADIO_SETTINGS', 0]
];
let html = opts.map(o => `
        <label class="uniRow dirty-target">
        <div class="uniLabel">${tr(o[2])}</div>
        <div class="uniRight">
        <span class="switch">
        <input id="${o[0]}" type="checkbox" data-bind="${o[1]}" ${o[3]?'checked':''}>
        <div></div>
        </span>
        </div>
        </label>`).join('');
let divInstText = div.querySelector('#divInstText');
if (divInstText) {
divInstText.innerHTML = `
            <div class="uniblocStep"><div>${tr('RESTORE_SELECT_FILE')}</div></div>
            <div id="jsUniRestore" class="uniblocCol">${html}</div>`;
}
instContent.insertAdjacentHTML('afterbegin', overlayHeader('RESTORE_TITLE', 'RESTORE_DESC', 'svg-restore', { subtitle: 'RESTORE_DESC', showInfo: false }));
shOverlay(div);
}
createFileUploader(service) {
const isRestore = service === '/restore', isMob = this.isMobile(), div = document.createElement('div');
div.id = 'divUploadFile';
div.className = 'inst-overlay no-feedback';
const step = (n, content, hide = false) => hide ? '' : `
        <div class="v-step-item">
        <div class="v-step-left"><div class="step-counter">${n}</div><div class="v-step-line"></div></div>
        <div class="v-step-right"><div>${content}</div></div>
        </div>`;
const firmwareHelp = service === '/updateFirmware' ? `
        <div class="help-container" data-tooltip-tr="FIRMWARE_MA_UPDATE_SYS_TOOLTIP">
        <svg class="help-svg"><use href="#icon-question"></use></svg>
        </div>` : service === '/updateApplication' ? `
        <div class="help-container" data-tooltip-tr="FIRMWARE_MA_UPDATE_LITTLEFS_TOOLTIP">
        <svg class="help-svg"><use href="#icon-question"></use></svg>
        </div>` : '';
div.innerHTML = `
        <div class="instructions-content UploadFile-content">
        <div class="overlay-scroll-content">
        <form method="POST" action="#" enctype="multipart/form-data" id="frmUploadApp">
        <div id="divInstText"></div>
        <div class="vertical-steps-container">
        ${step(1, `
        <div>${tr(service === '/updateFirmware' ? 'FIRMWARE_MA_UPDATE_SYS' : 'FIRMWARE_MA_UPDATE_LITTLEFS')}${firmwareHelp}</div>
        <a href="https://github.com/xkain/TESTRTS/releases" target="_blank" class="link" style="display:block; margin-top:5px;">${tr('FIRMWARE_MA_UPDATE_FROM_GITHUB')}<svg class="svgInTextSmall"><use href="#svg-linkOut"></use></svg></a>
        `, isRestore)}
        <div class="v-step-item ${isRestore ? '' : 'has-extra-content'}" style="${isRestore ? 'height:auto;margin:15px 0 0' : ''}">
        <div class="v-step-left" style="${isRestore ? 'display:none' : ''}">
        <div class="step-counter">2</div><div class="v-step-line"></div>
        </div>
        <div class="v-step-right" style="${isRestore ? 'padding-left:0' : ''}">
        <input id="fileName" type="file" name="updateFS" style="display:none"
        onchange="const f=this.files[0];if(f){const s=get('span-selected-file');s.innerText=f.name;s.style.opacity='1';firmware.checkBackupVersion(f)}"/>
        <label for="fileName" class="custom-file-upload">
        <span id="span-selected-file" class="file-name-display">${tr('CHOOSE_FILE')}</span>
        <div class="file-icon-btn"><svg><use href="#svg-upload"></use></svg></div>
        </label>
        </div>
        </div>
        <div class="v-step-item" style="${isRestore ? 'display:none' : ''}">
        <div class="v-step-left"><div class="step-counter">3</div></div>
        <div class="v-step-right"><div>${tr('FIRMWARE_MA_UPDATE_VERIFY_0')} <svg class="svgInText"><use href="#svg-save"></use></svg> ${tr('FIRMWARE_MA_UPDATE_VERIFY_1')}</div></div>
        </div>
        </div>

        <div class="warning" style="${isRestore ? '' : 'display:none'}">
        <div class="warning-header">
        <svg><use href="#svg-warning"></use></svg>
        <b>${tr('MSG_ALERT')}</b>
        </div>
        <div class="information-text">
        <span>${tr('RESTORE_NETWORK_WARNING')}</span>
        </div>
        </div>

        <div id="divFileUploadProgress" style="display:none;margin:15px 0">
        <div class="progress-bar-header"><span class="progress-bar-label"></span><span class="progress-bar-value" id="progFileUpload-value">0%</span></div>
        <div class="progress-bar" id="progFileUpload"><div class="progress-bar-fill"></div></div>
        </div>
        <!-- Affiché uniquement pour /updateFirmware et /updateApplication une fois le téléversement
             confirmé par le serveur (200) : l'appareil va redémarrer dans l'instant (cf. rebootDelay
             côté firmware, WebSystem.cpp), ce n'est donc plus utile de laisser la barre figée à 100%
             en attendant un clic manuel sur "Fermer" -- voir firmware.uploadFile(). -->
        <div id="divFileUploadSuccess" class="information" style="display:none;margin:15px 0">
        <div class="information-header">
        <span class="remote-search-spinner"></span>
        <b>${tr('FIRMWARE_MA_UPDATE_SUCCESS_TITLE')}</b>
        </div>
        <div class="information-text"><span>${tr('FIRMWARE_MA_UPDATE_SUCCESS_DESC')}</span></div>
        </div>
        </div>
        <div class="hrDivFooter-Instruc"></div>
        <div class="button-container-overlay"><div class="footer-sticky-content">
        <div class="uniRow backup-row" style="${isRestore ? 'display:none' : ''}">
        <div class="uniText">
        <span class="uniLabel">${tr('FIRMWARE_MT_SAVE_BACKUP')}</span>
        <span class="uniStatus">${tr(isMob ? 'FIRMWARE_MT_SAVE_BACKUP_DESC_MOB' : 'FIRMWARE_MT_SAVE_BACKUP_DESC')}</span>
        </div>
        <div id="btnBackupCfg" class="gitBackup" onclick="firmware.backup()"><svg><use href="#svg-save"></use></svg></div>
        </div>
        <!-- Remplace la ligne de sauvegarde ci-dessus une fois le transfert lancé (cf.
             firmware.uploadFile()) : le verrou 'hard' posé sur l'overlay à cet instant empêche déjà
             toute fermeture réelle (requestCloseOverlay() ne fait plus qu'un flash visuel), inutile
             donc de laisser "Annuler" affiché -- ce texte réutilise les mêmes clés que le message de
             ce verrou (setOverlayLock plus bas), déjà pensées pour prévenir de ne pas fermer la page
             ni débrancher l'appareil pendant une installation/restauration OTA. -->
        <div id="divUploadInProgressNotice" class="warning" style="display:none">
        <div class="warning-header">
        <svg><use href="#svg-warning"></use></svg>
        <b>${tr(isRestore ? 'PROMPT_RESTORE_IN_PROGRESS_TITLE' : 'PROMPT_UPDATE_IN_PROGRESS_TITLE')}</b>
        </div>
        <div class="information-text">
        <span>${tr(isRestore ? 'PROMPT_RESTORE_IN_PROGRESS_MSG' : 'PROMPT_UPDATE_IN_PROGRESS_MSG')}</span>
        </div>
        </div>
        <div class="button-container-row">
        <button id="btnClose" line type="button" onclick="requestCloseOverlay(get('divUploadFile'))">${tr('BT_CANCEL_1')}</button>
        <button id="btnUploadFile" type="button" onclick="firmware.uploadFile('${service}',get('divUploadFile'),ui.fromElement(get('divUploadFile')))">${tr('BT_UPLOAD_FILE')}</button>
        </div>
        </div></div>
        </form>
        </div>
        </div>`;
return div;
}
checkBackupVersion(file) {
const reader = new FileReader();
reader.onload = (e) => {
const lines = e.target.result.split('\n');
if (lines.length > 0) {
const ver = parseInt(lines[0].split(',')[0]);
if (!isNaN(ver) && ver < 25) {
let prompt = ui.promptMessage(tr('PROMPT_RESTORE_FILE_TITLE'), () => closeOverlay(prompt));
prompt.querySelector('.sub-message').innerHTML = `<p style="color:var(--color-warning); font-weight:bold;"><p>${tr('PROMPT_RESTORE_FILE_DESC')}</p><p><b>${tr('PROMPT_RESTORE_FILE_DESC_1')}</b></p><p>${tr('PROMPT_RESTORE_FILE_DESC_2')}</p>`;
const btnCan = prompt.querySelector('button[line]');
if (btnCan) {
btnCan.onclick = () => {
get('fileName').value = "";
get('span-selected-file').innerText = tr('CHOOSE_FILE');
closeOverlay(prompt);
};
}
}
}
};
reader.readAsText(file.slice(0, 100));
}
procMemoryStatus(mem) {
let sp = get('spanFreeMemory');
if (sp) sp.innerHTML = mem.free.fmt("#,##0 ");
sp = get('spanMaxMemory');
if (sp) sp.innerHTML = mem.max.fmt('#,##0 ');
sp = get('spanMinMemory');
if (sp) sp.innerHTML = mem.min.fmt('#,##0 ');
if (mem && mem.free) {
const totalRam = mem.total ? mem.total : 265672;
const ramUsedPct = Math.min(100, Math.max(0, Math.round(((totalRam - mem.free) / totalRam) * 100)));
const cRam = get('circle-ram');
if (cRam) {
cRam.style.background = `conic-gradient(#3b82f6 ${ramUsedPct}%, var(--color-circle-indicator) 0%)`;
cRam.innerHTML = `<span>${ramUsedPct}%</span>`;
}
}
}
procFwStatus(rel) {
const gitInst = get('divGitInstall');
if (gitInst && rel.status === 0) {
logger.warn('Overlay d\'installation orphelin (appareil redémarré sans statut de fin) : retiré');
clearOverlayLock(gitInst);
gitInst.remove();
}
if (gitInst && rel.status === 4) {
clearOverlayLock(gitInst);
gitInst.remove();
if (rel.error === 0) {
const subMsg = `${tr('GIT_RELEASE_SUCCES_1')}<br>${tr('GIT_RELEASE_SUCCES_2')}`;
ui.successMessage(tr('GIT_RELEASE_SUCCESS_TITLE'), subMsg);
} else {
let e = errors.find(x => x.code === rel.error) || { desc: tr('ERR_UNSPECIFIED') };
ui.errorMessage(e.desc);
}
return;
}
const divsGlobal = document.querySelectorAll('.firmware-message');
const btnGit = get('btnUpdateGithub');
const gitDesc = get('gitUpdateDesc');
const statusRight = get('gitUpdateStatusRight');
if (divsGlobal.length === 0) return;
divsGlobal.forEach(div => {
div.classList.remove('procFwStatusshow');
div.onclick = null;
});
if (rel.available && rel.status === 0 && rel.checkForUpdate !== false) {
divsGlobal.forEach(div => {
div.classList.add('procFwStatusshow');
div.style.cursor = 'pointer';
div.onclick = () => { firmware.updateGithub(); };
div.innerHTML = `<span>${tr('FW_UPDATE_AVAILABLE')}</span>`;
});
if (btnGit) {
const currentMajor = this.getMainVersion(rel.appVersion?.name || get('spanFwVersion')?.innerText);
const targetMajor = this.getMainVersion(rel.latest?.name);
const isBlocked = (currentMajor < 3 && targetMajor >= 3) || (currentMajor >= 3 && targetMajor < 3);
if (gitDesc) {
gitDesc.innerHTML = isBlocked
? tr('FW_UPDATE_USB_DESC').replace('%1', rel.latest.name)
: tr('FW_UPDATE_ACTION_DESC');
}
if (statusRight) {
const badgeText = isBlocked ? "USB REQUIS" : rel.latest.name;
statusRight.innerHTML = `<span class="status-badge state-danger">${badgeText}</span>`;
}
}
}
else if (rel.status === 4 && rel.error !== 0) {
let e = errors.find(x => x.code === rel.error) || { desc: tr('ERR_UNSPECIFIED') };
let inst = get('divGitInstall');
if (inst) inst.remove();
ui.errorMessage(e.desc);
}
else {
if (btnGit) {
if (gitDesc) gitDesc.innerHTML = tr('FW_UPDATE_UPTODATE');
if (statusRight) {
const currentVersion = rel.appVersion?.name || get('spanFwVersion')?.innerText || "";
statusRight.innerHTML = `<span class="status-badge state-success">v${currentVersion}</span>`;
}
}
}
}
procUpdateProgress(prog) {
const pct = Math.round((prog.loaded / prog.total) * 100);
general.reloadApp = true;
const git = get('divGitInstall');
if (!git) return;
const isApplication = prog.part === 100;
const p = isApplication ?
get('progApplicationDownload') :
get('progFirmwareDownload');
if (p) {
p.style.setProperty('--progress', `${pct}%`);
const val = get(`${p.id}-value`);
if (val) val.textContent = `${pct}%`;
}
ui.wizSetStep(git, isApplication ? (pct >= 100 ? 3 : 2) : 1);
}
procLangRestore(msg) {
const status = get('divGitPostStatus');
if (!status) return;
const spinner = status.querySelector('.remote-search-spinner');
const textEl = get('spanGitPostStatusText');
status.style.display = '';
if (msg.state === 'start') {
if (spinner) spinner.style.display = '';
if (textEl) textEl.textContent = tr('GIT_LANG_RESTORE_IN_PROGRESS').replace('%1', msg.code);
} else {
if (spinner) spinner.style.display = 'none';
if (textEl) {
textEl.textContent = tr(msg.state === 'success' ? 'GIT_LANG_RESTORE_SUCCESS' : 'GIT_LANG_RESTORE_FAILED').replace('%1', msg.code);
}
}
}
getMainVersion(verStr) {
if (!verStr) return 0;
const match = verStr.match(/[vV]?(\d+)/);
return match ? parseInt(match[1], 10) : 0;
}
renderGitInstallProgress(div, verName) {
const desc = tr('GIT_RELEASE_DESC').replace('%1', verName);
div.classList.remove('inst-overlay');
div.classList.add('modal-overlay');
document.body.classList.add('modal-open');
div.innerHTML = `
        <div class="message-content">

        ${modalHeader('GIT_RELEASE_TITLE', 'svg-github', {
subtitle: '',
})}

        ${wizardStepper(3, 'GIT_RELEASE_TITLE')}

        <div class="overlay-scroll-content">

        <div class="progress-bar-header"><span class="progress-bar-label">${tr('GIT_RELEASE_FIRMWARE_INSTALL_PROGRESS')}</span><span class="progress-bar-value" id="progFirmwareDownload-value">0%</span></div>
        <div class="progress-bar" id="progFirmwareDownload"><div class="progress-bar-fill"></div></div>
        <div class="progress-bar-header"><span class="progress-bar-label">${tr('GIT_RELEASE_APPLICATION_INSTALL_PROGRESS')}</span><span class="progress-bar-value" id="progApplicationDownload-value">0%</span></div>
        <div class="progress-bar" id="progApplicationDownload"><div class="progress-bar-fill"></div></div>

        <!-- Masqué par défaut : affiché uniquement pendant la réinstallation best-effort du
        pack de langue actif après l'écriture du filesystem.bin (cf. procLangRestore, événement
        socket gitLangRestore émis par GitUpdater::beginUpdate()). La barre ci-dessus reste
        figée à 100% pendant ce temps -- cf. procUpdateProgress/procFwStatus. -->
        <div id="divGitPostStatus" class="information remote-search-status" style="display:none;">
        <div class="information-header">
        <span class="remote-search-spinner"></span>
        <b id="spanGitPostStatusText"></b>
        </div>
        </div>
        </div>

        <div class="hrModal margin0"></div>
        <div class="button-container-modal">
        <div class="button-content-modal">

        <div class="git-install-footer-info">
        <svg><use href="#svg-power"></use></svg>
        <span>${tr('GIT_RELEASE_KEEP_POWERED')}</span>
        </div>
        </div>
        </div>
        </div>`;
const hP = div.querySelector('.instructions-header p');
if (hP) hP.innerHTML = desc;
ui.wizSetStep(div, 1);
}
confirmInstallGitRelease(div) {
const prompt = ui.promptMessage(get('divContainer'), tr('GIT_RELEASE_CONFIRM_TITLE'), () => {
this.installGitRelease(div);
}, true, 'svg-github');
const sel = div.querySelector('#selVersion');
const opt = sel && sel.selectedIndex !== -1 ? sel.options[sel.selectedIndex] : null;
const isReinstall = !!opt && opt.getAttribute('data-vernum') === div.getAttribute('data-currentvernum');
prompt.querySelector('.sub-message').innerHTML = `<p>${tr(isReinstall ? 'GIT_RELEASE_CONFIRM_SUB_REINSTALL' : 'GIT_RELEASE_CONFIRM_SUB')}</p>`;
}
async installGitRelease(div) {
let obj = ui.fromElement(div);
if (DEBUG_FAKE_OTA) {
this.renderGitInstallProgress(div, obj.version || 'X.X.X');
const fake = { progFirmwareDownload: 100, progApplicationDownload: DEBUG_FAKE_OTA_PCT };
Object.keys(fake).forEach(id => {
const p = div.querySelector(`#${id}`);
if (p) {
p.style.setProperty('--progress', `${fake[id]}%`);
const val = div.querySelector(`#${id}-value`);
if (val) val.textContent = `${fake[id]}%`;
}
});
ui.wizSetStep(div, 2);
return;
}
if (!this.isMobile()) {
try { await firmware.backup(); }
catch (err) { return ui.serviceError(div, err); }
}
this.gitSyncFetch(`/downloadFirmware?ver=${obj.version}`, { method: 'POST' }, (err, ver) => {
if (err) return ui.serviceError(err);
general.reloadApp = true;
setOverlayLock(div, 'hard', {
titleKey: 'PROMPT_UPDATE_IN_PROGRESS_TITLE',
msgKey: 'PROMPT_UPDATE_IN_PROGRESS_MSG',
});
this.renderGitInstallProgress(div, ver.name);
});
}
gitSyncOrigin() {
return `http://${isDevHost ? hst : window.location.hostname}:${GIT_SYNC_PORT}`;
}
gitSyncFetch(path, options, cb) {
const overlay = ui.waitMessage(get('divContainer'), 'WAIT_MSG_LOADING');
const opts = Object.assign({ headers: { apikey: security.apiKey || '' } }, options);
fetch(this.gitSyncOrigin() + path, opts)
.then(resp => resp.text().then(txt => ({ resp, txt })))
.then(({ resp, txt }) => {
overlay.remove();
let body = {};
try { body = txt ? JSON.parse(txt) : {}; } catch (e) { }
if (!resp.ok) {
body.htmlError = resp.status;
if (typeof body.desc === 'undefined') body.desc = resp.statusText || httpStatusText[resp.status] || httpStatusText['500'];
return cb(body, null);
}
cb(null, body);
})
.catch(err => { overlay.remove(); cb({ desc: String(err && err.message || err) }, null); });
}
updateGithub() {
this.gitSyncFetch('/getReleases', { method: 'GET' }, (err, rel) => {
if (err) {
if (typeof err.error !== 'undefined') {
let e = errors.find(x => x.code === err.error) || { desc: tr('ERR_UNSPECIFIED') };
return ui.errorMessage(e.desc);
}
return ui.serviceError(err);
}
const div = document.createElement('div'), isMob = this.isMobile();
const chip = (get('divContainer').getAttribute('data-chipmodel') || "").toLowerCase();
div.id = 'divGitInstall';
div.className = 'inst-overlay';
rel.releases.sort((a, b) => a.preRelease === b.preRelease && b.draft === a.draft ? 0 : a.preRelease ? 1 : -1);
const verNum = v => ((v?.major || 0) * 1000000) + ((v?.minor || 0) * 1000) + (v?.build || 0);
const currentVerNum = verNum(rel.appVersion);
div.setAttribute('data-currentvernum', currentVerNum);
const optsHtml = rel.releases.map(r => {
const name = r.name.toLowerCase();
if (name === 'main' || name === 'master' || (r.hwVersions.length > 0 && r.hwVersions.indexOf(chip) < 0)) return '';
const targetMajor = this.getMainVersion(r.version.name);
if (targetMajor < 3) return '';
if (verNum(r.version) < currentVerNum) return '';
return `<option value="${escAttr(r.version.name)}" data-prerelease="${r.preRelease}" data-vernum="${verNum(r.version)}">${escHtml(r.name)}${r.preRelease ? ' - Pre' : ''}</option>`;
}).join('');
div.innerHTML = `
            <div class="instructions-content github-content">
            ${overlayHeader('FIRMWARE_OTA_TITLE', 'FIRMWARE_OTA_TITLE_DESC', 'svg-github')}

            <!-- Zone statique du haut (Sélecteurs + Lien) -->
            <div class="overlay-static-content">
            <div class="baseFlexRow"><span class="uniLabel">${tr('FIRMWARE_MT_INSTALLED')}</span><span class="labelgrey">v${rel.appVersion.name}</span></div>
            <div class="baseFlexRow">
            <span class="uniLabel">${tr('FIRMWARE_OTA_AVAILABLE')}</span>
            <select id="selVersion" class="selectCompac" data-bind="version">${optsHtml}</select>
            </div>
            <a id="lnkGithubRelease" href="#" target="_blank" class="link">${tr('FIRMWARE_OTA_NOTE_GITHUB')}<svg class="svgInTextSmall"><use href="#svg-linkOut"></use></svg></a>


            </div> <!-- <-- ICI : Elle s'arrête bien juste après le lien 'lnkGithubRelease' -->
            <div class="hrModal"></div>

            <!-- Zone défilante pour les alertes et les notes de version -->
            <div class="overlay-scroll-content">
            <div id="divPrereleaseWarning" class="error" style="display:none;">
            <div class="error-header">
            <svg><use href="#svg-error"></use></svg>
            <b>${tr('MSG_ALERT')}</b>
            </div>
            <div class="information-text">
            <span id="spanUpdateWarning"></span>
            </div>
            </div>


            <div class="warningText"><svg><use href="#svg-warning"></use></svg><span>${tr('FIRMWARE_MT_CACHE')}</span></div>

            <!-- Conteneur des notes dynamique (prend le scroll) -->
            <div id="notesPreview" class="release-notes-preview">
            <div class="wifiConnectScan">
            <svg class="wait-spinner" viewBox="25 25 50 50"><circle class="wait-spinner-track" cx="50" cy="50" r="20" fill="none" stroke-width="3"/><circle class="wait-spinner-arc" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10"/></svg>
            </div>
            </div>
            </div>

            <!-- Footer collant en bas -->
            <div class="hrDivFooter-Instruc"></div>
            <div class="button-container-overlay">
            <div class="footer-sticky-content">
            <div class="uniRow">
            <div class="uniText"><span class="uniLabel">${tr('FIRMWARE_MT_SAVE_BACKUP')}</span><span class="uniStatus">${tr(isMob ? 'FIRMWARE_MT_SAVE_BACKUP_DESC_MOB' : 'FIRMWARE_MT_SAVE_BACKUP_DESC')}</span></div>
            <div id="btnBackupCfg" class="gitBackup" onclick="firmware.backup()"><svg><use href="#svg-save"></use></svg></div>
            </div>
            <div class="button-container-row">
            <button id="btnClose" line type="button" onclick="requestCloseOverlay(get('divGitInstall'))">${tr('BT_CANCEL_1')}</button>
            <button id="btnUpdate" type="button" class="btn-main" onclick="firmware.confirmInstallGitRelease(get('divGitInstall'))">${tr('BT_UPDATE')}</button>
            </div>
            </div>
            </div>
            </div>`;
shOverlay(div);
const sel = div.querySelector('#selVersion');
const updateNotes = async () => {
const nDiv = div.querySelector('#notesPreview'), lnk = div.querySelector('#lnkGithubRelease');
if (!nDiv || !sel || !sel.value) return;
nDiv.innerHTML = '<div class="wifiConnectScan"><svg class="wait-spinner" viewBox="25 25 50 50"><circle class="wait-spinner-track" cx="50" cy="50" r="20" fill="none" stroke-width="3"/><circle class="wait-spinner-arc" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10"/></svg></div>';
try {
const r = await firmware.getReleaseInfo(sel.value, true);
if (r?.info?.body) {
nDiv.innerHTML = firmware.parseMarkdown(r.info.body);
if (lnk && r.info.html_url) lnk.href = r.info.html_url;
} else {
throw new Error("No body");
}
} catch (e) {
nDiv.innerHTML = `
                    <div class="divGitNoteError">
                    <div class="gitNoteError">${tr('ERR_GIT_NOTE')}</div>
                    <div class="gitNoteErrorSub">${tr('FIRMWARE_OTA_NOTE_UPDATE')}</div>
                    </div>`;
}
};
sel.addEventListener('change', () => { this.gitReleaseSelected(div); updateNotes(); });
this.gitReleaseSelected(div);
updateNotes();
});
}
gitReleaseSelected(div) {
const sel = div.querySelector('#selVersion');
if (!sel || sel.selectedIndex === -1) return;
const opt = sel.options[sel.selectedIndex];
const isPre = opt.getAttribute('data-prerelease') === "true";
const divPre = div.querySelector('#divPrereleaseWarning');
const spanWarning = div.querySelector('#spanUpdateWarning');
const btnUpdate = div.querySelector('#btnUpdate');
if (btnUpdate) {
btnUpdate.disabled = false;
const isReinstall = opt.getAttribute('data-vernum') === div.getAttribute('data-currentvernum');
btnUpdate.textContent = tr(isReinstall ? 'BT_REINSTALL' : 'BT_UPDATE');
}
if (divPre) {
if (isPre) {
if (spanWarning) spanWarning.innerHTML = tr('FIRMWARE_OTA_RELEASE_BETA');
divPre.style.display = 'flex';
} else {
divPre.style.display = 'none';
}
}
}
async getReleaseInfo(tag, silent = false) {
let overlay = null;
if (!silent) overlay = ui.waitMessage(document.getElementById('divContainer'));
try {
let ret = { resp: { ok: false }, info: null };
ret.resp = await fetch(`https://api.github.com/repos/xkain/TESTRTS/releases/tags/${tag}`);
if (ret.resp.ok) {
ret.info = await ret.resp.json();
}
return ret;
}
catch (err) {
return { resp: { ok: false }, err: err };
}
finally {
if (overlay) overlay.remove();
}
}
formatInlineMarkdown(txt) {
if (!txt) return '';
return txt
.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
.replace(/\*(.*?)\*/g, '<i>$1</i>')
.replace(/`([^`]+)`/g, '<code class="md-code-inline">$1</code>')
.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" class="md-link">$1</a>')
.replace(/(?<!["=>])(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" class="md-link-auto">$1</a>');
}
parseMarkdown(bodyText) {
const self = this;
const ctx = {
lines: (bodyText || "").split(/\r?\n/),
ndx: 0,
html: '',
token(txt) {
const trimmed = txt.trim();
if (!trimmed) return { type: 'empty' };
const firstChar = txt.match(/\S/);
const indent = firstChar ? txt.indexOf(firstChar[0]) : 0;
if (trimmed.startsWith('#')) return { type: 'head', txt: trimmed, indent };
if (trimmed.startsWith('* ')) return { type: 'list', txt: trimmed.substring(2), indent };
return { type: 'text', txt: trimmed, indent };
},
renderHead(token) {
const level = (token.txt.match(/^#+/) || ["#"])[0].length;
const content = token.txt.replace(/^#+\s*/, '');
return `<h${level} style="margin: 10px 0 5px 0;">${self.formatInlineMarkdown(content)}</h${level}>`;
},
renderList() {
let listHtml = '<ul class="md-list" style="padding:0; margin:5px 0;">';
while (this.ndx < this.lines.length) {
const t = this.token(this.lines[this.ndx]);
if (t.type !== 'list') break;
const margin = (t.indent * 8) + 20;
listHtml += `<li style="margin-left:${margin}px; text-align:left; list-style-type:disc;">${self.formatInlineMarkdown(t.txt)}</li>`;
this.ndx++;
}
listHtml += '</ul>';
return listHtml;
},
parse() {
while (this.ndx < this.lines.length) {
const t = this.token(this.lines[this.ndx]);
switch (t.type) {
case 'head': this.html += this.renderHead(t); this.ndx++; break;
case 'list': this.html += this.renderList(); break;
case 'empty': this.html += '<div style="height:8px"></div>'; this.ndx++; break;
default:
const margin = (t.indent * 8) + (t.indent > 0 ? 20 : 0);
this.html += `<p style="margin: 2px 0; margin-left:${margin}px; text-align:left; line-height:1.4;">${self.formatInlineMarkdown(t.txt)}</p>`;
this.ndx++;
break;
}
}
}
};
ctx.parse();
return ctx.html;
}
updateManual(isApp = false) {
const service = isApp ? '/updateApplication' : '/updateFirmware';
const div = this.createFileUploader(service);
if (isApp) general.reloadApp = true;
const currentVer = isApp ? (general?.appVersion || this.appVersion) : (get('spanFwVersion').innerText || '?.?.?');
let instContent = div.querySelector('.instructions-content');
const updateDescKey = isApp ? 'FIRMWARE_MA_LITTLEFS_DESC' : 'FIRMWARE_MA_FIRMWARE_DESC';
instContent.insertAdjacentHTML('afterbegin', overlayHeader('FIRMWARE_MA_UPDATE_TITLE', updateDescKey, 'svg-update', { subtitle: updateDescKey, showInfo: false }));
div.querySelector('#divInstText').innerHTML = `



        <div class="overlay-static-content">
        <div class="baseFlexRow"><span class="uniLabel">${tr('FIRMWARE_MT_INSTALLED')}</span><span class="labelgrey">${currentVer}</span></div>
        <div class="warningText"><span>${tr('FIRMWARE_MT_CACHE')}</span></div></div>



        </div> <!-- <-- ICI : Elle s'arrête bien juste après le lien 'lnkGithubRelease' -->
        <div class="hrModal"></div>`;
div.className += isApp ? ' mode-app-update' : ' mode-firm-update';
shOverlay(div);
const btnB = div.querySelector('#btnBackupCfg');
if (btnB) {
btnB.style.display = 'flex';
btnB.onclick = () => firmware.backup();
}
}
async uploadFile(service, el, data) {
let field = el.querySelector('input[type="file"]'),
filename = field.value,
file = field.files[0],
title = tr('MSG_ALERT'),
err = null,
customErrMsg = null;
if (!filename) {
err = (service === '/restore')
? 'ERR_NO_FILE_BACKUP_SELECTED'
: (service === '/updateApplication' ? 'ERR_NO_FILE_LITTLEFS_SELECTED' : 'ERR_NO_FILE_FIRMWARE_SELECTED');
}
else {
const cleanFileName = filename.split(/(\\|\/)/).pop();
if (cleanFileName.includes('SomfyController')) {
const isOldFS = cleanFileName.includes('littlefs');
const fileTypeKey = isOldFS ? 'ERR_FIRMWARE_TYPE_LITTLEFS' : 'ERR_FIRMWARE_TYPE_FIRMWARE';
customErrMsg = tr('ERR_FIRMWARE_V2_INCOMPATIBLE')
.replace('%file%', cleanFileName)
.replace('%type%', tr(fileTypeKey));
}
else if (service === '/updateApplication' && (!cleanFileName.startsWith('ESPSomfyRTS_') || !cleanFileName.includes('_filesystem') || !cleanFileName.endsWith('.bin'))) {
err = 'ERR_INVALID_FILE_LITTLEFS';
}
else if (service === '/updateFirmware' && (!cleanFileName.startsWith('ESPSomfyRTS_') || cleanFileName.includes('_filesystem') || !cleanFileName.endsWith('.bin'))) {
err = 'ERR_INVALID_FILE_FIRMWARE';
}
else if (service === '/restore') {
if (file.size > 32768) {
const msg = tr('ERR_BACKUP_TOO_LARGE').replace('%s', file.size.fmt("#,##0"));
ui.errorMessage(title, msg);
return;
}
if (!cleanFileName.endsWith('.backup')) err = 'ERR_INVALID_FILE_BACKUP';
else if (!['shades', 'settings', 'network', 'transceiver', 'repeaters', 'mqtt'].some(k => data[k])) err = 'ERR_NO_RESTORE_OPTION';
}
}
if (customErrMsg || err) {
const message = customErrMsg ? customErrMsg : tr(err);
ui.errorMessage(title, message);
return;
}
if (service === '/updateFirmware' && window.__fwImageMarker) {
if (!await this.imageMarkerPresent(file, window.__fwImageMarker)) {
ui.errorMessage(title, tr('ERR_GIT_PARTITION_BLOCKED'));
return;
}
}
if (service === '/updateApplication' && window.__fsPartitionSize) {
if (!await this.fsImageGeometryOk(file, window.__fsPartitionSize)) {
ui.errorMessage(title, tr('ERR_GIT_PARTITION_BLOCKED'));
return;
}
}
this.confirmUploadFile(service, el, data, file);
}
async imageMarkerPresent(file, marker) {
try {
const buf = new Uint8Array(await file.arrayBuffer());
return new TextDecoder('latin1').decode(buf).indexOf(marker) >= 0;
}
catch (err) {
logger.warn('Firmware image marker check skipped:', err);
return true;
}
}
async fsImageGeometryOk(file, partitionSize) {
try {
const h = new DataView(await file.slice(0, 32).arrayBuffer());
if (h.byteLength < 32) return false;
const magic = new TextDecoder('latin1').decode(new Uint8Array(h.buffer, 8, 8));
if (magic !== 'littlefs') return false;
if (h.getUint32(0x14, true) >>> 16 !== 2) return false;
return h.getUint32(0x18, true) * h.getUint32(0x1C, true) === partitionSize;
}
catch (err) {
logger.warn('Filesystem image geometry check skipped:', err);
return true;
}
}
confirmUploadFile(service, el, data, file) {
const isRestore = service === '/restore';
const prompt = ui.promptMessage(get('divContainer'), tr(isRestore ? 'RESTORE_CONFIRM_TITLE' : 'GIT_RELEASE_CONFIRM_TITLE'), () => {
this._startUpload(service, el, data, file);
}, true, isRestore ? 'svg-restore' : 'svg-update');
prompt.querySelector('.sub-message').innerHTML = `<p>${tr(isRestore ? 'RESTORE_CONFIRM_SUB' : 'GIT_RELEASE_CONFIRM_SUB')}</p>`;
}
async _startUpload(service, el, data, file) {
if (service !== '/restore' && !this.isMobile()) {
try { await firmware.backup(); }
catch (e) { return ui.serviceError(el, e); }
}
let formData = new FormData();
formData.append('file', file);
if (service === '/restore') formData.append('data', JSON.stringify(data));
['btnBackupCfg', 'btnUploadFile'].forEach(id => { let b = el.querySelector('#' + id); if (b) b.style.display = 'none'; });
let field = el.querySelector('input[type="file"]');
field.disabled = true;
let steps = el.querySelector('.vertical-steps-container');
if (steps) steps.style.display = 'none';
let progWrap = el.querySelector('#divFileUploadProgress'),
prog = el.querySelector('#progFileUpload'),
progVal = el.querySelector('#progFileUpload-value'),
btnCancel = el.querySelector('#btnClose'),
backupRow = el.querySelector('.uniRow.backup-row'),
inProgressNotice = el.querySelector('#divUploadInProgressNotice');
progWrap.style.display = '';
if (backupRow) backupRow.style.display = 'none';
btnCancel.style.display = 'none';
if (inProgressNotice) inProgressNotice.style.display = '';
setOverlayLock(el, 'hard', {
titleKey: service === '/restore' ? 'PROMPT_RESTORE_IN_PROGRESS_TITLE' : 'PROMPT_UPDATE_IN_PROGRESS_TITLE',
msgKey: service === '/restore' ? 'PROMPT_RESTORE_IN_PROGRESS_MSG' : 'PROMPT_UPDATE_IN_PROGRESS_MSG',
});
let xhr = new XMLHttpRequest();
xhr.open('POST', baseUrl ? `${baseUrl}${service}` : service, true);
xhr.setRequestHeader('apikey', (typeof security !== 'undefined' ? security.apiKey : '') || '');
xhr.upload.onprogress = (evt) => {
let pct = evt.total ? Math.round((evt.loaded / evt.total) * 100) : 0;
prog.style.setProperty('--progress', `${pct}%`);
progVal.textContent = `${pct}%`;
};
xhr.onload = async () => {
clearOverlayLock(el);
if (xhr.status !== 200) {
if (inProgressNotice) inProgressNotice.style.display = 'none';
btnCancel.style.display = '';
btnCancel.innerText = tr('BT_CLOSE');
let desc = '';
try { desc = JSON.parse(xhr.responseText).desc || ''; } catch (e) { }
ui.serviceError(el, { htmlError: xhr.status, service: `POST ${service}`, desc: desc || xhr.statusText || httpStatusText[xhr.status || 500] });
return;
}
if (service === '/restore') {
await somfy.init();
closeOverlay(get('divUploadFile'));
}
else {
if (progWrap) progWrap.style.display = 'none';
if (inProgressNotice) inProgressNotice.style.display = 'none';
let successBox = el.querySelector('#divFileUploadSuccess');
if (successBox) successBox.style.display = '';
let footer = el.querySelector('.button-container-row');
if (footer) footer.style.display = 'none';
setTimeout(() => closeOverlay(get('divUploadFile')), 1500);
}
};
xhr.onerror = () => {
clearOverlayLock(el);
if (inProgressNotice) inProgressNotice.style.display = 'none';
btnCancel.style.display = '';
btnCancel.innerText = tr('BT_CLOSE');
ui.serviceError(el, 'Upload Failed');
};
btnCancel.onclick = () => requestCloseOverlay(el);
xhr.send(formData);
}
}
var firmware = new Firmware();